import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertOctagon,
  Bell,
  LayoutDashboard,
  Pause,
  Play,
  ScrollText,
  Settings,
  Shield,
  Square,
  Wallet,
  X,
} from "lucide-react";
import { STATION_BLURBS, DESTINATION_TYPES } from "@/lib/gmm/constants";
import { formatMoney } from "@/lib/gmm/money";
import type {
  AppState,
  AuditRow,
  BalanceState,
  ConnectorState,
  LedgerRow,
  OpportunityState,
  ProviderBalanceState,
  StationState,
} from "@/lib/gmm/types";
import {
  getAppState,
  getAuditLog,
  getConnectors,
  getLedger,
  getOpportunitiesFn,
  postCollection,
  postConnector,
  postDestination,
  postMasterAction,
  postOpportunity,
  postPaypalRail,
  postScan,
  postStationAction,
  postTransfer,
} from "@/lib/gmm/api";

type Tab = "dashboard" | "stations" | "funds" | "ledger" | "security" | "alerts";

const TABS: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "stations", label: "Stations", icon: Play },
  { id: "funds", label: "Move Money", icon: Wallet },
  { id: "ledger", label: "Transactions", icon: ScrollText },
  { id: "security", label: "Security", icon: Shield },
  { id: "alerts", label: "Notifications", icon: Bell },
];

function errMessage(err: unknown) {
  if (err && typeof err === "object" && "message" in err) return String((err as Error).message);
  return "Request failed";
}


function totalMoneyLabel(balance: BalanceState, value: string) {
  if (balance.status === "UNAVAILABLE" || balance.status === "NOT_CONFIGURED") return "—";
  return `$${formatMoney(value)}`;
}

function balanceStatusLabel(status: BalanceState["status"]) {
  if (status === "READY") return "Live provider balances verified";
  if (status === "PARTIAL") return "Partial provider balance data";
  if (status === "UNAVAILABLE") return "Live provider balances could not be verified";
  return "No live payout providers configured";
}

function providerSpendableLabel(provider: ProviderBalanceState) {
  if (provider.status === "UNAVAILABLE" || provider.status === "NOT_CONFIGURED") return "—";
  return `$${formatMoney(provider.spendable)}`;
}

function providerStatusLabel(status: ProviderBalanceState["status"]) {
  if (status === "LIVE") return "LIVE ACCOUNT";
  if (status === "TEST_MODE") return "TEST MODE — NOT REAL MONEY";
  if (status === "UNAVAILABLE") return "BALANCE UNAVAILABLE";
  return "NOT CONFIGURED";
}

function ProviderBalancePanel({ balance }: { balance: BalanceState }) {
  const rows = [
    { label: "Stripe platform balance", provider: balance.stripe },
    { label: "PayPal merchant balance (separate existing funds)", provider: balance.paypal },
  ];
  return (
    <div className="mt-4 rounded-md border border-line bg-canvas p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <strong className="text-ink">GMM Ledger · Company financial control and records</strong>
        <span className="text-xs font-extrabold tracking-wide text-gold">{balanceStatusLabel(balance.status)}</span>
      </div>
      {balance.status === "PARTIAL" ? (
        <p className="mt-2 text-sm text-muted">GMM Ledger is the company’s financial control and recordkeeping layer. The Field Team Stations are Tier 1; you authorize and verify activity in Tier 2; PayPal is the Tier 3 destination. A real transfer must still meet the connected account’s supported funding rules.</p>
      ) : null}
      {balance.status === "UNAVAILABLE" ? (
        <p className="mt-2 text-sm text-muted">GMM preserves the company ledger and your verification records. The selected external account is currently unavailable, so no external transfer success is claimed.</p>
      ) : null}
      {balance.status === "NOT_CONFIGURED" ? (
        <p className="mt-2 text-sm text-muted">No external transfer account balance is connected. GMM Ledger remains the company’s financial control and recordkeeping layer; real transfers require a supported account connection.</p>
      ) : null}
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {rows.map(({ label, provider }) => (
          <div key={label} className="rounded-md border border-line bg-panel p-3">
            <div className="text-sm font-bold text-ink">{label}</div>
            <div className="mt-1 text-[10px] font-extrabold tracking-wide text-muted">{providerStatusLabel(provider.status)}</div>
            <div className="mt-3 grid gap-1 text-sm text-muted">
              <div>Available <strong className="text-ink">{provider.available == null ? "—" : `$${formatMoney(provider.available)}`}</strong></div>
              <div>Pending <strong className="text-ink">{provider.pending == null ? "—" : `$${formatMoney(provider.pending)}`}</strong></div>
              <div>Spendable for payouts <strong className="text-gold">{providerSpendableLabel(provider)}</strong></div>
              <div>Payout holds / recent deductions <strong className="text-ink">${formatMoney(provider.reserved)}</strong></div>
            </div>
            {provider.message ? <p className="mt-2 text-xs text-muted">{provider.message}</p> : null}
            {provider.as_of ? <p className="mt-2 break-words text-[10px] text-muted">Provider snapshot: {new Date(provider.as_of).toLocaleString()}</p> : null}
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs text-muted">PayPal Payouts sends money out of an existing PayPal balance; the incoming-transfer integration must use a supported source-to-receiving-account route. THREE-TIER GMM FLOW: (1) Field Team Stations are the funding engine and funding sources; each funding activity must be verified. (2) You, the CEO, review and authorize station activity and transfers, with the GMM Ledger retaining the records and reconciliation history. (3) PayPal is the intended safekeeping destination for supported, authorized transfers. The ledger records station funding; provider-confirmed balances and transaction results determine what an external service has actually received and can transfer. PayPal reporting balances can be delayed.</p>
    </div>
  );
}

function FundingArchitecture() {
  const tiers = [
    {
      number: "TIER 1",
      title: "Field Team Stations",
      description: "The funding engine. Stations identify and perform their assigned funding activity; each collection must have traceable verification evidence.",
    },
    {
      number: "TIER 2",
      title: "CEO verification and control",
      description: "You review station activity, confirm records, authorize transfers, and oversee the company ledger and reconciliation history.",
    },
    {
      number: "TIER 3",
      title: "PayPal safekeeping destination",
      description: "Supported, authorized transfers go to PayPal. GMM records the provider reference and only treats a transfer as complete when provider status confirms it.",
    },
  ];
  return (
    <section aria-label="GMM three-tier financial architecture" className="mb-5 rounded-xl border border-gold/40 bg-panel p-5">
      <div className="text-xs font-extrabold tracking-[0.18em] text-gold">GMM CORE ARCHITECTURE</div>
      <h2 className="mt-1 font-display text-xl font-extrabold">Funding verification comes first</h2>
      <div className="mt-4 grid gap-3">
        {tiers.map((tier) => (
          <div key={tier.number} className="rounded-md border border-line bg-panel-2 p-3">
            <div className="text-[10px] font-extrabold tracking-[0.16em] text-gold">{tier.number}</div>
            <div className="mt-1 font-bold text-ink">{tier.title}</div>
            <p className="mt-1 text-sm text-muted">{tier.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function remainingSeconds(station: StationState, now: number) {
  if (station.paused) return station.paused_remaining_seconds || 0;
  if (station.active && station.next_cycle_at) {
    return Math.max(0, Math.ceil((new Date(station.next_cycle_at).getTime() - now) / 1000));
  }
  return 0;
}

function clock(total: number) {
  const h = String(Math.floor(total / 3600)).padStart(2, "0");
  const m = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

const DEST_FIELDS: Record<
  string,
  { key: string; label: string; placeholder: string; type?: string; required?: boolean }[]
> = {
  STRIPE_CONNECT: [
    { key: "connected_account_id", label: "Stripe connected account ID", placeholder: "acct_...", required: true },
  ],
  PAYPAL: [
    { key: "email", label: "PayPal recipient email", placeholder: "name@email.com", type: "email", required: true },
  ],
  ACH: [
    { key: "legal_name", label: "Legal name on the account", placeholder: "Account holder", required: true },
    { key: "routing_number", label: "Routing number", placeholder: "9 digits", required: true },
    { key: "account_number", label: "Account number", placeholder: "Account number", required: true },
    { key: "account_type", label: "Account type", placeholder: "checking or savings", required: true },
    { key: "phone", label: "Phone number", placeholder: "+1 404 000 0000", type: "tel" },
  ],
  DEBIT_CARD: [
    { key: "cardholder_name", label: "Cardholder name", placeholder: "Name on card", required: true },
    { key: "card_number", label: "Debit card number", placeholder: "Card number", required: true },
    { key: "phone", label: "Phone number", placeholder: "+1 404 000 0000", type: "tel" },
  ],
  CASH_APP: [
    { key: "cashtag", label: "Cash App $cashtag", placeholder: "$name", required: true },
    { key: "email", label: "Email", placeholder: "name@email.com", type: "email" },
    { key: "phone", label: "Phone number", placeholder: "+1 404 000 0000", type: "tel" },
  ],
  ONEPAY: [
    { key: "legal_name", label: "Legal name", placeholder: "Account holder", required: true },
    { key: "phone", label: "Phone number", placeholder: "+1 404 000 0000", type: "tel", required: true },
    { key: "email", label: "Email", placeholder: "name@email.com", type: "email" },
    { key: "account_id", label: "OnePay account id", placeholder: "Account id" },
  ],
};

function maskTail(value: string) {
  const digits = value.replace(/\s/g, "");
  if (digits.length <= 4) return "••••";
  return `••••${digits.slice(-4)}`;
}

function destinationSummary(externalId: string) {
  try {
    const row = JSON.parse(externalId) as Record<string, string>;
    const parts: string[] = [];
    if (row.email) parts.push(row.email);
    if (row.username) parts.push(row.username);
    if (row.cashtag) parts.push(row.cashtag);
    if (row.legal_name) parts.push(row.legal_name);
    if (row.cardholder_name) parts.push(row.cardholder_name);
    if (row.phone) parts.push(row.phone);
    if (row.account_type) parts.push(row.account_type);
    if (row.account_number) parts.push(maskTail(row.account_number));
    if (row.card_number) parts.push(maskTail(row.card_number));
    if (row.account_id) parts.push(row.account_id);
    return parts.join(" · ");
  } catch {
    return externalId;
  }
}

function StationCard({
  station,
  index,
  now,
  busy,
  onAction,
  onOpen,
}: {
  station: StationState;
  index: number;
  now: number;
  busy: boolean;
  onAction: (id: number, action: string) => void;
  onOpen: (station: StationState) => void;
}) {
  const rem = remainingSeconds(station, now);
  return (
    <article className="rounded-xl border border-line bg-panel p-6">
      <div className="flex items-center justify-between gap-3">
        <span className="font-display text-lg font-extrabold tracking-wide text-muted">
          #{String(index + 1).padStart(2, "0")}
        </span>
        <span className="rounded-full bg-gold px-3 py-1 text-[11px] font-extrabold tracking-widest text-gold-ink">
          {station.status}
        </span>
      </div>
      <h2 className="mt-4 font-display text-[1.7rem] font-extrabold leading-tight">
        {station.name.replace(/ Station$/, "")}
      </h2>
      <p className="mt-2 text-[0.95rem] leading-relaxed text-muted">{STATION_BLURBS[index]}</p>
      <div className="mt-4 rounded-md border border-line bg-canvas px-3 py-3">
        <div className="text-[11px] font-extrabold tracking-[0.14em] text-muted">RECORDED STATION EARNINGS</div>
        <div className="mt-1 font-display text-2xl font-extrabold text-gold">
          ${formatMoney(station.station_earnings)}
        </div>
        <div className="mt-1 text-xs text-muted">
          {station.completed_collections} completed {station.completed_collections === 1 ? "collection" : "collections"} · matched to this station
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between rounded-md border border-gold/40 bg-gold/5 px-3 py-2">
        {station.active || station.paused ? (
          <>
            <strong className="font-mono text-lg tracking-wider">{clock(rem)}</strong>
            <small className="text-xs tracking-wide text-muted">
              {station.paused ? "PAUSED — timer held" : "NEXT CYCLE"}
            </small>
          </>
        ) : (
          <small className="text-xs tracking-wide text-muted">90:00 cycle ready</small>
        )}
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {!station.active && !station.paused ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "start")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Play className="size-4" /> Start
          </button>
        ) : null}
        {station.active ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "pause")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Pause className="size-4" /> Pause
          </button>
        ) : null}
        {station.paused ? (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "start")}
            className="inline-flex h-11 items-center gap-2 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          >
            <Play className="size-4" /> Resume
          </button>
        ) : null}
        {(station.active || station.paused) && (
          <button
            disabled={busy}
            onClick={() => onAction(station.id, "stop")}
            className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-4 font-extrabold"
          >
            <Square className="size-4" /> Stop
          </button>
        )}
        <button
          onClick={() => onOpen(station)}
          className="inline-flex h-11 items-center rounded-md border border-line px-4 font-bold text-muted"
        >
          Details
        </button>
      </div>
    </article>
  );
}

export function GmmApp() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [state, setState] = useState<AppState | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [message, setMessage] = useState("");
  const [now, setNow] = useState(Date.now());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [detail, setDetail] = useState<StationState | null>(null);
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [audit, setAudit] = useState<AuditRow[]>([]);
  const [connectors, setConnectors] = useState<ConnectorState[]>([]);
  const [amount, setAmount] = useState("");
  const [dest, setDest] = useState("");
  const [dtype, setDtype] = useState("PAYPAL");
  const [dlabel, setDlabel] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [railId, setRailId] = useState("");
  const [railSecret, setRailSecret] = useState("");
  const [railWebhook, setRailWebhook] = useState("");
  const [depositTests, setDepositTests] = useState<Array<Record<string, unknown>>>([]);
  const [depositStationId, setDepositStationId] = useState("");
  const [checkoutStationId, setCheckoutStationId] = useState("");
  const [checkoutAmount, setCheckoutAmount] = useState("");
  const [checkoutOrders, setCheckoutOrders] = useState<Array<Record<string, unknown>>>([]);
  const [depositSuccess, setDepositSuccess] = useState<Record<string, unknown> | null>(null);
  const previousDepositStatuses = useRef<Map<string, string> | null>(null);

  const load = useCallback(async () => {
    try {
      const next = await getAppState();
      setState(next);
      setError("");
    } catch (err) {
      setError(errMessage(err));
    }
  }, []);

  useEffect(() => {
    void load();
    const poll = setInterval(() => void load(), 30000);
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      clearInterval(poll);
      clearInterval(tick);
    };
  }, [load]);

  useEffect(() => {
    if (tab === "ledger") void getLedger().then(setLedger).catch((e) => setError(errMessage(e)));
    if (tab === "security") void getAuditLog().then(setAudit).catch((e) => setError(errMessage(e)));
  }, [tab]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const checkoutId = Number(params.get("gmm_order"));
    const outcome = params.get("paypal_checkout");
    if (outcome === "return" && Number.isInteger(checkoutId) && checkoutId > 0) {
      setBusy("paypal-capture");
      void fetch(`/api/gmm/paypal/checkout-orders/${checkoutId}/capture`, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: "{}" })
        .then(async (res) => { const body = await res.json().catch(() => ({})); if (!res.ok) throw new Error(String(body.detail ?? "PayPal capture could not be confirmed")); setMessage(String(body.status) === "CAPTURE_PENDING" ? "PayPal is still processing the payment. GMM has not posted earnings yet." : "PayPal checkout capture checked. GMM only posts station earnings after PayPal confirms completion."); await load(); const listRes = await fetch("/api/gmm/paypal/checkout-orders", { credentials: "same-origin", cache: "no-store" }); const listBody = await listRes.json().catch(() => []); if (listRes.ok) setCheckoutOrders(Array.isArray(listBody) ? listBody as Array<Record<string, unknown>> : []); })
        .catch((err) => setMessage(errMessage(err)))
        .finally(() => { setBusy(""); window.history.replaceState({}, "", window.location.pathname); });
    } else if (outcome === "cancel") {
      setMessage("PayPal checkout was cancelled. No station earnings were posted.");
      window.history.replaceState({}, "", window.location.pathname);
    }
  // Only inspect the PayPal return URL on initial mount; subsequent app state changes must not recapture it.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshCheckoutOrders = async () => {
    const res = await fetch("/api/gmm/paypal/checkout-orders", { credentials: "same-origin", cache: "no-store" });
    const body = await res.json().catch(() => []);
    if (!res.ok) throw new Error(String(body.detail ?? "Could not load PayPal checkout orders"));
    setCheckoutOrders(Array.isArray(body) ? body as Array<Record<string, unknown>> : []);
  };

  const createCheckoutOrder = async () => {
    if (busy || !checkoutStationId || !checkoutAmount) return;
    const amountValue = Number(checkoutAmount);
    if (!Number.isFinite(amountValue) || amountValue <= 0) { setMessage("Enter a valid amount to request from the payer."); return; }
    setBusy("paypal-checkout-create"); setMessage("");
    try {
      const res = await fetch("/api/gmm/paypal/checkout-orders", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ station_id: Number(checkoutStationId), amount: amountValue, idempotency_key: `GMM-PP-CHECKOUT-${crypto.randomUUID()}` }) });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(String(body.detail ?? "Could not create PayPal checkout"));
      await refreshCheckoutOrders();
      if (body.approval_url) window.open(String(body.approval_url), "_blank", "noopener,noreferrer");
      setMessage("PayPal checkout created. The payer must approve and pay; GMM will record station earnings only after a completed capture is confirmed by PayPal.");
    } catch (err) { setMessage(errMessage(err)); }
    finally { setBusy(""); }
  };

  const captureCheckoutOrder = async (id: number) => {
    if (busy) return;
    setBusy(`paypal-capture-${id}`); setMessage("");
    try {
      const res = await fetch(`/api/gmm/paypal/checkout-orders/${id}/capture`, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: "{}" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(String(body.detail ?? "PayPal capture failed"));
      await refreshCheckoutOrders(); await load();
      setMessage(String(body.status) === "CAPTURE_PENDING" ? "PayPal payment is pending. No station earnings were posted." : "PayPal capture checked; only completed PayPal captures are recorded as station collections.");
    } catch (err) { setMessage(errMessage(err)); }
    finally { setBusy(""); }
  };

  const refreshDepositTests = async () => {
    const res = await fetch("/api/gmm/paypal/deposit-tests", { credentials: "same-origin", cache: "no-store" });
    const body = await res.json().catch(() => []);
    if (!res.ok) throw new Error(String(body.detail ?? "Could not load PayPal deposit tests"));
    const nextTests = Array.isArray(body) ? body as Array<Record<string, unknown>> : [];
    const previous = previousDepositStatuses.current;
    if (previous) {
      const newlyReceived = nextTests.find((test) =>
        String(test.status) === "RECEIVED" && previous.get(String(test.id)) !== "RECEIVED",
      );
      if (newlyReceived) setDepositSuccess(newlyReceived);
    }
    previousDepositStatuses.current = new Map(nextTests.map((test) => [String(test.id), String(test.status)]));
    setDepositTests(nextTests);
  };

  const startDepositTest = async () => {
    if (busy || !depositStationId) return;
    const confirmed = window.confirm("CEO confirmation: authorize a one-time $200.00 USD LIVE transfer from the connected authorized source-provider rail to your LIVE PayPal receiving account, attributed to this Field Team Station. GMM will automatically look for the real incoming credit in PayPal reporting. This does not create a checkout or manufacture funds.");
    if (!confirmed) return;
    setBusy("deposit-test");
    setMessage("");
    try {
      const res = await fetch("/api/gmm/paypal/deposit-tests", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ station_id: Number(depositStationId), ceo_confirmed: true, idempotency_key: `GMM-PP-TEST-${crypto.randomUUID()}` }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(String(body.detail ?? "Could not prepare the deposit test"));
      setMessage("CEO confirmation recorded. GMM is monitoring PayPal for the actual $200.00 USD incoming credit. A successful-transfer popup appears only after PayPal reports that the money arrived. The source station still needs a connected, authorized transfer rail.");
      await refreshDepositTests();
    } catch (err) { setMessage(errMessage(err)); }
    finally { setBusy(""); }
  };

  const refreshAndReconcileDepositTests = async () => {
    if (busy) return;
    setBusy("deposit-refresh");
    setMessage("");
    try {
      await refreshDepositTests();
      await load();
      setMessage("PayPal checked. If the $200.00 USD live deposit is reported as received, GMM updates the test and displays a Successful Transfer popup automatically. PayPal reporting can be delayed.");
    } catch (err) { setMessage(errMessage(err)); }
    finally { setBusy(""); }
  };

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (!params.has("paypal_deposit_test")) return;
    setTab("funds");
    if (params.has("paypal_checkout")) setMessage("This older checkout return is not part of the station-to-PayPal deposit workflow. GMM checks PayPal reporting automatically for an actual incoming credit.");
    void refreshDepositTests().catch((err) => setMessage(errMessage(err)));
    params.delete("paypal_deposit_test");
    params.delete("paypal_checkout");
    const query = params.toString();
    window.history.replaceState({}, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash}`);
  }, []);

  useEffect(() => {
    if (tab !== "funds") return;
    void refreshDepositTests().catch((err) => setMessage(errMessage(err)));
    // Reconcile periodically while the funds panel is open; PayPal reporting may lag.
    const depositPoll = setInterval(() => {
      void refreshDepositTests().catch((err) => setMessage(errMessage(err)));
      void load();
    }, 120000);
    return () => clearInterval(depositPoll);
  }, [tab, load]);

  const runMaster = async (action: string) => {
    if (busy) return;
    setBusy(action);
    setMessage("");
    try {
      const d = await postMasterAction({ data: { action } });
      setMessage(
        `${action === "emergency" ? "Emergency stop" : action === "start" ? "Start all" : action === "stop" ? "Stop all" : "Pause all"} executed for ${d.station_count} stations. Ledger unchanged.`,
      );
      await load();
    } catch (err) {
      setMessage(`Control action failed: ${errMessage(err)}`);
    } finally {
      setBusy("");
    }
  };

  const act = async (id: number, action: string) => {
    try {
      await postStationAction({ data: { id, action } });
      await load();
    } catch (err) {
      setError(errMessage(err));
    }
  };

  const sendTransfer = async () => {
    if (busy) return;
    setBusy("transfer");
    try {
      const res = await postTransfer({
        data: {
          amount: Number(amount),
          destination_id: Number(dest),
          idempotency_key: crypto.randomUUID(),
        },
      });
      if (res.status === "FAILED") {
        setMessage(res.error_message || "The provider rejected the transfer. Available funds were not reduced.");
      } else if (res.status === "COMPLETED") {
        setMessage("The provider confirmed the transfer completed.");
      } else if (res.status === "RECONCILIATION_REQUIRED") {
        setMessage("The request outcome is uncertain. GMM has held the amount to prevent duplicate spending; verify the provider transaction before retrying.");
      } else {
        setMessage(`Transfer submitted to the provider. Current status: ${res.status}.`);
      }
      setAmount("");
      await load();
    } catch (err) {
      setMessage(errMessage(err));
    } finally {
      setBusy("");
    }
  };

  const saveDest = async () => {
    const spec = DEST_FIELDS[dtype] ?? [];
    const missing = spec.filter((field) => field.required && !fields[field.key]?.trim());
    if (missing.length) {
      setMessage(`Enter ${missing.map((field) => field.label).join(", ")}.`);
      return;
    }
    const payload: Record<string, string> = {};
    for (const field of spec) {
      const value = fields[field.key]?.trim();
      if (value) payload[field.key] = value;
    }
    if (dtype === "STRIPE_CONNECT" && !/^acct_[A-Za-z0-9]+$/.test(payload.connected_account_id ?? "")) {
      setMessage("Enter a valid Stripe connected account ID beginning with acct_.");
      return;
    }
    if (dtype === "PAYPAL" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email ?? "")) {
      setMessage("Enter a valid PayPal recipient email address before saving the destination.");
      return;
    }
    const label =
      dlabel.trim() ||
      payload.email ||
      payload.username ||
      payload.cashtag ||
      payload.legal_name ||
      payload.cardholder_name ||
      dtype;
    try {
      await postDestination({
        data: { type: dtype, label, external_id: JSON.stringify(payload) },
      });
      setMessage(`${dtype.replaceAll("_", " ")} destination saved.`);
      setDlabel("");
      setFields({});
      await load();
    } catch (err) {
      setMessage(errMessage(err));
    }
  };

  const unread = useMemo(
    () => state?.notifications.filter((n) => !n.read).length ?? 0,
    [state],
  );

  if (!state) {
    return (
      <main className="mx-auto min-h-dvh w-full max-w-[760px] px-5 py-16">
        <div className="h-8 w-56 animate-pulse rounded-md bg-panel" />
        <div className="mt-8 h-40 animate-pulse rounded-xl bg-panel" />
        <div className="mt-4 h-32 animate-pulse rounded-xl bg-panel" />
      </main>
    );
  }

  const spendable = state.balance.spendable;
  const transferable = state.balance.transferable;
  const available = state.balance.available;
  const stationEarningsTotal = state.stations.reduce(
    (total, station) => total + Number(station.station_earnings || 0),
    0,
  );

  return (
    <div className="mx-auto min-h-dvh w-full max-w-[760px] px-5 pb-28 pt-8">
      <header className="flex items-start gap-4 border-b border-line pb-6">
        <div>
          <div className="font-display text-[1.65rem] font-extrabold tracking-wide">
            GET MONEY MACHINE
          </div>
          <div className="mt-1 text-xs font-bold tracking-[0.16em] text-gold">
            {balanceStatusLabel(state.balance.status)}
          </div>
        </div>
        <div className="ml-auto text-right">
          <span className="block text-[11px] font-extrabold tracking-[0.16em] text-muted">
            LIVE SPENDABLE BALANCE
          </span>
          <strong className="mt-1 block font-display text-[1.7rem] font-extrabold leading-none text-gold">
            {totalMoneyLabel(state.balance, spendable)}
          </strong>
        </div>
      </header>

      <nav className="-mx-1 flex gap-2 overflow-x-auto py-5">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`inline-flex h-11 shrink-0 items-center gap-2 rounded-full border px-5 text-[15px] font-extrabold ${
                tab === t.id
                  ? "border-gold bg-gold text-gold-ink"
                  : "border-line bg-panel-2 text-ink"
              }`}
            >
              <Icon className="size-4" />
              {t.label}
              {t.id === "alerts" && unread > 0 ? (
                <span className="rounded-full bg-gold-ink px-1.5 text-[10px] text-gold">{unread}</span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {error ? (
        <div className="mb-4 rounded-md border border-danger-line bg-danger-bg px-4 py-3 text-sm text-danger-fg">
          {error}
        </div>
      ) : null}

      {tab === "dashboard" || tab === "stations" ? (
        <>
          {tab === "dashboard" ? (
            <>
              <FundingArchitecture />
              <section className="mb-5 rounded-xl border border-line bg-panel p-7 shadow-[0_4px_18px_#0007]">
                <div className="text-sm font-extrabold tracking-[0.18em] text-muted">
                  LIVE SPENDABLE / TRANSFERABLE BALANCE
                </div>
                <div className="mt-3 font-display text-[3.2rem] font-extrabold leading-none text-gold">
                  {totalMoneyLabel(state.balance, spendable)}
                </div>
                <div className="mt-4 grid gap-1 text-[15px] text-muted">
                  <div>
                    Field Team Station funding records <strong className="text-ink">${formatMoney(stationEarningsTotal)}</strong>
                  </div>
                  <div>
                    Completed accounting ledger{" "}
                    <strong className="text-ink">${formatMoney(state.balance.completed_ledger)}</strong>
                  </div>
                  <div>
                    Provider pending funds{" "}
                    <strong className="text-ink">{totalMoneyLabel(state.balance, state.balance.pending)}</strong>
                  </div>
                  <div>
                    Spendable <strong className="text-ink">{totalMoneyLabel(state.balance, spendable)}</strong>
                  </div>
                  <div>
                    Transferable <strong className="text-ink">{totalMoneyLabel(state.balance, transferable)}</strong>
                  </div>
                  <div>
                    Verified live available <strong className="text-ink">{totalMoneyLabel(state.balance, available)}</strong>
                  </div>
                  <div>
                    Payout holds / recent deductions <strong className="text-ink">${formatMoney(state.balance.reserved)}</strong>
                  </div>
                </div>
                <div className="mt-4 rounded-md border border-line bg-panel-2 px-4 py-3 text-[15px] text-muted">
                  Tier 1 funding records across {state.stations.length} Field Team Stations: <strong className="text-gold">${formatMoney(stationEarningsTotal)}</strong>. GMM preserves these records. The available and transferable figures are reconciled separately against provider-confirmed balances so the same funds are not counted twice.
                </div>
                <ProviderBalancePanel balance={state.balance} />
                <div className="mt-5 flex flex-wrap gap-3">
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("start")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "start" ? "Starting…" : "Start All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("stop")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "stop" ? "Stopping…" : "Stop All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("pause")}
                    className="h-12 rounded-md bg-gold px-5 font-extrabold text-gold-ink"
                  >
                    {busy === "pause" ? "Pausing…" : "Pause All"}
                  </button>
                  <button
                    disabled={!!busy}
                    onClick={() => runMaster("emergency")}
                    className="inline-flex h-12 items-center gap-2 rounded-md bg-danger px-5 font-extrabold text-gold-ink"
                  >
                    <AlertOctagon className="size-4" />
                    {busy === "emergency" ? "Stopping…" : "Emergency Stop"}
                  </button>
                </div>
                {message ? (
                  <div className="mt-4 rounded-md border border-line bg-canvas px-4 py-3 text-sm text-muted">
                    {message}
                  </div>
                ) : null}
              </section>
              <p className="mb-5 rounded-md border border-line bg-panel-2 px-4 py-3 text-[15px] text-muted">
GMM uses the three-tier architecture: Tier 1 Field Team Stations (funding engine), Tier 2 CEO verification and authorization, Tier 3 PayPal (safekeeping destination). The ledger keeps the company’s financial records; external transfers must be confirmed by the connected service.
              </p>
            </>
          ) : (
            <h2 className="mb-4 font-display text-[1.8rem] font-extrabold">Stations</h2>
          )}
          <div className="grid gap-5">
            {state.stations.map((s, i) => (
              <StationCard
                key={s.id}
                station={s}
                index={i}
                now={now}
                busy={!!busy}
                onAction={act}
                onOpen={setDetail}
              />
            ))}
          </div>
        </>
      ) : null}

      {tab === "funds" ? (
        <section className="rounded-xl border border-line bg-panel p-7">
          <div className="text-sm font-extrabold tracking-[0.18em] text-muted">
            LIVE SPENDABLE / TRANSFERABLE BALANCE
          </div>
          <div className="mt-3 font-display text-[3rem] font-extrabold leading-none text-gold">
            {totalMoneyLabel(state.balance, spendable)}
          </div>
          <div className="mt-2 grid gap-1 text-sm text-muted">
            <div>Verified live available <strong className="text-ink">{totalMoneyLabel(state.balance, available)}</strong></div>
            <div>Provider pending <strong className="text-ink">{totalMoneyLabel(state.balance, state.balance.pending)}</strong></div>
            <div>Payout holds / recent deductions <strong className="text-ink">${formatMoney(state.balance.reserved)}</strong></div>
          </div>
          <p className="mt-3 text-[15px] text-muted">
            GMM Ledger is the internal financial provider, system of record, and payout orchestrator. Stripe and PayPal are external execution rails; the app keeps ledger accounting and external rail readiness as separate states.
          </p>
          <ProviderBalancePanel balance={state.balance} />
          <div className="mt-4 rounded-md border border-line bg-canvas px-4 py-3 text-sm text-muted">
            <div className="font-bold text-ink">Funding source: {state.funding_source.label}</div>
            <p className="mt-1">
              No provider-issued account number or routing number is on file. None is shown, because
              none has been issued.
            </p>
            <ul className="mt-3 grid gap-2">
              {Object.entries(state.providers).map(([key, provider]) => (
                <li key={key}>
                  {provider.provider}: {provider.configured ? "connected" : "not connected"}.
                  {provider.missing?.length ? ` Missing ${provider.missing.join(", ")}.` : ""}
                </li>
              ))}
            </ul>
            <div className="mt-4 grid gap-3">
              <div className="font-bold text-ink">PayPal payout credentials</div>
              <input
                value={railId}
                onChange={(e) => setRailId(e.target.value)}
                placeholder="PayPal client ID"
                autoComplete="off"
                className="h-12 rounded-md border border-line bg-panel px-3 text-ink"
              />
              <input
                value={railSecret}
                onChange={(e) => setRailSecret(e.target.value)}
                placeholder="PayPal secret"
                type="password"
                autoComplete="off"
                className="h-12 rounded-md border border-line bg-panel px-3 text-ink"
              />
              <input
                value={railWebhook}
                onChange={(e) => setRailWebhook(e.target.value)}
                placeholder="PayPal webhook ID"
                autoComplete="off"
                className="h-12 rounded-md border border-line bg-panel px-3 text-ink"
              />
              <p className="text-xs text-muted">
                Use PayPal Live API credentials. The client secret is sent to the server for verification and is never shown again.
                You may save the verified client ID and secret before creating the webhook; webhook-based confirmations remain unconfigured until its ID is added and verified.
              </p>
              <button
                type="button"
                className="h-11 rounded-md bg-gold font-extrabold text-gold-ink disabled:cursor-not-allowed disabled:opacity-45"
                disabled={!!busy || !railId.trim() || !railSecret.trim()}
                onClick={() => {
                  if (busy) return;
                  setBusy("paypal-credentials-save");
                  setMessage("");
                  void postPaypalRail({
                    data: { client_id: railId, client_secret: railSecret, webhook_id: railWebhook },
                  })
                    .then(() => {
                      setRailSecret("");
                      setMessage(railWebhook.trim()
                        ? "PayPal Live credentials authenticated and saved securely on the server; webhook ID verified."
                        : "PayPal Live credentials authenticated and saved securely on the server. Add and verify the webhook ID before relying on webhook-based confirmations.");
                      return load();
                    })
                    .catch((err) => setMessage(errMessage(err)))
                    .finally(() => setBusy(""));
                }}
              >
                {busy === "paypal-credentials-save" ? "Verifying and saving…" : "Save PayPal credentials"}
              </button>
            </div>
          </div>
          <div className="mt-6 rounded-xl border border-line bg-canvas p-5">
            <div className="text-sm font-extrabold tracking-[0.16em] text-gold">PAYPAL CHECKOUT — RECEIVE A PAYER PAYMENT</div>
            <p className="mt-2 text-sm text-muted">Create a PayPal payment request linked to one of your 15 Field Team Stations. The payer must approve and pay in PayPal. Only a PayPal-confirmed completed capture is posted to that station's earnings ledger. This is an incoming payer payment, not a transfer of previously recorded internal earnings.</p>
            <label className="mt-4 block text-sm font-bold text-muted">Receiving Field Team Station
              <select value={checkoutStationId} onChange={(e) => setCheckoutStationId(e.target.value)} className="mt-2 h-12 w-full rounded-md border border-line bg-panel px-3 text-ink">
                <option value="">Select station</option>
                {(state?.stations ?? []).map((station) => <option key={station.id} value={station.id}>{station.name}</option>)}
              </select>
            </label>
            <label className="mt-3 block text-sm font-bold text-muted">Payment amount (USD)
              <input value={checkoutAmount} onChange={(e) => setCheckoutAmount(e.target.value)} type="number" min="0.01" max="1000000" step="0.01" placeholder="0.00" className="mt-2 h-12 w-full rounded-md border border-line bg-panel px-3 text-ink" />
            </label>
            <button className="mt-3 h-11 w-full rounded-md bg-gold font-extrabold text-gold-ink disabled:opacity-45" disabled={!checkoutStationId || !checkoutAmount || !!busy} onClick={() => void createCheckoutOrder()}>{busy === "paypal-checkout-create" ? "Creating PayPal order…" : "Create PayPal Payment Request"}</button>
            <button className="mt-2 h-10 w-full rounded-md border border-gold font-bold text-ink disabled:opacity-45" disabled={!!busy} onClick={() => void refreshCheckoutOrders().catch((err) => setMessage(errMessage(err)))}>Refresh PayPal Checkout Status</button>
            <div className="mt-3 space-y-2">
              {checkoutOrders.map((order) => <div key={String(order.id)} className="rounded-md border border-line bg-panel p-3">
                <div className="flex flex-wrap justify-between gap-2"><strong>Checkout #{String(order.id)} · ${formatMoney(String(order.amount ?? "0.00"))}</strong><span className="text-xs font-bold">{String(order.status).replaceAll("_", " ")}</span></div>
                <div className="mt-1 text-xs text-muted">{String(order.station_name ?? "Field Team Station")} · {String(order.created_at ?? "")}</div>
                {order.approval_url && String(order.status) !== "CAPTURED" ? <a className="mt-2 inline-block text-sm font-bold text-gold underline" href={String(order.approval_url)} target="_blank" rel="noreferrer">Open PayPal payment approval</a> : null}
                {String(order.status) !== "CAPTURED" && order.paypal_order_id ? <button className="mt-2 block rounded-md border border-line px-3 py-2 text-sm font-bold" disabled={!!busy} onClick={() => void captureCheckoutOrder(Number(order.id))}>Check approval and capture payment</button> : null}
                {order.paypal_capture_id ? <div className="mt-1 text-xs text-muted">PayPal capture: {String(order.paypal_capture_id)}</div> : null}
                {order.error_message ? <p className="mt-1 text-xs text-muted">{String(order.error_message)}</p> : null}
              </div>)}
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-gold/40 bg-canvas p-5">
            <div className="text-sm font-extrabold tracking-[0.16em] text-gold">CEO-CONTROLLED $200 LIVE PAYPAL DEPOSIT TEST</div>
            <p className="mt-2 text-sm text-muted">Field Team Station earnings recorded in GMM Ledger → your one CEO authorization → your connected PayPal receiving account. GMM checks PayPal reporting automatically and marks the test received only when PayPal confirms the actual successful $200.00 USD incoming credit. No checkout or manual transaction-ID entry is used. The external ledger-to-PayPal execution rail must be configured; authorization alone does not move funds.</p>
            <label className="mt-4 block text-sm font-bold text-muted">Source Field Team Station
              <select value={depositStationId} onChange={(e) => setDepositStationId(e.target.value)} className="mt-2 h-12 w-full rounded-md border border-line bg-panel px-3 text-ink">
                <option value="">Select station</option>
                {(state?.stations ?? []).map((station) => <option key={station.id} value={station.id}>{station.name}</option>)}
              </select>
            </label>
            <button className="mt-3 h-11 w-full rounded-md bg-gold font-extrabold text-gold-ink disabled:opacity-45" disabled={!depositStationId || !!busy} onClick={() => void startDepositTest()}>
              {busy === "deposit-test" ? "Authorizing…" : "Authorize $200 LIVE Deposit Test"}
            </button>
            <div className="mt-4 space-y-3">
              <button className="h-10 w-full rounded-md border border-gold font-bold text-ink disabled:opacity-45" disabled={!!busy} onClick={() => void refreshAndReconcileDepositTests()}>{busy === "deposit-refresh" ? "Checking PayPal…" : "Refresh PayPal Balance & Auto-Detect Deposit"}</button>
              {depositTests.map((test) => <div key={String(test.id)} className="rounded-md border border-line bg-panel p-3">
                <div className="flex flex-wrap justify-between gap-2"><strong>Test #{String(test.id)} · ${formatMoney(String(test.amount ?? "200.00"))}</strong><span className="text-xs font-bold">{String(test.status).replaceAll("_", " ")}</span></div>
                <div className="mt-1 text-xs text-muted">{String(test.station_name ?? "Field Team Station")} · {String(test.created_at ?? "")}</div>
                {["AWAITING_SOURCE_TRANSFER", "AWAITING_PAYER_APPROVAL", "CAPTURE_PENDING"].includes(String(test.status)) ? <>
                  <p className="mt-2 text-sm text-muted">Awaiting the actual $200.00 USD live credit in your PayPal account. GMM automatically searches PayPal’s transaction report whenever this panel refreshes. When PayPal reports the successful incoming credit, this test changes to RECEIVED automatically. Reporting may lag by up to several hours. No manual transaction ID is required.</p>
                </> : <p className="mt-2 text-sm text-muted">PayPal transaction: {String(test.paypal_transaction_id ?? "not recorded")}; event {String(test.paypal_event_code ?? "—")}</p>}
                {test.error_message ? <p className="mt-2 text-xs text-muted">{String(test.error_message)}</p> : null}
              </div>)}
              {!depositTests.length ? <p className="text-xs text-muted">No receiving tests created yet.</p> : null}
            </div>
          </div>
          <label className="mt-6 block text-sm font-bold text-muted">Amount</label>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            type="number"
            min="0.01"
            step="0.01"
            placeholder="0.00"
            className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-lg"
          />
          <div className="mt-6">
            <div className="text-sm font-extrabold tracking-[0.16em] text-muted">
              DESTINATION CREDENTIALS
            </div>
            <p className="mt-2 text-sm text-muted">
              Save who the money goes to. For PayPal receiving, save the intended account email. This destination record alone does not move funds into the PayPal balance.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {DESTINATION_TYPES.map(([k, label]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => {
                    setDtype(k);
                    setFields({});
                  }}
                  className={`rounded-full border px-4 py-2 text-sm font-extrabold ${
                    dtype === k
                      ? "border-gold bg-gold text-gold-ink"
                      : "border-line bg-panel-2 text-ink"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="mt-4 grid gap-3">
              <label className="text-sm font-bold text-muted">
                Label
                <input
                  value={dlabel}
                  onChange={(e) => setDlabel(e.target.value)}
                  placeholder="Optional nickname"
                  className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-base text-ink"
                />
              </label>
              {(DEST_FIELDS[dtype] ?? []).map((field) => (
                <label key={field.key} className="text-sm font-bold text-muted">
                  {field.label}
                  <input
                    value={fields[field.key] ?? ""}
                    onChange={(e) =>
                      setFields((prev) => ({ ...prev, [field.key]: e.target.value }))
                    }
                    type={field.type ?? "text"}
                    inputMode={field.type === "tel" ? "tel" : undefined}
                    autoComplete={field.type === "email" ? "email" : field.type === "tel" ? "tel" : "off"}
                    placeholder={field.placeholder}
                    className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-base text-ink"
                  />
                </label>
              ))}
              <button
                type="button"
                className="h-12 rounded-md bg-gold font-extrabold text-gold-ink"
                onClick={() => void saveDest()}
              >
                Save Destination
              </button>
            </div>
            <div className="mt-5 grid gap-2">
              {state.destinations.filter((d) => d.enabled).length ? (
                state.destinations
                  .filter((d) => d.enabled)
                  .map((d) => (
                    <div key={d.id} className="rounded-md border border-line bg-canvas px-4 py-3">
                      <div className="font-extrabold">{d.label}</div>
                      <div className="mt-1 text-sm text-muted">
                        {d.type.replaceAll("_", " ")} · {destinationSummary(d.external_id)}
                      </div>
                    </div>
                  ))
              ) : (
                <div className="text-sm text-muted">No destinations saved yet.</div>
              )}
            </div>
          </div>
          <label className="mt-6 block text-sm font-bold text-muted">Transfer destination</label>
          <select
            value={dest}
            onChange={(e) => setDest(e.target.value)}
            className="mt-2 h-12 w-full rounded-md border border-line bg-canvas px-4 text-base"
          >
            <option value="">Select destination</option>
            {state.destinations
              .filter((d) => d.enabled)
              .map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label} · {destinationSummary(d.external_id)}
                </option>
              ))}
          </select>
          {state.destinations.find((d) => String(d.id) === dest)?.type === "PAYPAL" ? (
            <p className="mt-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm text-muted">
              PayPal recipient email is saved. Important: PayPal Payouts sends money out of an existing PayPal balance; it cannot move GMM ledger funds into your own PayPal account. This destination remains blocked for that direction until a supported, authorized source-to-PayPal transfer rail is implemented.
            </p>
          ) : null}
          <button
            className="mt-5 h-12 w-full rounded-md bg-gold text-lg font-extrabold text-gold-ink disabled:opacity-45"
            disabled={!amount || !dest || !!busy}
            onClick={() => void sendTransfer()}
          >
            {busy === "transfer" ? "Submitting…" : "Send Transfer"}
          </button>
          {message ? (
            <div className="mt-4 rounded-md border border-line bg-canvas px-4 py-3 text-sm text-muted">
              {message}
            </div>
          ) : null}
          <div className="mt-6">
            <h2 className="font-display text-xl font-extrabold">Recent Available Funds Activity</h2>
            {state.withdrawals.length ? (
              state.withdrawals.slice(0, 10).map((w) => (
                <div
                  key={w.id}
                  className="mt-2 rounded-md border border-line bg-canvas px-4 py-3"
                >
                  <div className="flex justify-between gap-3">
                    <span>{w.status}</span>
                    <strong className="text-gold">${formatMoney(w.amount)}</strong>
                  </div>
                  {w.error_message ? (
                    <p className="mt-1 text-sm text-muted">{w.error_message}</p>
                  ) : null}
                  {w.status === "FAILED" ? (
                    <p className="mt-1 text-sm text-muted">The provider rejected this transfer. Available funds were not reduced.</p>
                  ) : null}
                  {w.status === "INITIATED" ? (
                    <p className="mt-1 text-sm text-muted">Provider payout initiated; completion is not confirmed.</p>
                  ) : null}
                </div>
              ))
            ) : (
              <div className="py-4 text-muted">No activity.</div>
            )}
          </div>
        </section>
      ) : null}

      {tab === "ledger" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Ledger Transactions</h2>
          <p className="mt-2 text-sm text-muted">
            GMM Ledger is the internal financial provider and authoritative system of record: it authorizes, records, reserves, audits, and reconciles money movements. Stripe and PayPal APIs are external execution rails and must use their officially supported funding flows. An owner-verified ledger entry remains recorded in GMM Ledger; it is not represented as a provider-side deposit unless a real funding transaction confirms that deposit.
          </p>
          {ledger.length ? (
            ledger.map((row) => (
              <div
                key={row.id}
                className="mt-3 rounded-lg border border-line bg-panel px-4 py-3"
              >
                <div className="flex justify-between gap-3">
                  <span className="font-bold">{row.kind}</span>
                  <strong className="font-mono text-gold">${formatMoney(row.amount)}</strong>
                </div>
                <div className="mt-1 text-sm text-muted">{row.status}</div>
                <div className="mt-1 text-sm text-muted">{row.description}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 rounded-lg border border-line bg-panel px-4 py-6 text-muted">
              Ledger is empty. No opening balance has been recorded.
            </div>
          )}
        </section>
      ) : null}

      {tab === "security" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Audit & Security</h2>
          {audit.length ? (
            audit.map((row) => (
              <div key={row.id} className="mt-3 rounded-lg border border-line bg-panel px-4 py-3">
                <div className="font-bold">{row.action}</div>
                <div className="mt-1 text-sm text-muted">{row.detail}</div>
                <div className="mt-1 font-mono text-xs text-subtle">{row.created_at}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 text-muted">No audit events yet.</div>
          )}
        </section>
      ) : null}

      {tab === "alerts" ? (
        <section>
          <h2 className="font-display text-[1.8rem] font-extrabold">Notifications</h2>
          {state.notifications.length ? (
            state.notifications.map((n) => (
              <div key={n.id} className="mt-3 rounded-lg border border-line bg-panel px-4 py-3">
                <div className="font-bold">{n.title}</div>
                <div className="mt-1 text-sm text-muted">{n.message}</div>
              </div>
            ))
          ) : (
            <div className="mt-6 text-muted">No notifications.</div>
          )}
        </section>
      ) : null}

      <button
        type="button"
        aria-label="Settings"
        onClick={() => {
          setSettingsOpen(true);
          void getConnectors().then(setConnectors).catch(() => undefined);
        }}
        className="fixed bottom-6 right-5 grid size-[62px] place-items-center rounded-full border-[8px] border-[#303030] bg-[#656565] text-ink shadow-[0_0_0_5px_#171717]"
      >
        <Settings className="size-6" />
      </button>

      {settingsOpen ? (
        <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 p-0 sm:place-items-center sm:p-6">
          <div className="max-h-[92dvh] w-full max-w-[560px] overflow-y-auto rounded-t-xl border border-line bg-panel p-6 sm:rounded-xl">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-extrabold">Control room</h2>
              <button onClick={() => setSettingsOpen(false)} className="grid size-10 place-items-center">
                <X className="size-5" />
              </button>
            </div>
            <p className="mt-4 text-sm text-muted">
              Scanner mode: live external connectors. Search scope: worldwide (all countries). Each scan sends global scope, all countries, the station name, and station-specific search terms to its configured endpoint. The endpoint must support those parameters and return real JSON results. Fabricated results: false. Cycle: 90 minutes.
            </p>
            <h3 className="mt-5 font-display text-xl font-extrabold">Station connectors</h3>
            <div className="mt-3 grid gap-3">
              {connectors.map((c) => (
                <ConnectorEditor key={c.station_id} connector={c} onSaved={() => void getConnectors().then(setConnectors)} />
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {detail ? (
        <StationDetail
          station={detail}
          onClose={() => setDetail(null)}
          onChanged={() => void load()}
        />
      ) : null}
      {depositSuccess ? (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-5" role="dialog" aria-modal="true" aria-labelledby="paypal-deposit-success-title">
          <div className="w-full max-w-md rounded-2xl border border-emerald-400/60 bg-panel p-6 shadow-2xl">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border-2 border-emerald-500 text-3xl font-black text-emerald-500" aria-hidden="true">✓</div>
            <h2 id="paypal-deposit-success-title" className="mt-4 text-center text-2xl font-extrabold">Successful Transfer</h2>
            <p className="mt-2 text-center text-sm text-muted">PayPal reporting confirms that the money arrived in the connected receiving account.</p>
            <div className="mt-5 rounded-xl border border-line bg-canvas p-4 text-center">
              <div className="text-xs font-bold uppercase tracking-wider text-muted">Confirmed PayPal deposit</div>
              <div className="mt-1 text-3xl font-extrabold text-emerald-500">${formatMoney(String(depositSuccess.amount ?? "200.00"))} USD</div>
              <div className="mt-2 text-sm text-muted">{String(depositSuccess.station_name ?? "Field Team Station")}</div>
              <div className="mt-1 break-all text-xs text-muted">PayPal transaction: {String(depositSuccess.paypal_transaction_id ?? "confirmed by PayPal")}</div>
            </div>
            <button className="mt-5 h-12 w-full rounded-md bg-emerald-600 font-extrabold text-white" onClick={() => setDepositSuccess(null)}>Done</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function ConnectorEditor({
  connector,
  onSaved,
}: {
  connector: ConnectorState;
  onSaved: () => void;
}) {
  const [endpoint, setEndpoint] = useState(connector.endpoint ?? "");
  const [enabled, setEnabled] = useState(connector.enabled);
  const [msg, setMsg] = useState("");
  return (
    <div className="rounded-lg border border-line bg-canvas p-4">
      <div className="font-bold">{connector.station_name}</div>
      <p className="mt-1 text-xs text-muted">Worldwide search connector — use an HTTPS API endpoint that supports scope=worldwide, countries=all, station, and query parameters and returns real JSON opportunity records.</p>
      <input
        value={endpoint}
        onChange={(e) => setEndpoint(e.target.value)}
        placeholder="https://source.example/opportunities.json"
        className="mt-2 h-11 w-full rounded-md border border-line bg-panel px-3 text-sm"
      />
      <label className="mt-2 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        Enable live connector
      </label>
      <button
        className="mt-2 h-10 rounded-md bg-gold px-4 text-sm font-extrabold text-gold-ink"
        onClick={async () => {
          try {
            await postConnector({
              data: {
                station_id: connector.station_id,
                connector_type: "http_json",
                endpoint,
                enabled,
              },
            });
            setMsg("Saved");
            onSaved();
          } catch (err) {
            setMsg(errMessage(err));
          }
        }}
      >
        Save
      </button>
      {msg ? <div className="mt-2 text-xs text-muted">{msg}</div> : null}
    </div>
  );
}

function StationDetail({
  station,
  onClose,
  onChanged,
}: {
  station: StationState;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [rows, setRows] = useState<OpportunityState[]>([]);
  const [title, setTitle] = useState("");
  const [source, setSource] = useState("");
  const [value, setValue] = useState("");
  const [evidence, setEvidence] = useState("");
  const [msg, setMsg] = useState("");

  const reload = useCallback(() => {
    void getOpportunitiesFn({ data: { station_id: station.id } })
      .then(setRows)
      .catch((e) => setMsg(errMessage(e)));
  }, [station.id]);

  useEffect(() => {
    reload();
  }, [reload]);

  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-black/70 sm:place-items-center sm:p-6">
      <div className="max-h-[92dvh] w-full max-w-[560px] overflow-y-auto rounded-t-xl border border-line bg-panel p-6 sm:rounded-xl">
        <div className="flex items-start justify-between gap-3">
          <h2 className="font-display text-2xl font-extrabold">{station.name}</h2>
          <button onClick={onClose} className="grid size-10 place-items-center">
            <X className="size-5" />
          </button>
        </div>
        <p className="mt-2 text-sm text-muted">
This station belongs to Tier 1, the funding engine. Your Tier 2 review records and verifies station activity; a ledger entry is preserved, while an external deposit or transfer is only marked successful when supported transaction evidence confirms it.
        </p>
        <div className="mt-4 rounded-md border border-gold/40 bg-gold/5 p-4">
          <div className="text-xs font-extrabold tracking-widest text-muted">THIS STATION'S RECORDED EARNINGS</div>
          <div className="mt-1 font-display text-3xl font-extrabold text-gold">${formatMoney(station.station_earnings)}</div>
          <div className="mt-1 text-sm text-muted">{station.completed_collections} completed {station.completed_collections === 1 ? "collection" : "collections"}</div>
        </div>
        <button
          className="mt-4 h-11 rounded-md bg-gold px-4 font-extrabold text-gold-ink"
          onClick={async () => {
            try {
              const r = await postScan({ data: { station_id: station.id } });
              setMsg(`Scan ${r.status}. Fabricated results: false.`);
              reload();
              onChanged();
            } catch (err) {
              setMsg(errMessage(err));
            }
          }}
        >
          Run scan
        </button>
        <div className="mt-5 grid gap-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Opportunity title"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <input
            value={source}
            onChange={(e) => setSource(e.target.value)}
            placeholder="Source URL (optional)"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Collected amount"
            className="h-11 rounded-md border border-line bg-canvas px-3"
          />
          <textarea
            value={evidence}
            onChange={(e) => setEvidence(e.target.value)}
            placeholder="Required: source confirmation, receipt/reference, award notice, or other traceable evidence"
            rows={3}
            className="rounded-md border border-line bg-canvas px-3 py-2"
          />
          <button
            disabled={!evidence.trim() || evidence.trim().length < 8}
            className="h-11 rounded-md border border-line font-extrabold disabled:cursor-not-allowed disabled:opacity-50"
            onClick={async () => {
              try {
                await postCollection({
                  data: {
                    station_id: station.id,
                    title,
                    amount: Number(value),
                    evidence: [evidence, source].filter(Boolean).join("\n"),
                  },
                });
                setTitle("");
                setSource("");
                setValue("");
                setEvidence("");
                setMsg("Collection recorded with CEO-supplied verification evidence. The GMM Ledger records this funding; external-account receipt and transferable cash remain separately reconciled against provider confirmation.");
                reload();
                onChanged();
              } catch (err) {
                setMsg(errMessage(err));
              }
            }}
          >
            Record completed collection
          </button>
        </div>
        {msg ? <div className="mt-3 text-sm text-muted">{msg}</div> : null}
        <div className="mt-5 grid gap-2">
          {rows.map((o) => (
            <div key={o.id} className="rounded-md border border-line bg-canvas px-3 py-3 text-sm">
              <div className="font-bold">
                #{o.id} {o.title}
              </div>
              <div className="text-muted">
                {o.state}
                {o.verified_value ? ` · collected $${formatMoney(o.verified_value)}` : ""}
                {!o.verified_value && o.estimated_value
                  ? ` · est $${formatMoney(o.estimated_value)}`
                  : ""}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
