import {
  addDestination,
  addOpportunity,
  controlStation,
  GmmError,
  handlePaypalWebhook,
  startPaypalDepositTest,
  listPaypalDepositTests,
  startPaypalCheckout,
  capturePaypalCheckout,
  listPaypalCheckoutOrders,
  confirmPaypalDepositTest,
  health,
  listAudit,
  getLedgerAccountStatus,
  listConnectors,
  listLedger,
  listOpportunities,
  loadAppState,
  markNotificationRead,
  masterControl,
  recordStationCollection,
  requestTransfer,
  saveConnector,
  savePaypalRail,
  scanStation,
  verifyOpportunity,
  withOwnerSql,
  runScheduledStationCycles,
} from "./core";
import { requireUserId } from "@/lib/auth/verify.server";
import { assertApprovedGmmBuild } from "./build-gate.server";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json",
      "Cache-Control": "no-store, no-cache, must-revalidate" },
  });
}

function err(message: string, status = 400) {
  return json({ detail: message }, status);
}

async function bodyOf(request: Request) {
  return (await request.json().catch(() => ({}))) as Record<string, unknown>;
}

async function requireUser(_request: Request): Promise<string> {
  // Resolve a signed server session (or an authorized live-preview bearer).
  // Never trust a client-supplied owner ID or a hard-coded bearer token.
  return requireUserId();
}

export async function handleGmmRequest(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/^\/api\/gmm/, "") || "/";
  const method = request.method.toUpperCase();

  try {
    if (method === "GET" && path === "/health") return json(await health());

    if (method === "POST" && path === "/paypal/webhook") {
      return json(await handlePaypalWebhook(request));
    }


    // Authenticated by a dedicated server-only worker secret; no user session or
    // client-supplied owner ID is accepted for this scheduler-only operation.
    if (method === "POST" && path === "/internal/worker/tick") {
      const configuredSecret = process.env.GMM_WORKER_SECRET?.trim();
      const suppliedSecret = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "").trim() ?? "";
      const ownerId = process.env.GMM_OWNER_USER_ID?.trim() ?? "";
      if (!configuredSecret || !ownerId) return err("Background worker is not configured", 503);
      const a = new TextEncoder().encode(configuredSecret);
      const b = new TextEncoder().encode(suppliedSecret);
      let mismatch = a.length ^ b.length;
      for (let i = 0; i < Math.max(a.length, b.length); i += 1) mismatch |= (a[i] ?? 0) ^ (b[i] ?? 0);
      if (mismatch !== 0) return err("Unauthorized", 401);
      return json({ status: "completed", worker: await runScheduledStationCycles(ownerId) });
    }

    // Health, provider webhooks and secret-authenticated worker stay available.
    assertApprovedGmmBuild(request.headers.get("x-gmm-build-id") ?? undefined);
    const userId = await requireUser(request);

    if (method === "GET" && path === "/account/status") {
      return json(await getLedgerAccountStatus(userId));
    }

    if (method === "GET" && path === "/auth/me") {
      return json({ id: userId });
    }
    if (method === "POST" && path === "/auth/logout") {
      return json({ status: "logged_out" });
    }

    if (method === "GET" && path === "/stations") {
      const state = await loadAppState(userId);
      return json(state.stations);
    }
    if (method === "GET" && path === "/balance") {
      const state = await loadAppState(userId);
      return json(state.balance);
    }
    if (method === "GET" && path === "/destinations") {
      const state = await loadAppState(userId);
      return json(state.destinations);
    }
    if (method === "GET" && path === "/withdrawals") {
      const state = await loadAppState(userId);
      return json(state.withdrawals);
    }
    if (method === "GET" && (path === "/transactions" || path === "/ledger")) {
      return json(await listLedger(userId));
    }
    if (method === "GET" && path === "/audit") return json(await listAudit(userId));
    if (method === "GET" && path === "/notifications") {
      const state = await loadAppState(userId);
      return json(state.notifications);
    }
    if (method === "GET" && path === "/paypal/status") {
      const state = await loadAppState(userId);
      return json(state.paypal);
    }
    if (method === "GET" && path === "/paypal/checkout-orders") {
      return json(await listPaypalCheckoutOrders(userId));
    }
    if (method === "POST" && path === "/paypal/checkout-orders") {
      const body = await bodyOf(request);
      return json(await startPaypalCheckout(userId, {
        station_id: Number(body.station_id), amount: Number(body.amount),
        idempotency_key: String(body.idempotency_key ?? crypto.randomUUID()),
        origin: url.origin,
      }), 201);
    }
    const checkoutCapture = path.match(/^\/paypal\/checkout-orders\/(\d+)\/capture$/);
    if (method === "POST" && checkoutCapture) {
      return json(await capturePaypalCheckout(userId, Number(checkoutCapture[1])));
    }
    if (method === "GET" && path === "/paypal/deposit-tests") {
      return json(await listPaypalDepositTests(userId));
    }
    if (method === "POST" && path === "/paypal/deposit-tests") {
      const body = await bodyOf(request);
      return json(await startPaypalDepositTest(userId, {
        station_id: Number(body.station_id),
        ceo_confirmed: body.ceo_confirmed === true,
        idempotency_key: String(body.idempotency_key ?? crypto.randomUUID()),
      }), 201);
    }
    const depositTestConfirm = path.match(/^\/paypal\/deposit-tests\/(\d+)\/confirm$/);
    if (method === "POST" && depositTestConfirm) {
      const body = await bodyOf(request);
      return json(await confirmPaypalDepositTest(userId, Number(depositTestConfirm[1]), String(body.transaction_id ?? "")));
    }
    if (method === "POST" && path === "/paypal/credentials") {
      const body = await bodyOf(request);
      const saved = await savePaypalRail(userId, {
        client_id: String(body.client_id ?? ""),
        client_secret: String(body.client_secret ?? ""),
        webhook_id: String(body.webhook_id ?? ""),
      });
      return json(saved);
    }
    if (method === "GET" && path === "/payout-providers") {
      const state = await loadAppState(userId);
      return json(state.providers);
    }
    if (method === "GET" && path === "/connectors") {
      return json(await listConnectors(userId));
    }
    if (method === "GET" && path === "/scanner/status") {
      const state = await loadAppState(userId);
      return json(state.scanner);
    }
    if (method === "GET" && path === "/opportunities") {
      const stationId = url.searchParams.get("station_id");
      return json(await listOpportunities(userId, stationId ? Number(stationId) : undefined));
    }

    const stationGet = path.match(/^\/stations\/(\d+)$/);
    if (method === "GET" && stationGet) {
      const state = await loadAppState(userId);
      const s = state.stations.find((x) => x.id === Number(stationGet[1]));
      if (!s) return err("Station not found", 404);
      return json(s);
    }

    const control = path.match(/^\/stations\/control\/([a-z]+)$/);
    if (method === "POST" && control) {
      return json(await withOwnerSql(userId, (sql) => masterControl(sql, userId, control[1])));
    }

    const stationAct = path.match(/^\/stations\/(\d+)\/([a-z]+)$/);
    if (method === "POST" && stationAct) {
      if (stationAct[2] === "scan") {
        return json(await scanStation(userId, Number(stationAct[1])));
      }
      return json(
        await withOwnerSql(userId, (sql) =>
          controlStation(sql, userId, Number(stationAct[1]), stationAct[2]),
        ),
      );
    }

    if (method === "POST" && path === "/destinations") {
      const body = await bodyOf(request);
      return json(
        await withOwnerSql(userId, (sql) =>
          addDestination(sql, userId, {
            type: String(body.type ?? ""),
            label: String(body.label ?? ""),
            external_id: String(body.external_id ?? ""),
          }),
        ),
      );
    }

    if (method === "POST" && path === "/withdrawals") {
      const body = await bodyOf(request);
      return json(
        await withOwnerSql(userId, (sql) =>
          requestTransfer(sql, userId, {
            amount: Number(body.amount),
            destination_id: Number(body.destination_id),
            idempotency_key: String(body.idempotency_key ?? crypto.randomUUID()),
          }),
        ),
      );
    }

    if (method === "POST" && path === "/collections") {
      const body = await bodyOf(request);
      return json(
        await recordStationCollection(userId, {
          station_id: Number(body.station_id),
          title: String(body.title ?? ""),
          amount: Number(body.amount),
          evidence: body.evidence ? String(body.evidence) : undefined,
        }),
      );
    }

    if (method === "POST" && path === "/opportunities/manual") {
      const body = await bodyOf(request);
      return json(
        await addOpportunity(userId, {
          station_id: Number(body.station_id),
          title: String(body.title ?? ""),
          source_url: body.source_url ? String(body.source_url) : undefined,
          estimated_value:
            body.estimated_value == null ? null : Number(body.estimated_value),
          evidence: body.evidence ? String(body.evidence) : undefined,
        }),
      );
    }

    const verify = path.match(/^\/opportunities\/(\d+)\/verify$/);
    if (method === "POST" && verify) {
      const body = await bodyOf(request);
      return json(
        await verifyOpportunity(userId, {
          opportunity_id: Number(verify[1]),
          verified_value: Number(body.verified_value),
          evidence: String(body.evidence ?? ""),
        }),
      );
    }

    const conn = path.match(/^\/connectors\/(\d+)$/);
    if (method === "POST" && conn) {
      const body = await bodyOf(request);
      return json(
        await saveConnector(userId, {
          station_id: Number(conn[1]),
          connector_type: String(body.connector_type ?? "http_json"),
          endpoint: String(body.endpoint ?? ""),
          enabled: Boolean(body.enabled),
        }),
      );
    }

    const note = path.match(/^\/notifications\/(\d+)\/read$/);
    if (method === "POST" && note) {
      return json(await markNotificationRead(userId, Number(note[1])));
    }

    return err("Not found", 404);
  } catch (e) {
    if (e instanceof GmmError) return err(e.message, e.status);
    const message = e instanceof Error ? e.message : "Server error";
    const status = (e as { status?: number } | null)?.status;
    if (status === 401 || message === "Unauthorized") return err("Unauthorized", 401);
    if (status === 403) return err("Forbidden", 403);
    if (/invalid credentials|unauthorized|invalid email or password/i.test(message)) {
      return err("Invalid credentials", 401);
    }
    return err(message, 500);
  }
}
