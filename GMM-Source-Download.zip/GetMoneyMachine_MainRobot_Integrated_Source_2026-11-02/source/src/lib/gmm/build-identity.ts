/** Stable identity baked into the approved Get Money Machine New web build. */
export const GMM_BUILD_ID = "get-money-machine-new-2026-11-07";
