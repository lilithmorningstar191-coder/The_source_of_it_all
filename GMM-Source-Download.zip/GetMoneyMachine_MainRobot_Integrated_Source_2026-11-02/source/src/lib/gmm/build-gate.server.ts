import { GMM_BUILD_ID } from "./build-identity";

/**
 * Owner-controlled gate. It remains OFF unless explicitly enabled in Render.
 * When enabled, only the approved build identity may use owner operations.
 */
export function assertApprovedGmmBuild(suppliedBuildId: unknown): void {
  if (process.env.GMM_KILL_SWITCH_ENABLED?.trim().toLowerCase() !== "true") return;

  const configured = process.env.GMM_ALLOWED_BUILD_ID?.trim();
  const allowedBuildId = configured || GMM_BUILD_ID;
  if (suppliedBuildId !== allowedBuildId) {
    const error = new Error("This Get Money Machine build has been disabled. Open Get Money Machine New.") as Error & { status: number };
    error.status = 426;
    throw error;
  }
}
