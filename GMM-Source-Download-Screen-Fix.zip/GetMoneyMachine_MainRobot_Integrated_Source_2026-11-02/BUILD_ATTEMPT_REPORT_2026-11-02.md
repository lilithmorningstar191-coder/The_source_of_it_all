# GMM build attempt report — 2026-11-02

## Base APK identity
- Supplied original APK archive: `get-money-machine.apk.zip`
- SHA-256: `77dde3d062f66dbdf2c77a5ba3dbfbdc8545f518e88eaa68e51877c2595748bc`
- ZIP/APK integrity: `unzip -t` passed.
- The same bytes are preserved as `main-apk/GetMoneyMachine-original-base.apk`.

## Source regression tests
- Command: `node --test 'scripts/**/*.test.mjs'`
- Result: 200 tests passed, 0 failed.
- Scope: repository script/regression tests only; not Android compilation or device acceptance.

## Android build attempt
- Command: `sh gradlew :app:assembleRelease --no-daemon`
- Result: blocked before Gradle configuration/build.
- Cause: Gradle wrapper could not download Gradle 8.9 from `services.gradle.org`; DNS/network resolution failed (`UnresolvedAddressException`).
- Android SDK platform 35/build-tools and `android.jar` are also absent from this environment.
- No new APK was produced. The original APK remains unchanged.

## Release blockers found in source
- Native `MainActivity.kt` calls `MainShell("")`; no PIN entry/authentication flow supplies a bearer session token.
- The Android source has no PIN/session implementation; the backend worker secret is separate and must never be embedded in the APK.
- Android station labels/data naming do not yet match the owner's exact 15 requested station display names.
- The worker scheduler code is present but is not deployed or activated; it requires server-side owner ID and worker secret configuration and an independent scheduler service.
- No release keystore/signing material is present. A release-signed update requires the original signing key; without it, an APK signed with a different key will not update an existing installation in place.
- No production deployment, database mutation, or live payment/transfer was performed.

## Honest status
Source regression tests passed. The requested repaired, installable Android APK is **not built or verified**. Do not treat the preserved original APK as the repaired release.
