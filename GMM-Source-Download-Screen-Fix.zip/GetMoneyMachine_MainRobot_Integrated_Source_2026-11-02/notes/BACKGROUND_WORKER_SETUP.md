# GMM persistent background station scheduler

The API now exposes `POST /api/gmm/internal/worker/tick`. It is deliberately separate from dashboard requests and money-transfer endpoints. It only advances due station scans for the single owner configured by `GMM_OWNER_USER_ID`; it cannot create a withdrawal, call PayPal/Stripe, or change the ledger balance.

## Required API service environment

Set these server-side on the existing GMM API service (never in the APK):

- `GMM_OWNER_USER_ID`: the exact authenticated owner ID from the production auth database.
- `GMM_WORKER_SECRET`: a newly generated high-entropy secret (at least 32 random bytes).

Do not guess the owner ID. Do not reuse a PayPal credential or an app PIN as the worker secret.

## Scheduler service

Create a Render Cron Job using the same audited source revision and Node runtime as the API. Set its schedule to `*/15 * * * *` (every 15 minutes), command to `npm run worker:tick`, and environment variables:

- `GMM_API_URL=https://wise-minds-creation-api.onrender.com`
- `GMM_WORKER_SECRET` = the exact same secret configured on the API service.

The API's `GMM_OWNER_USER_ID` stays only on the API service. Do not put database credentials or payment-provider credentials on the cron job. The cron job must be configured only after the API revision containing this route is deployed.

## Behavior and safety

- The backend, not the phone, owns the schedule. It runs while the app is closed and the phone is off.
- The worker processes only stations already enabled, active, unpaused, not emergency-stopped, and due by `next_cycle_at`.
- Existing `tickCycles` logic advances the next cycle by 90 minutes.
- Discovery results do not become earnings or cash automatically. Existing evidence/owner-confirmation rules remain in force.
- The endpoint fails closed when either server environment variable is missing or the secret is wrong.
- This is a scheduler integration, not a source-of-funds connector. It does not connect a funding account or send money.

## Release gate

Before enabling the cron job, verify the exact owner ID from the production auth record, deploy the API route, call the endpoint once with the secret, inspect the worker result and station event log, then create the 15-minute cron job. Do not activate it against a database until the owner ID is confirmed.
