# GMM Ledger API status endpoint patch

## What this patch adds

- `GET /api/gmm/account/status`, protected by the existing signed-session user authentication.
- Identifies the internal account as `GMM_LEDGER` / `GMM Ledger`.
- Reports which database backend answered the query (`neon` or embedded `pglite`), ledger-record totals, opening-balance records, station count, and withdrawals grouped by status.
- Reports whether the native settlement endpoint is configured, without exposing secrets.
- Explicitly separates recorded ledger accounting from verified external cash; it never labels ledger records as cash-backed or claims a live transfer succeeded.
- Adds database-backend information to the existing health response.

## Endpoint

`GET /api/gmm/account/status`

Requires the existing authenticated GMM session. It does not accept a client-supplied user ID.

## Important limitations

This is source-code work only. It does not deploy itself to the live app, connect to a production database, recover production credentials, or create cash. `production_database_confirmed: true` means only that the configured backend type is Neon and a query returned; deployment identity and external cash backing still require independent operational verification. `native_settlement_configured: true` means only that the server has the two native-settlement environment variables; it does not prove the endpoint is reachable or that a transfer executes.

The endpoint is read-only. Existing withdrawal processing remains protected by owner authentication and idempotency handling. No Stripe, PayPal, or other third-party credentials are added by this patch.
