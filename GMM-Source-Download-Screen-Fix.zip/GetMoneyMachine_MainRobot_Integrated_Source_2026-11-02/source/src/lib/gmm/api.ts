import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  addDestination,
  addOpportunity,
  controlStation,
  GmmError,
  listAudit,
  listConnectors,
  listLedger,
  listOpportunities,
  loadAppState,
  markNotificationRead,
  masterControl,
  recordStationCollection,
  requestTransfer,
  saveConnector,
  savePaypalRail,
  scanStation,
  verifyOpportunity,
  withOwnerSql,
} from "./core";

const ownerMiddleware = authMiddleware;

function rethrow(err: unknown): never {
  if (err instanceof GmmError) throw err;
  throw err;
}

export const getAppState = createServerFn({ method: "GET" })
  .middleware([ownerMiddleware])
  .handler(async ({ context }) => loadAppState(context.userId));

export const postStationAction = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { id: number; action: string }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await withOwnerSql(context.userId, (sql) =>
        controlStation(sql, context.userId, data.id, data.action),
      );
    } catch (err) {
      rethrow(err);
    }
  });

export const postMasterAction = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { action: string }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await withOwnerSql(context.userId, (sql) =>
        masterControl(sql, context.userId, data.action),
      );
    } catch (err) {
      rethrow(err);
    }
  });

export const postTransfer = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { amount: number; destination_id: number; idempotency_key: string }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await withOwnerSql(context.userId, (sql) =>
        requestTransfer(sql, context.userId, data),
      );
    } catch (err) {
      rethrow(err);
    }
  });

export const postDestination = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { type: string; label: string; external_id: string }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await withOwnerSql(context.userId, (sql) =>
        addDestination(sql, context.userId, data),
      );
    } catch (err) {
      rethrow(err);
    }
  });

export const getLedger = createServerFn({ method: "GET" })
  .middleware([ownerMiddleware])
  .handler(async ({ context }) => listLedger(context.userId));

export const getAuditLog = createServerFn({ method: "GET" })
  .middleware([ownerMiddleware])
  .handler(async ({ context }) => listAudit(context.userId));

export const getConnectors = createServerFn({ method: "GET" })
  .middleware([ownerMiddleware])
  .handler(async ({ context }) => listConnectors(context.userId));

export const postConnector = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator(
    (data: { station_id: number; connector_type: string; endpoint: string; enabled: boolean }) =>
      data,
  )
  .handler(async ({ context, data }) => {
    try {
      return await saveConnector(context.userId, data);
    } catch (err) {
      rethrow(err);
    }
  });

export const getOpportunitiesFn = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { station_id?: number } = {}) => data)
  .handler(async ({ context, data }) => listOpportunities(context.userId, data.station_id));

export const postOpportunity = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator(
    (data: {
      station_id: number;
      title: string;
      source_url?: string;
      estimated_value?: number | null;
      evidence?: string;
    }) => data,
  )
  .handler(async ({ context, data }) => {
    try {
      return await addOpportunity(context.userId, data);
    } catch (err) {
      rethrow(err);
    }
  });

export const postCollection = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator(
    (data: { station_id: number; title: string; amount: number; evidence?: string }) => data,
  )
  .handler(async ({ context, data }) => {
    try {
      return await recordStationCollection(context.userId, data);
    } catch (err) {
      rethrow(err);
    }
  });

export const postVerifyOpportunity = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { opportunity_id: number; verified_value: number; evidence: string }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await verifyOpportunity(context.userId, data);
    } catch (err) {
      rethrow(err);
    }
  });

export const postPaypalRail = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator(
    (data: { client_id: string; client_secret: string; webhook_id: string }) => data,
  )
  .handler(async ({ context, data }) => {
    try {
      return await savePaypalRail(context.userId, data);
    } catch (err) {
      rethrow(err);
    }
  });

export const postScan = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { station_id: number }) => data)
  .handler(async ({ context, data }) => {
    try {
      return await scanStation(context.userId, data.station_id);
    } catch (err) {
      rethrow(err);
    }
  });

export const postReadNotification = createServerFn({ method: "POST" })
  .middleware([ownerMiddleware])
  .validator((data: { id: number }) => data)
  .handler(async ({ context, data }) => markNotificationRead(context.userId, data.id));
