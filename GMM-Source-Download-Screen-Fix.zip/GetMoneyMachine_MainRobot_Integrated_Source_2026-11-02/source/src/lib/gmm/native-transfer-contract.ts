export type NativeTransferStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";

export type NativeTransferResponse = {
  status: NativeTransferStatus;
  reference: string;
  message?: string;
  source_funds_verified: true;
  amount: string;
  currency: "USD";
  destination_receipt_confirmed?: true;
  destination_receipt_reference?: string;
};

/** Fail closed unless the settlement service attests to the exact requested transfer. */
export function validateNativeTransferResponse(
  value: unknown,
  expected: { amount: string; currency: "USD" },
): NativeTransferResponse {
  if (!value || typeof value !== "object") throw new Error("GMM settlement response is not an object.");
  const body = value as Record<string, unknown>;
  const status = String(body.status ?? "").toUpperCase();
  if (!["PENDING", "PROCESSING", "COMPLETED", "FAILED"].includes(status)) {
    throw new Error("GMM settlement response has an invalid status.");
  }
  if (typeof body.reference !== "string" || !body.reference.trim()) {
    throw new Error("GMM settlement response has no stable reference.");
  }
  if (body.source_funds_verified !== true) {
    throw new Error("GMM settlement service did not verify cleared source funds.");
  }
  if (String(body.amount ?? "") !== expected.amount || body.currency !== expected.currency) {
    throw new Error("GMM settlement response does not match the requested amount and currency.");
  }
  if (status === "COMPLETED" && (body.destination_receipt_confirmed !== true || typeof body.destination_receipt_reference !== "string" || !body.destination_receipt_reference.trim())) {
    throw new Error("GMM settlement cannot report COMPLETED without a confirmed destination receipt.");
  }
  return {
    status: status as NativeTransferStatus,
    reference: body.reference.trim(),
    message: typeof body.message === "string" ? body.message : undefined,
    source_funds_verified: true,
    amount: expected.amount,
    currency: expected.currency,
    destination_receipt_confirmed: body.destination_receipt_confirmed === true ? true : undefined,
    destination_receipt_reference: typeof body.destination_receipt_reference === "string" ? body.destination_receipt_reference : undefined,
  };
}
