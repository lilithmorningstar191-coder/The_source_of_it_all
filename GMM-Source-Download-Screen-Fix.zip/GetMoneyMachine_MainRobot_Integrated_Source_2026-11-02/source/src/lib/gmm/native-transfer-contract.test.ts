import test from "node:test";
import assert from "node:assert/strict";
import { validateNativeTransferResponse } from "./native-transfer-contract.ts";

const expected = { amount: "2.50", currency: "USD" as const };
const base = {
  status: "PROCESSING",
  reference: "gmm-settle-123",
  source_funds_verified: true,
  amount: "2.50",
  currency: "USD",
};

test("accepts a referenced in-progress settlement only when source funds and amount match", () => {
  assert.equal(validateNativeTransferResponse(base, expected).status, "PROCESSING");
});

test("rejects settlement without explicit source-funds verification", () => {
  assert.throws(() => validateNativeTransferResponse({ ...base, source_funds_verified: false }, expected), /did not verify cleared source funds/);
});

test("rejects mismatched amount or currency", () => {
  assert.throws(() => validateNativeTransferResponse({ ...base, amount: "250.00" }, expected), /does not match/);
  assert.throws(() => validateNativeTransferResponse({ ...base, currency: "EUR" }, expected), /does not match/);
});

test("rejects completed status without independently identified destination receipt", () => {
  assert.throws(() => validateNativeTransferResponse({ ...base, status: "COMPLETED" }, expected), /without a confirmed destination receipt/);
});

test("accepts completed only with destination receipt confirmation and reference", () => {
  const result = validateNativeTransferResponse({ ...base, status: "COMPLETED", destination_receipt_confirmed: true, destination_receipt_reference: "dest-receipt-456" }, expected);
  assert.equal(result.status, "COMPLETED");
  assert.equal(result.destination_receipt_reference, "dest-receipt-456");
});

test("rejects missing or unstable settlement references", () => {
  assert.throws(() => validateNativeTransferResponse({ ...base, reference: " " }, expected), /no stable reference/);
});
