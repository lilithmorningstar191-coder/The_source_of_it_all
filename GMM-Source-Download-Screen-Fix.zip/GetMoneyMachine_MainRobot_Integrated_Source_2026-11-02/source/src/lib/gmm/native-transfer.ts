import { env } from "@/lib/env.server";
import { validateNativeTransferResponse } from "./native-transfer-contract";

export type NativeTransferResult = {
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";
  reference: string;
  message?: string;
};

/**
 * Calls GMM's own authorized source-to-destination settlement service. This is
 * deliberately provider-neutral: it does not use PayPal Payouts, Stripe, or a
 * new payout provider. The remote service must verify real available funds,
 * enforce idempotency, and return a settlement reference.
 */
export async function executeGmmNativeTransfer(input: {
  userId: string; amount: string; currency: "USD"; destinationType: string;
  destinationId: string; idempotencyKey: string; withdrawalId: number;
}): Promise<NativeTransferResult> {
  const endpoint = env("GMM_NATIVE_TRANSFER_URL");
  const secret = env("GMM_NATIVE_TRANSFER_SECRET");
  if (!endpoint || !secret) {
    throw new Error("GMM native settlement is not configured. No transfer was sent.");
  }
  const url = new URL(endpoint);
  if (url.protocol !== "https:" && url.hostname !== "localhost" && url.hostname !== "127.0.0.1") {
    throw new Error("GMM native settlement endpoint must use HTTPS.");
  }
  const response = await fetch(url, {
    method: "POST",
    headers: { "Authorization": `Bearer ${secret}`, "Content-Type": "application/json",
      "Accept": "application/json", "Idempotency-Key": input.idempotencyKey },
    body: JSON.stringify({
      source: "GMM_LEDGER", destination_type: input.destinationType,
      destination_id: input.destinationId, amount: input.amount, currency: input.currency,
      idempotency_key: input.idempotencyKey, withdrawal_id: input.withdrawalId,
      user_reference: input.userId,
    }),
    signal: AbortSignal.timeout(20000),
  });
  const body = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    // Treat timeouts/server errors as ambiguous at the caller; never retry with a new key.
    throw new Error(`GMM settlement service returned HTTP ${response.status}: ${typeof body.message === "string" ? body.message : "request not confirmed"}`);
  }
  return validateNativeTransferResponse(body, { amount: input.amount, currency: input.currency });
}
