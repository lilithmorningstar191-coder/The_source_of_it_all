/** Canonical internal financial-provider identity used by the entire GMM app. */
export const FINANCIAL_PROVIDER_ID = "GMM_LEDGER" as const;
export const FINANCIAL_PROVIDER_NAME = "GMM Ledger" as const;
export const EXTERNAL_EXECUTION_RAILS = ["STRIPE_CONNECT", "PAYPAL"] as const;

export const CYCLE_MINUTES = 90;

/** Locked GMM money-flow contract. Never infer direction from the selected destination. */
export const GMM_TRANSFER_FLOW = {
  source: "GMM_LEDGER",
  destination: "PAYPAL_RECEIVING_ACCOUNT",
  requiresCeoAuthorization: true,
  receiptVerification: "AUTOMATIC_PROVIDER_CONFIRMATION",
  successRequiresProviderReceipt: true,
} as const;

export function assertGmmTransferFlow(input: {
  source: string; destination: string; ceoConfirmed: boolean; providerReceiptConfirmed?: boolean;
}) {
  if (input.source !== GMM_TRANSFER_FLOW.source) throw new Error("Transfer source must be GMM Ledger.");
  if (input.destination !== GMM_TRANSFER_FLOW.destination) throw new Error("Transfer destination must be the connected PayPal receiving account.");
  if (GMM_TRANSFER_FLOW.requiresCeoAuthorization && input.ceoConfirmed !== true) throw new Error("CEO authorization is required.");
  if (input.providerReceiptConfirmed !== true) return { authorized: true, successful: false as const, status: "AWAITING_PROVIDER_RECEIPT" as const };
  return { authorized: true, successful: true as const, status: "SUCCESSFUL_TRANSFER" as const };
}


const CORE_STATION_NAMES = [
  "Free Money Finder",
  "Unclaimed Funds",
  "Refund Recovery",
  "Rebate Finder",
  "Cashback Hub",
  "Rewards Hub",
  "Bonus Finder",
  "Fee Recovery",
  "Overpayment Recovery",
  "Subscription Credits",
  "Claims & Settlements",
  "Business Incentives",
  "Public Funds Finder",
  "Revenue Finder",
  "Reinvestment",
] as const;

/** Short display labels for the original 15 Field Team Stations. IDs, categories, order, and allocations remain unchanged. */
export const STATION_NAMES = CORE_STATION_NAMES;

const CORE_STATION_BLURBS = [
  "Find legitimate, verified opportunities to receive money at no upfront cost.",
  "Find public/state unclaimed money and property.",
  "Find refunds, reimbursements, and returned payments.",
  "Find eligible rebates and verified rebate programs.",
  "Find legitimate cashback opportunities.",
  "Find verified rewards and incentive programs.",
  "Find legitimate promotional bonus programs.",
  "Find recoverable fees and fee credits.",
  "Find verified overpayment recovery opportunities.",
  "Find legitimate subscription credits.",
  "Find verified settlements and claims.",
  "Find legitimate business incentives.",
  "Find public opportunities from legitimate sources.",
  "Find legitimate revenue opportunities.",
  "Manage verified reinvestment activity.",
] as const;

export const STATION_BLURBS = CORE_STATION_BLURBS;
export const FIELD_TEAM_STATION_COUNT = 15 as const;

export const DESTINATION_TYPES = [
  ["PAYPAL", "PayPal"],
  ["STRIPE_CONNECT", "Stripe Connect"],
] as const;

export const DESTINATION_HINTS: Record<string, string> = {
  STRIPE_CONNECT: "Stripe Connect connected account ID (acct_...). The recipient must complete Stripe onboarding.",
  PAYPAL: "PayPal recipient email",
  ACH: 'JSON: {"access_token":"...","account_id":"...","legal_name":"...","network":"ach","ach_class":"ppd"}',
  ONEPAY:
    "JSON: Plaid access_token/account_id for the linked OnePay account",
  CASH_APP: 'JSON: {"merchant_id":"...","customer_id":"...","grant_id":"..."}',
  DEBIT_CARD:
    "JSON with recipient_primary_account_number or recipient_payment_credential_reference",
};

export const CONTROL_ACTIONS = [
  "start",
  "stop",
  "pause",
  "emergency",
  "enable",
  "disable",
] as const;

export type ControlAction = (typeof CONTROL_ACTIONS)[number];
