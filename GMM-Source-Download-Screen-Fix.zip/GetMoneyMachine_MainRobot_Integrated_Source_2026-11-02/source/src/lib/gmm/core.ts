import { getSql, type Sql } from "@/lib/db";
import { dbSource } from "@/lib/db";
import {
  CONTROL_ACTIONS,
  CYCLE_MINUTES,
  STATION_NAMES,
  FINANCIAL_PROVIDER_ID,
  FINANCIAL_PROVIDER_NAME,
  type ControlAction,
} from "./constants";
import { providerStatusMap, paypalConfigured, paypalClientId, paypalClientSecret, paypalWebhookId, stripeConfigured, gmmNativeTransferConfigured } from "./env";
import { executeGmmNativeTransfer } from "./native-transfer";
import { createStripeConnectTransfer, readStripeBalance } from "./stripe";
import { asBool, asInt, asMoney, iso, moneyNumber, toCents } from "./money";
import {
  assertPaypalCredentials,
  createPaypalCheckoutOrder,
  capturePaypalCheckoutOrder,
  assertPaypalWebhook,
  getPaypalPayout,
  findPaypalIncomingCredit,
  findRecentPaypalIncomingCredit,
  readPaypalBalance,
  paypalLiveEnv,
} from "./paypal";
import type {
  AppState,
  AuditRow,
  BalanceState,
  ConnectorState,
  DestinationState,
  LedgerRow,
  NotificationRow,
  OpportunityState,
  ProviderBalanceState,
  StationState,
  WithdrawalState,
} from "./types";

type StationRow = Record<string, unknown>;

export class GmmError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

async function audit(sql: Sql, userId: string, action: string, detail: string) {
  await sql`insert into gmm_audit (user_id, action, detail) values (${userId}, ${action}, ${detail})`;
}

async function notify(
  sql: Sql,
  userId: string,
  kind: string,
  title: string,
  message: string,
) {
  await sql`insert into gmm_notifications (user_id, kind, title, message) values (${userId}, ${kind}, ${title}, ${message})`;
}

async function stationEvent(
  sql: Sql,
  userId: string,
  stationId: number,
  eventType: string,
  status: string,
  detail = "",
) {
  await sql`insert into gmm_station_events (user_id, station_id, event_type, status, detail)
    values (${userId}, ${stationId}, ${eventType}, ${status}, ${detail})`;
}

export async function ensureOwner(sql: Sql, userId: string) {
  // Rename legacy station labels in place by stable sort order. This preserves station IDs
  // and every connector, event, opportunity, earnings, and ledger foreign-key reference.
  const renamed = [
    "Free Money Finder", "Unclaimed Funds", "Refund Recovery", "Rebate Finder",
    "Cashback Hub", "Rewards Hub", "Bonus Finder", "Fee Recovery",
    "Overpayment Recovery", "Subscription Credits", "Claims & Settlements",
    "Business Incentives", "Public Funds Finder", "Revenue Finder", "Reinvestment",
  ];
  for (let i = 0; i < renamed.length; i += 1) {
    await sql`update gmm_stations set name = ${renamed[i]}
      where user_id = ${userId} and sort_order = ${i + 1}
      and name <> ${renamed[i]}
      and not exists (select 1 from gmm_stations existing
        where existing.user_id = ${userId} and existing.name = ${renamed[i]})`;
  }
  // Ensure every required station exists even for databases created by an older build.
  // Stable sort order and station IDs remain the foreign-key target.
  for (let i = 0; i < STATION_NAMES.length; i += 1) {
    const name = STATION_NAMES[i];
    await sql`insert into gmm_stations (user_id, name, sort_order)
      values (${userId}, ${name}, ${i + 1})
      on conflict (user_id, name) do nothing`;
    await sql`update gmm_stations set sort_order = ${i + 1}
      where user_id = ${userId} and name = ${name}`;
  }
  const stations = await sql<{ id: number; name: string }>`
    select id, name from gmm_stations where user_id = ${userId}
      and name <> 'Earnings & Transfer Station' order by sort_order`;
  for (const s of stations) {
    await sql`insert into gmm_connectors (user_id, station_id, connector_type, enabled)
      values (${userId}, ${s.id}, 'http_json', false)
      on conflict (user_id, station_id) do nothing`;
  }
  await sql`insert into gmm_account_locks (user_id, name)
    values (${userId}, 'owner-financial-lock')
    on conflict (user_id) do nothing`;

  await sql`create table if not exists gmm_funding_sources (
    id serial primary key,
    user_id text not null unique,
    kind text not null,
    label text not null,
    provider text,
    provider_account_id text,
    account_number text,
    routing_number text,
    created_at timestamptz not null default now()
  )`;
  await sql`alter table gmm_withdrawals add column if not exists funding_source_id integer`;
  await sql`create table if not exists gmm_rail_secrets (
    provider text primary key,
    client_id text not null,
    client_secret text not null,
    webhook_id text,
    updated_at timestamptz not null default now()
  )`;
  await sql`insert into gmm_funding_sources (user_id, kind, label)
    values (${userId}, 'GMM_LEDGER_ORCHESTRATOR', 'GMM Ledger — internal financial provider and authoritative ledger; Stripe/PayPal are external execution rails')
    on conflict (user_id) do nothing`;
  // Canonical internal financial provider: GMM Ledger. Every payout persists the invariant orchestrator=GMM_LEDGER. It owns authorization,
  // accounting, reservations, idempotency, and reconciliation. Stripe/PayPal are
  // external execution rails whose supported funding requirements still apply.
  // Normalize legacy labels so every component uses the same provider identity.
  await sql`update gmm_funding_sources
    set kind = 'GMM_LEDGER_ORCHESTRATOR', label = 'GMM Ledger — internal financial provider and authoritative ledger; Stripe/PayPal are external execution rails'
    where user_id = ${userId} and kind in ('LEDGER', 'PROVIDER_BALANCES', 'GMM_LEDGER_ORCHESTRATOR')`;

  // IMPORTANT: station discovery and estimates never create money. New collection
  // income is recorded only after the owner confirms a completed collection with
  // traceable evidence. Migration 0006 restores the existing individual station
  // funding records removed by an earlier migration; it never creates an aggregate
  // opening-balance record. Provider-confirmed external liquidity remains separate.
}

function stationStatus(row: StationRow): StationState["status"] {
  if (asBool(row.emergency_stopped)) return "EMERGENCY STOPPED";
  if (asBool(row.paused)) return "PAUSED";
  if (asBool(row.active)) return "RUNNING";
  return "STOPPED";
}

function mapStation(row: StationRow): StationState {
  return {
    id: asInt(row.id),
    name: String(row.name),
    enabled: asBool(row.enabled),
    active: asBool(row.active),
    paused: asBool(row.paused),
    emergency_stopped: asBool(row.emergency_stopped),
    status: stationStatus(row),
    last_activity: iso(row.last_activity),
    last_scan_at: iso(row.last_scan_at),
    cycle_started_at: iso(row.cycle_started_at),
    next_cycle_at: iso(row.next_cycle_at),
    cycle_count: asInt(row.cycle_count),
    cycle_minutes: CYCLE_MINUTES,
    paused_remaining_seconds: asInt(row.paused_remaining_seconds),
    station_earnings: asMoney(row.station_earnings),
    completed_collections: asInt(row.completed_collections),
  };
}

function publicHttpsUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new GmmError("A valid HTTPS source endpoint is required");
  }
  if (url.protocol !== "https:") {
    throw new GmmError("Connector must use HTTPS");
  }
  const host = url.hostname.toLowerCase();
  if (
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "::1" ||
    host.endsWith(".local") ||
    host === "0.0.0.0"
  ) {
    throw new GmmError("Private hosts are not allowed");
  }
  const ipv4 = host.match(/^(\d{1,3}\.){3}\d{1,3}$/);
  if (ipv4) {
    const p = host.split(".").map(Number);
    const priv =
      p[0] === 10 ||
      p[0] === 127 ||
      p[0] === 0 ||
      (p[0] === 192 && p[1] === 168) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 169 && p[1] === 254);
    if (priv) throw new GmmError("Private hosts are not allowed");
  }
  return url;
}

async function creditCompletedCollection(
  sql: Sql,
  userId: string,
  input: { stationId: number; opportunityId: number; amount: string; title: string },
) {
  const reference = `collection:${input.opportunityId}`;
  const existing = await sql`select id from gmm_ledger
    where user_id = ${userId} and provider_reference = ${reference} limit 1`;
  if (existing.length) return;
  const [station] = await sql`select name from gmm_stations where id = ${input.stationId} and user_id = ${userId}`;
  const stationName = station ? String(station.name) : `Station ${input.stationId}`;
  const description = `${stationName}. ${input.title}. Reported collection: $${input.amount}. Accounting record only; spendable and transferable cash is read from live payment-provider balances.`;
  await sql`insert into gmm_ledger
    (user_id, kind, station_id, amount, status, description, provider_reference)
    values (${userId}, 'STATION_COLLECTION', ${input.stationId}, ${input.amount}, 'COMPLETED', ${description}, ${reference})`;
  await sql`update gmm_opportunities
    set state = 'COMPLETED', verified_value = ${input.amount}, updated_at = now()
    where id = ${input.opportunityId} and user_id = ${userId}`;
  await stationEvent(sql, userId, input.stationId, "COLLECTION", "COMPLETED", description);
  await notify(sql, userId, "collection.completed", "Station collection credited", description);
  await audit(sql, userId, "collection.completed", `opportunity=${input.opportunityId};amount=${input.amount};cash_balance_unchanged=true`);
}

async function runScan(sql: Sql, userId: string, stationId: number) {
  const [station] = await sql`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  await sql`update gmm_stations set last_scan_at = now() where id = ${stationId} and user_id = ${userId}`;
  const [connector] = await sql`select * from gmm_connectors where station_id = ${stationId} and user_id = ${userId}`;
  if (!connector || !asBool(connector.enabled) || !connector.endpoint) {
    await stationEvent(
      sql,
      userId,
      stationId,
      "SCAN",
      "NOT_CONFIGURED",
      "No real external source connector configured",
    );
    return { status: "not_configured" as const, results: [] as OpportunityState[], fabricated_results: false };
  }
  try {
    // Every station scan asks its configured source for worldwide results. The endpoint
    // must honor these query parameters and return JSON opportunities; this keeps the
    // search scope global instead of silently defaulting to the user's local region.
    const url = publicHttpsUrl(String(connector.endpoint));
    const stationName = String(station.name);
    const globalQueries: Record<string, string> = {
      "Free Money Finder": "legitimate grants benefits financial assistance worldwide",
      "Unclaimed Funds": "unclaimed property money assets government worldwide",
      "Refund Recovery": "consumer refunds tax refunds fee refunds worldwide",
      "Rebate Finder": "manufacturer rebates consumer rebates worldwide",
      "Cashback Hub": "cashback offers purchase rewards worldwide",
      "Rewards Hub": "loyalty rewards points redemption worldwide",
      "Bonus Finder": "promotional bonuses signup offers worldwide",
      "Fee Recovery": "bank service fee refunds fee recovery worldwide",
      "Overpayment Recovery": "overpayment refunds utility insurance billing worldwide",
      "Subscription Credits": "subscription refunds credits cancellations worldwide",
      "Claims & Settlements": "class action settlements consumer claims worldwide",
      "Business Incentives": "small business grants incentives programs worldwide",
      "Public Funds Finder": "public grants tenders and assistance programs worldwide",
      "Revenue Finder": "legitimate revenue opportunities worldwide",
      "Reinvestment": "reinvestment programs dividends eligible opportunities worldwide",
    };
    url.searchParams.set("scope", "worldwide");
    url.searchParams.set("region", "global");
    url.searchParams.set("countries", "all");
    url.searchParams.set("station", stationName);
    url.searchParams.set("query", globalQueries[stationName] ?? `${stationName} worldwide`);
    url.searchParams.set("currency", "USD");
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), 15000);
    const res = await fetch(url, { signal: ac.signal, redirect: "error" });
    clearTimeout(t);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const payload = (await res.json()) as unknown;
    const items = Array.isArray(payload)
      ? payload
      : payload && typeof payload === "object" && Array.isArray((payload as { opportunities?: unknown }).opportunities)
        ? ((payload as { opportunities: unknown[] }).opportunities)
        : [];
    const results: OpportunityState[] = [];
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const rec = item as Record<string, unknown>;
      if (!rec.title) continue;
      const estimated = rec.estimated_value == null ? null : asMoney(rec.estimated_value);
      // A discovery connector is untrusted opportunity data, not a payment processor.
      // Its reported status/amount can never create a cash ledger entry.
      const collected: string | null = null;
      const sourceUrl = rec.source_url == null ? null : String(rec.source_url);
      const inserted = await sql<{ id: number }>`
        insert into gmm_opportunities (user_id, station_id, title, source_url, estimated_value, verified_value, state, evidence)
        values (
          ${userId}, ${stationId}, ${String(rec.title)}, ${sourceUrl}, ${estimated}, ${collected},
          ${collected ? "COMPLETED" : "DETECTED"}, 'External connector response'
        )
        returning id`;
      if (collected) {
        await creditCompletedCollection(sql, userId, {
          stationId,
          opportunityId: inserted[0].id,
          amount: collected,
          title: String(rec.title),
        });
      }
      const [row] = await sql`select * from gmm_opportunities where id = ${inserted[0].id} and user_id = ${userId}`;
      results.push(mapOpportunity(row));
    }
    await stationEvent(sql, userId, stationId, "SCAN", "COMPLETED", `${results.length} source records`);
    return { status: "completed" as const, results, fabricated_results: false };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await stationEvent(sql, userId, stationId, "SCAN", "ERROR", message);
    return { status: "error" as const, results: [] as OpportunityState[], fabricated_results: false, error: message };
  }
}

async function tickCycles(sql: Sql, userId: string) {
  const due = await sql<StationRow>`
    select * from gmm_stations
    where user_id = ${userId}
      and enabled = true
      and active = true
      and paused = false
      and emergency_stopped = false
      and next_cycle_at is not null
      and next_cycle_at <= now()`;
  for (const st of due) {
    const id = asInt(st.id);
    const result = await runScan(sql, userId, id);
    await sql`update gmm_stations
      set cycle_count = coalesce(cycle_count, 0) + 1,
          cycle_started_at = now(),
          next_cycle_at = now() + interval '90 minutes',
          last_activity = now()
      where id = ${id} and user_id = ${userId}`;
    await stationEvent(
      sql,
      userId,
      id,
      "CYCLE_COMPLETED",
      "COMPLETED",
      `results=${result.results.length}`,
    );
  }
}

type BalanceReservationRow = { provider: string; amount: unknown };

function noProviderBalance(
  status: "NOT_CONFIGURED" | "UNAVAILABLE",
  message: string | null = null,
): ProviderBalanceState {
  return {
    status,
    available: null,
    pending: null,
    spendable: "0.00",
    reserved: "0.00",
    as_of: null,
    message,
  };
}

export async function getBalance(sql: Sql, userId: string): Promise<BalanceState> {
  // GMM Ledger is the internal financial provider, system of record, and payout
  // orchestrator. It preserves its own accounting balance; external payout calls
  // must also satisfy the selected Stripe/PayPal rail's real funding requirements.
  const [completedRow] = await sql<{ v: unknown }>`
    select coalesce(sum(amount), 0) as v from gmm_ledger
    where user_id = ${userId} and status = 'COMPLETED'
      and kind in ('OPENING_BALANCE', 'STATION_COLLECTION', 'STATION_EARNINGS_IMPORT', 'TRANSFER_DEBIT', 'TRANSFER_REVERSAL')`;
  const reservationRows = await sql<BalanceReservationRow>`
    select upper(d.type) as provider, coalesce(sum(w.amount), 0) as amount
    from gmm_withdrawals w
    join gmm_destinations d on d.id = w.destination_id and d.user_id = w.user_id
    where w.user_id = ${userId}
      and w.status in ('PENDING', 'SUBMITTED', 'PROCESSING', 'RECONCILIATION_REQUIRED')
      and upper(d.type) in ('STRIPE_CONNECT', 'PAYPAL')
    group by upper(d.type)`;
  const reservedFor = (provider: string) =>
    asMoney(reservationRows.find((row) => String(row.provider).toUpperCase() === provider)?.amount ?? 0);

  let stripe: ProviderBalanceState = noProviderBalance("NOT_CONFIGURED");
  if (stripeConfigured()) {
    try {
      const snapshot = await readStripeBalance();
      const available = asMoney(snapshot.available_usd);
      const pending = asMoney(snapshot.pending_usd);
      const reserved = reservedFor("STRIPE_CONNECT");
      const live = snapshot.livemode;
      stripe = {
        status: live ? "LIVE" : "TEST_MODE",
        available,
        pending,
        spendable: live ? asMoney(Math.max(0, moneyNumber(available) - moneyNumber(reserved))) : "0.00",
        reserved: live ? reserved : "0.00",
        as_of: snapshot.as_of,
        message: live ? null : "Stripe is in test mode. These are simulated funds and cannot be deposited or paid out as real money.",
      };
    } catch {
      stripe = noProviderBalance("UNAVAILABLE", "Could not verify the live Stripe balance. No payout will be allowed through this rail until the balance can be read.");
    }
  }

  let paypal: ProviderBalanceState = noProviderBalance("NOT_CONFIGURED");
  const paypalCreds = await paypalRailCreds(sql);
  if (paypalCreds) {
    try {
      const snapshot = await readPaypalBalance(paypalCreds.clientId, paypalCreds.clientSecret);
      const available = asMoney(snapshot.available_usd);
      const pending = asMoney(snapshot.pending_usd);
      const reserved = reservedFor("PAYPAL");
      // PayPal's reporting balance endpoint can lag by up to three hours. Deduct
      // completed PayPal payouts created after the reporting snapshot so the
      // app does not immediately re-spend funds the old snapshot still shows.
      let recentCompleted = "0.00";
      if (snapshot.as_of) {
        const [row] = await sql<{ amount: unknown }>`
          select coalesce(sum(w.amount), 0) as amount
          from gmm_withdrawals w
          join gmm_destinations d on d.id = w.destination_id and d.user_id = w.user_id
          where w.user_id = ${userId}
            and upper(d.type) = 'PAYPAL'
            and w.status = 'COMPLETED'
            and w.created_at > ${snapshot.as_of}::timestamptz`;
        recentCompleted = asMoney(row?.amount ?? 0);
      }
      const spendable = Math.max(0, moneyNumber(available) - moneyNumber(reserved) - moneyNumber(recentCompleted));
      paypal = {
        status: "LIVE",
        available,
        pending,
        spendable: asMoney(spendable),
        reserved: asMoney(moneyNumber(reserved) + moneyNumber(recentCompleted)),
        as_of: snapshot.as_of,
        message: snapshot.as_of ? `PayPal reporting snapshot updated ${snapshot.as_of}; reporting data can lag by up to three hours.` : "PayPal reporting snapshot timestamp unavailable; treat the displayed balance conservatively.",
      };
    } catch {
      paypal = noProviderBalance("UNAVAILABLE", "Could not verify the PayPal balance. Confirm that the PayPal app has balances/read reporting permission. No payout will be allowed through this rail until the balance can be read.");
    }
  }

  const sources: ProviderBalanceState[] = [stripe, paypal];
  const configured = sources.filter((source) => source.status !== "NOT_CONFIGURED");
  const liveSources = sources.filter((source) => source.status === "LIVE");
  let status: BalanceState["status"];
  if (configured.length === 0) status = "NOT_CONFIGURED";
  else if (liveSources.length === 0) status = "UNAVAILABLE";
  else if (configured.some((source) => source.status !== "LIVE")) status = "PARTIAL";
  else status = "READY";

  const providerAvailable = (source: ProviderBalanceState) =>
    source.status === "LIVE" && source.available != null ? moneyNumber(source.available) : 0;
  const providerPending = (source: ProviderBalanceState) =>
    source.status === "LIVE" && source.pending != null ? moneyNumber(source.pending) : 0;
  const available = asMoney(providerAvailable(stripe) + providerAvailable(paypal));
  const spendable = asMoney(moneyNumber(stripe.spendable) + moneyNumber(paypal.spendable));
  const pending = asMoney(providerPending(stripe) + providerPending(paypal));
  const reserved = asMoney(moneyNumber(stripe.reserved) + moneyNumber(paypal.reserved));
  const times = [stripe.as_of, paypal.as_of].filter((v): v is string => Boolean(v));
  const asOf = times.length ? times.sort().at(-1)! : null;

  return {
    available,
    display_available: available,
    spendable,
    transferable: spendable,
    pending,
    completed_ledger: asMoney(completedRow?.v ?? 0),
    currency: "USD",
    source: "provider_balances",
    opening_balance: "0.00",
    display_source: "provider_balances",
    status,
    reserved,
    as_of: asOf,
    stripe,
    paypal,
  };
}

export async function controlStation(
  sql: Sql,
  userId: string,
  stationId: number,
  action: string,
) {
  if (!CONTROL_ACTIONS.includes(action as ControlAction)) {
    throw new GmmError("Unsupported action");
  }
  const [station] = await sql<StationRow>`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  if (action === "start" && !asBool(station.enabled)) {
    throw new GmmError("Station is disabled", 409);
  }
  const act = action as ControlAction;
  if (act === "start") {
    const remaining = asInt(station.paused_remaining_seconds);
    const seconds = remaining > 0 ? remaining : CYCLE_MINUTES * 60;
    await sql`update gmm_stations set
      active = true, paused = false, emergency_stopped = false,
      cycle_started_at = now(),
      next_cycle_at = now() + make_interval(secs => ${seconds}),
      paused_remaining_seconds = 0,
      last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
    // START begins the station's collection workflow immediately.
    // A scan credits available funds only when the source records a COLLECTED or COMPLETED amount.
    await runScan(sql, userId, stationId);
  } else if (act === "pause") {
    await sql`update gmm_stations set
      paused_remaining_seconds = case
        when active = true and next_cycle_at is not null
        then greatest(0, floor(extract(epoch from (next_cycle_at - now())))::int)
        else paused_remaining_seconds end,
      paused = true, active = false, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "stop") {
    await sql`update gmm_stations set
      active = false, paused = false, emergency_stopped = false,
      cycle_started_at = null, next_cycle_at = null, paused_remaining_seconds = 0,
      last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "emergency") {
    await sql`update gmm_stations set
      emergency_stopped = true, active = false, paused = false,
      cycle_started_at = null, next_cycle_at = null, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "enable") {
    await sql`update gmm_stations set enabled = true, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  } else if (act === "disable") {
    await sql`update gmm_stations set enabled = false, active = false, last_activity = now()
      where id = ${stationId} and user_id = ${userId}`;
  }
  await stationEvent(sql, userId, stationId, `CONTROL_${act.toUpperCase()}`, "COMPLETED");
  await audit(sql, userId, `station.${act}`, `station_id=${stationId}`);
  const [next] = await sql<StationRow>`select * from gmm_stations where id = ${stationId} and user_id = ${userId}`;
  return mapStation(next);
}

export async function masterControl(sql: Sql, userId: string, action: string) {
  if (!CONTROL_ACTIONS.includes(action as ControlAction)) {
    throw new GmmError("Unsupported action");
  }
  const stations = await sql<StationRow>`select * from gmm_stations where user_id = ${userId} order by sort_order`;
  if (action === "start") {
    await Promise.all(
      stations
        .filter((st) => asBool(st.enabled))
        .map((st) => controlStation(sql, userId, asInt(st.id), action).catch(() => null)),
    );
  } else {
    for (const st of stations) {
      try {
        await controlStation(sql, userId, asInt(st.id), action);
      } catch {
        /* continue remaining stations */
      }
    }
  }
  await audit(sql, userId, `master.${action}`, "all stations; ledger_unchanged=true");
  const rows = await sql<StationRow>`select * from gmm_stations where user_id = ${userId} order by sort_order`;
  return {
    ok: true,
    action,
    station_count: rows.length,
    executed_at: new Date().toISOString(),
    stations: rows.map(mapStation),
  };
}

function mapOpportunity(row: Record<string, unknown>): OpportunityState {
  return {
    id: asInt(row.id),
    station_id: asInt(row.station_id),
    title: String(row.title),
    state: String(row.state),
    estimated_value: row.estimated_value == null ? null : asMoney(row.estimated_value),
    verified_value: row.verified_value == null ? null : asMoney(row.verified_value),
    source_url: row.source_url == null ? null : String(row.source_url),
    evidence: row.evidence == null ? null : String(row.evidence),
    error_message: row.error_message == null ? null : String(row.error_message),
    created_at: iso(row.created_at),
    updated_at: iso(row.updated_at),
  };
}

function mapDestination(row: Record<string, unknown>): DestinationState {
  return {
    id: asInt(row.id),
    type: String(row.type),
    label: String(row.label),
    external_id: String(row.external_id ?? ""),
    enabled: asBool(row.enabled),
    created_at: iso(row.created_at),
  };
}

function mapWithdrawal(row: Record<string, unknown>): WithdrawalState {
  return {
    id: asInt(row.id),
    amount: asMoney(row.amount),
    destination_id: asInt(row.destination_id),
    status: String(row.status),
    provider_reference: row.provider_reference == null ? null : String(row.provider_reference),
    error_message: row.error_message == null ? null : String(row.error_message),
    created_at: iso(row.created_at),
  };
}

function mapLedger(row: Record<string, unknown>): LedgerRow {
  return {
    id: asInt(row.id),
    kind: String(row.kind),
    station_id: row.station_id == null ? null : asInt(row.station_id),
    amount: asMoney(row.amount),
    status: String(row.status),
    description: String(row.description),
    provider_reference: row.provider_reference == null ? null : String(row.provider_reference),
    created_at: iso(row.created_at),
  };
}

const STATUS_MAP: Record<string, string> = {
  SUCCESS: "COMPLETED",
  CAPTURED: "COMPLETED",
  DENIED: "FAILED",
  ACKNOWLEDGED: "SUBMITTED",
  COMPLETED: "COMPLETED",
  FAILED: "FAILED",
  DECLINED: "FAILED",
  RETURNED: "REVERSED",
  REFUNDED: "REVERSED",
  REVERSED: "REVERSED",
  CANCELLED: "CANCELLED",
  CANCELED: "CANCELLED",
  PENDING: "SUBMITTED",
  PROCESSING: "PROCESSING",
  INITIATED: "SUBMITTED",
  posted: "PROCESSING",
  settled: "COMPLETED",
  funds_available: "COMPLETED",
  pending: "SUBMITTED",
  failed: "FAILED",
  returned: "REVERSED",
  SETTLED: "COMPLETED",
  POSTED: "PROCESSING",
};

async function paypalRailCreds(sql: Sql) {
  const envId = paypalClientId();
  const envSecret = paypalClientSecret();
  if (envId && envSecret) {
    return { clientId: envId, clientSecret: envSecret, webhookId: paypalWebhookId() ?? "" };
  }
  const [row] = await sql<{ client_id: string; client_secret: string; webhook_id: string | null }>`
    select client_id, client_secret, webhook_id from gmm_rail_secrets where provider = 'PAYPAL' and environment = 'live' limit 1`;
  if (!row?.client_id || !row.client_secret) return null;
  return {
    clientId: String(row.client_id),
    clientSecret: String(row.client_secret),
    webhookId: row.webhook_id ? String(row.webhook_id) : "",
  };
}

async function createPayout(
  sql: Sql,
  amount: string,
  dest: DestinationState,
  idem: string,
  providerSpendable: string,
) {
  const type = dest.type.toUpperCase();
  if (toCents(amount) > toCents(providerSpendable)) return null;
  if (type === "STRIPE_CONNECT") {
    if (!stripeConfigured()) return null;
    let accountId = dest.external_id.trim();
    try {
      const parsed = JSON.parse(accountId) as { account_id?: string; connected_account_id?: string };
      accountId = parsed.connected_account_id ?? parsed.account_id ?? accountId;
    } catch { /* direct acct_ ID is also accepted */ }
    return createStripeConnectTransfer({ amount, connectedAccountId: accountId, reference: idem });
  }
  if (type === "PAYPAL") {
    // Defensive second barrier: this route only pays from an existing PayPal
    // balance to a recipient; it must never be used as a GMM-to-PayPal deposit.
    throw new GmmError(
      "PayPal Payouts sends money out of PayPal. It cannot deposit GMM Ledger funds into the connected PayPal balance.",
      409,
    );
  }
  return null;
  // No PayPal payout initiation path is permitted here. Existing historical
  // PayPal payout records can still be reconciled by getPaypalPayout().
}

async function reverseUnpaidLedgerPosts(sql: Sql, userId: string) {
  const rows = await sql<{ amount: unknown; provider_reference: string }>`
    select amount, provider_reference from gmm_ledger
    where user_id = ${userId} and kind = 'TRANSFER_DEBIT' and status = 'COMPLETED'
      and provider_reference like 'ledger-%'`;
  for (const row of rows) {
    const reference = String(row.provider_reference);
    const existing = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_REVERSAL' and provider_reference = ${reference} limit 1`;
    if (existing.length) continue;
    const amount = asMoney(Math.abs(moneyNumber(row.amount)));
    await sql`insert into gmm_ledger (user_id, kind, amount, status, description, provider_reference)
      values (${userId}, 'TRANSFER_REVERSAL', ${amount}, 'COMPLETED',
        ${"Reversed. No payment was sent to the destination."}, ${reference})`;
    await sql`update gmm_withdrawals
      set status = 'FAILED',
          error_message = ${"Payout was not completed. The available balance was not reduced."}
      where user_id = ${userId} and provider_reference = ${reference}`;
  }
}

async function applyProviderStatus(
  sql: Sql,
  userId: string,
  withdrawal: WithdrawalState,
  rawStatus: string,
  reference: string | null,
) {
  const mapped = STATUS_MAP[rawStatus] ?? withdrawal.status;
  await sql`update gmm_withdrawals set status = ${mapped} where id = ${withdrawal.id} and user_id = ${userId}`;
  if (mapped === "COMPLETED" && reference) {
    const existing = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_DEBIT' and provider_reference = ${reference} limit 1`;
    if (existing.length === 0) {
      await sql`insert into gmm_ledger (user_id, kind, amount, status, description, provider_reference)
        values (${userId}, 'TRANSFER_DEBIT', ${`-${withdrawal.amount}`}, 'COMPLETED',
          ${"Actual completed transfer debit"}, ${reference})`;
    }
  }
  if (mapped === "REVERSED" && reference) {
    const debit = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_DEBIT' and provider_reference = ${reference} limit 1`;
    const rev = await sql`select id from gmm_ledger
      where user_id = ${userId} and kind = 'TRANSFER_REVERSAL' and provider_reference = ${reference} limit 1`;
    if (debit.length && !rev.length) {
      await sql`insert into gmm_ledger (user_id, kind, amount, status, description, provider_reference)
        values (${userId}, 'TRANSFER_REVERSAL', ${withdrawal.amount}, 'COMPLETED',
          ${"Actual reversal returned funds to internal ledger"}, ${reference})`;
    }
  }
  return mapped;
}

async function reconcileWithdrawal(sql: Sql, userId: string, w: WithdrawalState) {
  if (!w.provider_reference || !["PROCESSING", "PENDING", "SUBMITTED", "RECONCILIATION_REQUIRED"].includes(w.status)) return w;
  const [dest] = await sql`select * from gmm_destinations where id = ${w.destination_id} and user_id = ${userId}`;
  if (!dest) return w;
  if (String(dest.type).toUpperCase() !== "PAYPAL") return w;
  if (!paypalConfigured() && !(await paypalRailCreds(sql))) return w;
  const creds = await paypalRailCreds(sql);
  if (!creds) return w;
  try {
    const body = await getPaypalPayout(w.provider_reference, creds.clientId, creds.clientSecret);
    const header = (body.batch_header ?? {}) as { batch_status?: string };
    const items = Array.isArray(body.items) ? body.items as Array<{ transaction_status?: string }> : [];
    // This payout batch contains a single item, so use its provider status when
    // present instead of blindly treating a successful batch header as a success.
    const raw = items[0]?.transaction_status ?? header.batch_status ?? w.status;
    await sql`update gmm_provider_records set status = ${raw}, raw_status = ${JSON.stringify(body)}, updated_at = now()
      where reference = ${w.provider_reference} and user_id = ${userId}`;
    const mapped = await applyProviderStatus(sql, userId, w, raw, w.provider_reference);
    return { ...w, status: mapped };
  } catch {
    return w;
  }
}

export async function requestTransfer(
  sql: Sql,
  userId: string,
  input: { amount: number; destination_id: number; idempotency_key: string },
) {
  if (!Number.isFinite(input.amount) || input.amount <= 0) {
    throw new GmmError("Amount must be greater than zero");
  }
  const amount = asMoney(input.amount);
  const existing = await sql`select * from gmm_withdrawals
    where user_id = ${userId} and idempotency_key = ${input.idempotency_key} limit 1`;
  if (existing.length) return mapWithdrawal(existing[0]);

  const [destRow] = await sql`select * from gmm_destinations
    where id = ${input.destination_id} and user_id = ${userId}`;
  if (!destRow || !asBool(destRow.enabled)) {
    throw new GmmError("Destination unavailable", 404);
  }
  const dest = mapDestination(destRow);

  // Preferred GMM-native route: GMM Ledger authorizes the withdrawal and its
  // own settlement service executes it. This route intentionally bypasses
  // PayPal Payouts / Stripe as the source of funds.
  if (gmmNativeTransferConfigured()) {
    const [funding] = await sql<{ id: number }>`select id from gmm_funding_sources where user_id = ${userId} limit 1`;
    let inserted: { id: number };
    try {
      const rows = await sql<{ id: number }>`
        insert into gmm_withdrawals (user_id, amount, destination_id, status, idempotency_key, funding_source_id, orchestrator, execution_provider, funding_basis)
        values (${userId}, ${amount}, ${dest.id}, 'PENDING', ${input.idempotency_key}, ${funding ? asInt(funding.id) : null}, 'GMM_LEDGER', 'GMM_NATIVE', 'GMM_NATIVE_SETTLEMENT')
        returning id`;
      inserted = rows[0];
    } catch (err) {
      const again = await sql`select * from gmm_withdrawals where user_id = ${userId} and idempotency_key = ${input.idempotency_key} limit 1`;
      if (again.length) return mapWithdrawal(again[0]);
      throw err;
    }
    try {
      const result = await executeGmmNativeTransfer({
        userId, amount, currency: "USD", destinationType: dest.type, destinationId: dest.external_id,
        idempotencyKey: input.idempotency_key, withdrawalId: asInt(inserted.id),
      });
      await sql`update gmm_withdrawals set status = ${result.status}, provider_reference = ${result.reference}, error_message = ${result.message ?? null}
        where id = ${inserted.id} and user_id = ${userId}`;
      await sql`insert into gmm_provider_records (user_id, provider, reference, withdrawal_id, status, raw_status)
        values (${userId}, 'GMM_NATIVE', ${result.reference}, ${inserted.id}, ${result.status}, ${JSON.stringify(result)})`;
      await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};orchestrator=GMM_LEDGER;execution_provider=GMM_NATIVE;status=${result.status}`);
      const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
      return mapWithdrawal(row);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      // Any request that might have reached the settlement service stays locked
      // for reconciliation; retry only with the same idempotency key.
      const rejected = /returned HTTP 4\d\d/.test(message);
      const status = rejected ? "FAILED" : "RECONCILIATION_REQUIRED";
      await sql`update gmm_withdrawals set status = ${status}, error_message = ${message} where id = ${inserted.id} and user_id = ${userId}`;
      await notify(sql, userId, rejected ? "transfer.failed" : "transfer.reconciliation_required", rejected ? "Transfer rejected" : "Transfer needs reconciliation", message);
      await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};execution_provider=GMM_NATIVE;status=${status}`);
      const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
      return mapWithdrawal(row);
    }
  }

  if (dest.type.toUpperCase() === "PAYPAL") {
    // PayPal Payouts debits the sender's existing PayPal balance to pay a recipient.
    // It does not deposit GMM's internal ledger balance into the owner's PayPal wallet.
    // Block the wrong-direction rail instead of making a misleading or duplicate-risking transfer.
    throw new GmmError(
      "This PayPal Payouts connection cannot move funds from the GMM Ledger into your PayPal balance. It sends money out of an existing PayPal balance. Connect a supported company receiving-account transfer route before initiating this transfer.",
      409,
    );
  }
  const balance = await getBalance(sql, userId);
  const destinationType = dest.type.toUpperCase();
  const providerBalance = destinationType === "STRIPE_CONNECT"
    ? balance.stripe
    : destinationType === "PAYPAL"
      ? balance.paypal
      : null;
  if (!providerBalance) {
    throw new GmmError("This payout destination is not connected to a supported live-money provider.");
  }
  if (providerBalance.status !== "LIVE" || providerBalance.available == null) {
    throw new GmmError(providerBalance.message ?? "The provider's live balance could not be verified. No payout was attempted.");
  }
  if (toCents(amount) > toCents(providerBalance.spendable)) {
    throw new GmmError(`Amount exceeds the currently verified ${destinationType === "STRIPE_CONNECT" ? "Stripe" : "PayPal"} transferable balance.`);
  }

  const [funding] = await sql<{ id: number }>`select id from gmm_funding_sources where user_id = ${userId} limit 1`;
  const fundingId = funding ? asInt(funding.id) : null;

  let inserted: { id: number };
  try {
    const rows = await sql<{ id: number }>`
      insert into gmm_withdrawals (user_id, amount, destination_id, status, idempotency_key, funding_source_id, orchestrator, execution_provider, funding_basis)
      select ${userId}, ${amount}, ${dest.id}, 'PENDING', ${input.idempotency_key}, ${fundingId}, 'GMM_LEDGER', ${destinationType}, 'LIVE_PROVIDER_AVAILABLE_BALANCE'
      where ${toCents(amount)} <= ${toCents(providerBalance.spendable)}
      returning id`;
    if (!rows.length) throw new GmmError("The provider balance changed or the amount is no longer spendable. Refresh balances before trying again.", 409);
    inserted = rows[0];
  } catch (err) {
    if (err instanceof GmmError) throw err;
    const again = await sql`select * from gmm_withdrawals
      where user_id = ${userId} and idempotency_key = ${input.idempotency_key} limit 1`;
    if (again.length) return mapWithdrawal(again[0]);
    throw err;
  }

  try {
    const res = await createPayout(sql, amount, dest, input.idempotency_key, providerBalance.spendable);
    if (!res) {
      const message =
        dest.type.toUpperCase() === "PAYPAL"
          ? "PayPal credentials, reporting balance access, or recipient details are unavailable, so the payout was not sent."
          : dest.type.toUpperCase() === "STRIPE_CONNECT"
            ? "Stripe live credentials or a valid connected account are unavailable, so the transfer was not sent."
          : `${dest.type} has no live payout connection, so the payout was not sent.`;
      await sql`update gmm_withdrawals
        set status = 'FAILED', error_message = ${message}
        where id = ${inserted.id} and user_id = ${userId}`;
      await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};orchestrator=${FINANCIAL_PROVIDER_ID};financial_provider=${FINANCIAL_PROVIDER_NAME};execution_provider=${dest.type};status=FAILED;funding_source=provider_balance;transferable=${providerBalance.spendable}`);
      const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
      return mapWithdrawal(row);
    }
    const mapped = STATUS_MAP[res.status] ?? "PROCESSING";
    await sql`update gmm_withdrawals
      set status = ${mapped}, provider_reference = ${res.provider_reference}, error_message = null
      where id = ${inserted.id} and user_id = ${userId}`;
    await sql`insert into gmm_provider_records (user_id, provider, reference, withdrawal_id, status, raw_status)
      values (${userId}, ${res.provider}, ${res.provider_reference}, ${inserted.id}, ${res.status}, ${JSON.stringify(res.raw ?? res)})`;
    const w = mapWithdrawal({
      id: inserted.id,
      amount,
      destination_id: dest.id,
      status: mapped,
      provider_reference: res.provider_reference,
      error_message: null,
      created_at: new Date().toISOString(),
    });
    if (mapped === "COMPLETED") {
      await applyProviderStatus(sql, userId, w, "COMPLETED", res.provider_reference);
    }
    await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};orchestrator=${FINANCIAL_PROVIDER_ID};financial_provider=${FINANCIAL_PROVIDER_NAME};execution_provider=${dest.type};funding_source=provider_balance;status=${mapped}`);
    const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
    return mapWithdrawal(row);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // A timeout/network/database error can happen after the provider accepted a request.
    // Never mark an ambiguous attempt FAILED and release its reservation: that can cause
    // a second transfer. Explicit provider 4xx rejections are safe to mark FAILED.
    const explicitRejection = /failed \(4\d\d\)|authentication failed \(4\d\d\)|invalid .*headers/i.test(message);
    const status = explicitRejection ? "FAILED" : "RECONCILIATION_REQUIRED";
    await sql`update gmm_withdrawals set status = ${status}, error_message = ${message}
      where id = ${inserted.id} and user_id = ${userId}`;
    await notify(sql, userId, explicitRejection ? "transfer.failed" : "transfer.reconciliation_required",
      explicitRejection ? "Transfer rejected by provider" : "Transfer needs provider reconciliation", message);
    await audit(sql, userId, "withdrawal.requested", `id=${inserted.id};destination=${dest.type};status=${status}`);
    const [row] = await sql`select * from gmm_withdrawals where id = ${inserted.id} and user_id = ${userId}`;
    return mapWithdrawal(row);
  }
}

export async function addDestination(
  sql: Sql,
  userId: string,
  input: { type: string; label: string; external_id: string },
) {
  const type = input.type.toUpperCase().trim();
  const supported = new Set(["PAYPAL", "STRIPE_CONNECT"]);
  if (!supported.has(type)) throw new GmmError("Unsupported payout destination type");
  const label = input.label.trim();
  const external = input.external_id.trim();
  if (!label || !external) throw new GmmError("Destination label and provider data are required");
  const rows = await sql`insert into gmm_destinations (user_id, type, label, external_id, enabled)
    values (${userId}, ${type}, ${label}, ${external}, true)
    returning *`;
  await audit(sql, userId, "destination.created", `${asInt(rows[0].id)}:${type}`);
  return mapDestination(rows[0]);
}

export async function savePaypalRail(
  userId: string,
  input: { client_id: string; client_secret: string; webhook_id: string },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const clientId = input.client_id.trim();
  const clientSecret = input.client_secret.trim();
  const webhookId = input.webhook_id.trim();
  if (!clientId || !clientSecret) {
    throw new GmmError("Enter both the PayPal Live client ID and client secret. The credentials cannot be saved until PayPal authenticates them.");
  }
  try {
    // Verify OAuth credentials before storing them. Webhook setup is a separate
    // configuration step; requiring its ID here prevented saving otherwise-valid
    // credentials before the webhook had been created. If supplied, verify it.
    await assertPaypalCredentials(clientId, clientSecret);
    if (webhookId) await assertPaypalWebhook(clientId, clientSecret, webhookId);
  } catch (err) {
    const message = err instanceof Error ? err.message : "PayPal authentication failed";
    throw new GmmError(`${message}. The secret was not saved.`);
  }
  await sql`insert into gmm_rail_secrets (provider, client_id, client_secret, webhook_id, environment)
    values ('PAYPAL', ${clientId}, ${clientSecret}, ${webhookId}, 'live')
    on conflict (provider) do update
      set client_id = ${clientId}, client_secret = ${clientSecret},
          webhook_id = case when ${webhookId} <> '' then ${webhookId} else gmm_rail_secrets.webhook_id end,
          environment = 'live', updated_at = now()`;
  await audit(sql, userId, "paypal.rail.saved", "credentials stored; secret not logged");
  return { configured: true };
}

/** Creates a PayPal Checkout request so a payer can send real money to the configured PayPal merchant. */
export async function startPaypalCheckout(userId: string, input: { station_id: number; amount: number; idempotency_key: string; origin: string }) {
  if (!Number.isInteger(input.station_id) || input.station_id < 1) throw new GmmError("Choose a valid Field Team Station");
  if (!Number.isFinite(input.amount) || input.amount <= 0 || Math.round(input.amount * 100) !== input.amount * 100 || input.amount > 1000000) throw new GmmError("Enter a valid USD amount (up to $1,000,000.00)");
  const key = input.idempotency_key.trim();
  if (key.length < 8 || key.length > 120) throw new GmmError("A unique checkout request key is required");
  let origin: URL;
  try { origin = new URL(input.origin); } catch { throw new GmmError("Invalid app origin"); }
  if (origin.protocol !== "https:" && origin.hostname !== "localhost") throw new GmmError("PayPal checkout requires a secure HTTPS app origin");
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [station] = await sql`select id, name from gmm_stations where id = ${input.station_id} and user_id = ${userId} and name <> 'Earnings & Transfer Station'`;
  if (!station) throw new GmmError("The selected Field Team Station does not belong to this CEO", 404);
  const prior = await sql`select * from gmm_paypal_checkout_orders where user_id = ${userId} and idempotency_key = ${key} limit 1`;
  if (prior.length) return prior[0];
  const creds = await paypalRailCreds(sql);
  if (!creds?.clientId || !creds?.clientSecret) throw new GmmError("Configure verified PayPal credentials before creating a checkout", 409);
  const rows = await sql`insert into gmm_paypal_checkout_orders (user_id, station_id, amount, currency, status, idempotency_key)
    values (${userId}, ${input.station_id}, ${input.amount.toFixed(2)}, 'USD', 'CREATED', ${key}) returning *`;
  const row = rows[0];
  try {
    const paypal = await createPaypalCheckoutOrder({ clientId: creds.clientId, clientSecret: creds.clientSecret, amount: input.amount.toFixed(2), reference: `GMM-${String(row.id)}-${String(input.station_id)}`, returnUrl: `${origin.origin}/?paypal_checkout=return&gmm_order=${String(row.id)}`, cancelUrl: `${origin.origin}/?paypal_checkout=cancel&gmm_order=${String(row.id)}` });
    const updated = await sql`update gmm_paypal_checkout_orders set paypal_order_id = ${paypal.orderId}, approval_url = ${paypal.approvalUrl}, status = 'CREATED', updated_at = now() where id = ${asInt(row.id)} and user_id = ${userId} returning *`;
    await audit(sql, userId, "paypal.checkout.created", `checkout_id=${asInt(row.id)};station_id=${input.station_id};amount=${input.amount.toFixed(2)};paypal_order_id=${paypal.orderId}`);
    return updated[0];
  } catch (err) {
    const message = err instanceof Error ? err.message : "PayPal order creation failed";
    await sql`update gmm_paypal_checkout_orders set status = 'FAILED', error_message = ${message.slice(0, 500)}, updated_at = now() where id = ${asInt(row.id)} and user_id = ${userId}`;
    throw new GmmError(message, (err as { status?: number })?.status ?? 502);
  }
}

async function recordPaypalCheckoutCapture(sql: Sql, orderRow: Record<string, unknown>, capture: { captureId: string; amount: string; currency: string; status: string }) {
  const userId = String(orderRow.user_id);
  const orderId = asInt(orderRow.id);
  if (capture.status !== "COMPLETED") {
    const nextStatus = capture.status === "PENDING" ? "CAPTURE_PENDING" : "FAILED";
    await sql`update gmm_paypal_checkout_orders set status = ${nextStatus}, updated_at = now() where id = ${orderId} and status <> 'CAPTURED'`;
    if (nextStatus === "CAPTURE_PENDING") await notify(sql, userId, "paypal.checkout.pending", "PayPal payment pending", `PayPal has not completed checkout order ${orderId} yet. GMM has not posted station earnings.`);
    return { status: nextStatus };
  }
  if (!capture.captureId || capture.currency !== "USD" || toCents(capture.amount) !== toCents(orderRow.amount)) throw new GmmError("PayPal capture amount/currency does not match the GMM order; no earnings were posted", 409);
  const result = await sql`update gmm_paypal_checkout_orders set status = 'CAPTURED', paypal_capture_id = ${capture.captureId}, error_message = null, updated_at = now()
    where id = ${orderId} and user_id = ${userId} and status <> 'CAPTURED'
      and not exists (select 1 from gmm_paypal_checkout_orders other where other.paypal_capture_id = ${capture.captureId}) returning *`;
  if (!result.length) {
    const [existing] = await sql`select * from gmm_paypal_checkout_orders where id = ${orderId} and user_id = ${userId}`;
    if (existing?.status === "CAPTURED" && existing?.paypal_capture_id === capture.captureId) return existing;
    throw new GmmError("This PayPal capture was already reconciled or the order state changed", 409);
  }
  await sql`insert into gmm_ledger (user_id, kind, station_id, amount, status, description, provider_reference)
    select ${userId}, 'STATION_COLLECTION', ${asInt(orderRow.station_id)}, ${String(orderRow.amount)}, 'COMPLETED',
      'PayPal Checkout capture confirmed by PayPal; payer-originated receipt.', ${capture.captureId}
    where not exists (select 1 from gmm_ledger where user_id = ${userId} and provider_reference = ${capture.captureId})`;
  await audit(sql, userId, "paypal.checkout.received", `checkout_id=${orderId};station_id=${asInt(orderRow.station_id)};amount=${String(orderRow.amount)};currency=USD;paypal_capture_id=${capture.captureId}`);
  await notify(sql, userId, "paypal.checkout.received", "PayPal payment received", `$${Number(orderRow.amount).toFixed(2)} USD was captured by PayPal and reconciled to ${String(orderRow.station_name ?? `Field Team Station ${String(orderRow.station_id)}`)}.`);
  return result[0];
}

export async function capturePaypalCheckout(userId: string, checkoutId: number) {
  if (!Number.isInteger(checkoutId) || checkoutId < 1) throw new GmmError("Invalid checkout ID");
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [row] = await sql`select o.*, s.name as station_name from gmm_paypal_checkout_orders o join gmm_stations s on s.id = o.station_id and s.user_id = o.user_id where o.id = ${checkoutId} and o.user_id = ${userId}`;
  if (!row) throw new GmmError("PayPal checkout not found", 404);
  if (String(row.status) === "CAPTURED") return row;
  if (!row.paypal_order_id) throw new GmmError("This checkout has no PayPal order ID", 409);
  const creds = await paypalRailCreds(sql);
  if (!creds?.clientId || !creds?.clientSecret) throw new GmmError("PayPal credentials are not configured", 409);
  try {
    const capture = await capturePaypalCheckoutOrder({ clientId: creds.clientId, clientSecret: creds.clientSecret, orderId: String(row.paypal_order_id) });
    return await recordPaypalCheckoutCapture(sql, row, { captureId: String(capture.captureId ?? ""), amount: String(capture.amount ?? ""), currency: String(capture.currency ?? ""), status: String(capture.captureStatus) });
  } catch (err) {
    const message = err instanceof Error ? err.message : "PayPal capture failed";
    await sql`update gmm_paypal_checkout_orders set error_message = ${message.slice(0, 500)}, updated_at = now() where id = ${checkoutId} and user_id = ${userId} and status <> 'CAPTURED'`;
    throw new GmmError(message, (err as { status?: number })?.status ?? 502);
  }
}

export async function listPaypalCheckoutOrders(userId: string) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  return sql`select o.id, o.station_id, s.name as station_name, o.amount, o.currency, o.status, o.paypal_order_id, o.approval_url, o.paypal_capture_id, o.error_message, o.created_at, o.updated_at
    from gmm_paypal_checkout_orders o join gmm_stations s on s.id = o.station_id and s.user_id = o.user_id where o.user_id = ${userId} order by o.created_at desc limit 30`;
}

/** Creates a CEO-authorized $200 live receiving-test record. This does not itself move money. */
export async function startPaypalDepositTest(
  userId: string,
  input: { station_id: number; ceo_confirmed: boolean; idempotency_key: string },
) {
  if (input.ceo_confirmed !== true) throw new GmmError("CEO confirmation is required before authorizing the $200 live source-provider deposit test", 403);
  if (!Number.isInteger(input.station_id) || input.station_id < 1) throw new GmmError("Choose a valid Field Team Station");
  const key = input.idempotency_key.trim();
  if (key.length < 8 || key.length > 120) throw new GmmError("A unique live-deposit request key is required");
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [station] = await sql`select id from gmm_stations where id = ${input.station_id} and user_id = ${userId}`;
  if (!station) throw new GmmError("The selected Field Team Station does not belong to this CEO", 404);
  const creds = await paypalRailCreds(sql);
  if (!creds?.clientId || !creds?.clientSecret || !creds?.webhookId) {
    throw new GmmError("Configure and verify the live PayPal receiving account before preparing a receiving test", 409);
  }
  const prior = await sql`select * from gmm_paypal_deposit_tests where user_id = ${userId} and idempotency_key = ${key} limit 1`;
  if (prior.length) return prior[0];
  const active = await sql`select id from gmm_paypal_deposit_tests where user_id = ${userId} and status in ('AWAITING_SOURCE_TRANSFER', 'AWAITING_PAYER_APPROVAL', 'CAPTURE_PENDING') limit 1`;
  if (active.length) throw new GmmError("A live deposit test is already awaiting a source-provider transfer or reconciliation. Resolve it before creating another.", 409);
  // This creates an authorization/reconciliation record only. PayPal has no generic public API
  // for crediting arbitrary funds from an internal ledger into the owner's own wallet. The real
  // transfer must be initiated by a connected, authorized source provider/worker rail.
  const rows = await sql`insert into gmm_paypal_deposit_tests (user_id, station_id, amount, currency, status, idempotency_key, error_message)
    values (${userId}, ${input.station_id}, 200.00, 'USD', 'AWAITING_SOURCE_TRANSFER', ${key},
      'Awaiting execution by the station source provider through its authorized transfer rail; no funds have been sent yet.') returning *`;
  await audit(sql, userId, "paypal.deposit_test.authorized", `test_id=${asInt(rows[0].id)};station_id=${input.station_id};amount=200.00;currency=USD;ceo_confirmed=true;source_transfer=not_started`);
  await notify(sql, userId, "paypal.deposit_test.awaiting_source", "$200 live source-provider deposit test authorized", "CEO authorization is recorded. No funds have been moved yet. The connected, authorized source-provider rail must execute the real $200 USD transfer to the live PayPal receiving account; GMM will then verify the incoming transaction directly with PayPal.");
  return rows[0];
}

export async function listPaypalDepositTests(userId: string) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const creds = await paypalRailCreds(sql);
  if (creds?.clientId && creds?.clientSecret) {
    const pending = await sql`select * from gmm_paypal_deposit_tests where user_id = ${userId} and status = 'AWAITING_SOURCE_TRANSFER' order by created_at asc limit 10`;
    for (const test of pending) {
      try {
        const evidence = await findRecentPaypalIncomingCredit({
          clientId: creds.clientId,
          clientSecret: creds.clientSecret,
          since: String(test.created_at),
        });
        if (!evidence) continue;
        await recordPaypalDepositReceipt(sql, userId, test, evidence);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "PayPal deposit reconciliation is temporarily unavailable";
        // Keep the test pending on report lag/provider errors; never imply receipt without evidence.
        await sql`update gmm_paypal_deposit_tests set error_message = ${msg}, updated_at = now() where id = ${asInt(test.id)} and user_id = ${userId} and status = 'AWAITING_SOURCE_TRANSFER'`;
      }
    }
  }
  return sql`select t.id, t.station_id, s.name as station_name, t.amount, t.currency, t.status,
      t.paypal_transaction_id, t.paypal_event_code, t.paypal_transaction_status,
      t.error_message, t.created_at, t.updated_at
    from gmm_paypal_deposit_tests t join gmm_stations s on s.id = t.station_id and s.user_id = t.user_id
    where t.user_id = ${userId} order by t.created_at desc limit 20`;
}

async function recordPaypalDepositReceipt(
  sql: Sql,
  userId: string,
  testRow: Record<string, unknown>,
  evidence: { transaction_id: string; event_code: string; status: string; amount: string; currency: string; [key: string]: unknown },
) {
  if (toCents(evidence.amount) !== toCents(String(testRow.amount ?? "0")) || evidence.currency !== "USD" || evidence.status !== "S") {
    throw new GmmError("PayPal evidence does not match the exact stored live deposit-test amount", 409);
  }
  const testId = asInt(testRow.id);
  const result = await sql`update gmm_paypal_deposit_tests
    set status = 'RECEIVED', paypal_transaction_id = ${evidence.transaction_id}, paypal_event_code = ${evidence.event_code},
      paypal_transaction_status = ${evidence.status}, provider_evidence = ${JSON.stringify(evidence)}::jsonb,
      error_message = null, updated_at = now()
    where id = ${testId} and user_id = ${userId} and status = 'AWAITING_SOURCE_TRANSFER'
      and not exists (select 1 from gmm_paypal_deposit_tests other where other.user_id = ${userId} and other.paypal_transaction_id = ${evidence.transaction_id})
    returning *`;
  if (!result.length) {
    const [existing] = await sql`select id, status, paypal_transaction_id from gmm_paypal_deposit_tests where id = ${testId} and user_id = ${userId}`;
    if (existing?.status === "RECEIVED" && existing?.paypal_transaction_id === evidence.transaction_id) return existing;
    throw new GmmError("This PayPal transaction was already used or the test state changed; no duplicate receipt was posted", 409);
  }
  await sql`insert into gmm_ledger (user_id, kind, station_id, amount, status, description, provider_reference)
    select ${userId}, 'PAYPAL_DEPOSIT_TEST_RECEIPT', ${asInt(testRow.station_id)}, ${Number(testRow.amount)}, 'COMPLETED',
      'PayPal-reported incoming credit confirmed against stored live deposit-test amount; excluded from available-balance summation to avoid double counting.', ${evidence.transaction_id}
    where not exists (select 1 from gmm_ledger where user_id = ${userId} and provider_reference = ${evidence.transaction_id})`;
  await audit(sql, userId, "paypal.deposit_test.received", `test_id=${testId};station_id=${asInt(testRow.station_id)};amount=${String(testRow.amount)};currency=USD;paypal_transaction_id=${evidence.transaction_id};event=${evidence.event_code};status=${evidence.status}`);
  await notify(sql, userId, "paypal.deposit_test.received", "Live PayPal deposit received", `PayPal's transaction report shows the successful $${Number(testRow.amount).toFixed(2)} USD incoming credit. GMM automatically reconciled the receipt; no manual transaction ID was required.`);
  return result[0];
}

/** Confirm only against PayPal's own transaction-report record; never accept user-entered proof alone. */
export async function confirmPaypalDepositTest(userId: string, testId: number, transactionId: string) {
  if (!Number.isInteger(testId) || testId < 1) throw new GmmError("Invalid deposit test ID");
  const id = transactionId.trim();
  if (!id) throw new GmmError("PayPal transaction ID is required");
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [testRow] = await sql`select * from gmm_paypal_deposit_tests where id = ${testId} and user_id = ${userId}`;
  if (!testRow) throw new GmmError("Deposit test not found", 404);
  if (String(testRow.status) === "RECEIVED") {
    if (String(testRow.paypal_transaction_id) === id) return testRow;
    throw new GmmError("This test has already been confirmed with a different PayPal transaction", 409);
  }
  if (String(testRow.status) !== "AWAITING_SOURCE_TRANSFER") throw new GmmError("This test is not awaiting provider reconciliation", 409);
  const creds = await paypalRailCreds(sql);
  if (!creds?.clientId || !creds?.clientSecret) throw new GmmError("Live PayPal credentials are not configured", 409);
  let evidence: Awaited<ReturnType<typeof findPaypalIncomingCredit>>;
  try {
    evidence = await findPaypalIncomingCredit({ clientId: creds.clientId, clientSecret: creds.clientSecret, transactionId: id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "PayPal transaction could not be verified";
    if (/not returned|does not match|transaction ID/i.test(msg)) {
      await sql`update gmm_paypal_deposit_tests set error_message = ${msg}, updated_at = now() where id = ${testId} and user_id = ${userId}`;
    }
    throw new GmmError(msg, (err as { status?: number })?.status ?? 502);
  }
  if (toCents(evidence.amount) !== toCents(String(testRow.amount ?? "0")) || evidence.currency !== "USD" || evidence.status !== "S") throw new GmmError("PayPal evidence does not match the exact stored live deposit-test amount and successful status", 409);
  const result = await sql`update gmm_paypal_deposit_tests
    set status = 'RECEIVED', paypal_transaction_id = ${evidence.transaction_id}, paypal_event_code = ${evidence.event_code},
      paypal_transaction_status = ${evidence.status}, provider_evidence = ${JSON.stringify(evidence)}::jsonb,
      error_message = null, updated_at = now()
    where id = ${testId} and user_id = ${userId} and status = 'AWAITING_SOURCE_TRANSFER'
      and not exists (select 1 from gmm_paypal_deposit_tests other where other.user_id = ${userId} and other.paypal_transaction_id = ${evidence.transaction_id})
    returning *`;
  if (!result.length) throw new GmmError("This PayPal transaction was already used or the test state changed; no duplicate receipt was posted", 409);
  await sql`insert into gmm_ledger (user_id, kind, station_id, amount, status, description, provider_reference)
    select ${userId}, 'PAYPAL_DEPOSIT_TEST_RECEIPT', ${asInt(testRow.station_id)}, ${Number(testRow.amount)}, 'COMPLETED',
      'PayPal-reported incoming bank/EFT credit confirmed against stored live deposit-test amount; excluded from available-balance summation to avoid double counting.', ${evidence.transaction_id}
    where not exists (select 1 from gmm_ledger where user_id = ${userId} and provider_reference = ${evidence.transaction_id})`;
  await audit(sql, userId, "paypal.deposit_test.received", `test_id=${testId};station_id=${asInt(testRow.station_id)};amount=${String(testRow.amount)};currency=USD;paypal_transaction_id=${evidence.transaction_id};event=${evidence.event_code};status=${evidence.status}`);
  await notify(sql, userId, "paypal.deposit_test.received", "Live PayPal deposit confirmed", `PayPal Transaction Search confirmed a successful $${Number(testRow.amount).toFixed(2)} USD incoming bank/EFT credit. This confirms the receiving path for this transaction only; it does not certify other station balances.`);
  return result[0];
}

export async function loadAppState(userId: string): Promise<AppState> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  await reverseUnpaidLedgerPosts(sql, userId);
  await tickCycles(sql, userId);
  // Station totals are calculated from persisted Ledger entries linked to each station.
  const stations = await sql<StationRow>`
    select s.*,
      coalesce((select sum(l.amount) from gmm_ledger l
        where l.user_id = s.user_id and l.station_id = s.id
          and l.kind in ('STATION_COLLECTION', 'STATION_EARNINGS_IMPORT') and l.status = 'COMPLETED'), 0) as station_earnings,
      (select count(*)::int from gmm_ledger l
        where l.user_id = s.user_id and l.station_id = s.id
          and l.kind = 'STATION_COLLECTION' and l.status = 'COMPLETED') as completed_collections
    from gmm_stations s where s.user_id = ${userId}
      and s.name <> 'Earnings & Transfer Station' order by s.sort_order`;
  const destRows = await sql`select * from gmm_destinations where user_id = ${userId} order by id`;
  const wdRows = await sql`select * from gmm_withdrawals where user_id = ${userId} order by created_at desc`;
  const noteRows = await sql`select * from gmm_notifications where user_id = ${userId} order by created_at desc limit 50`;
  const withdrawals: WithdrawalState[] = [];
  for (const row of wdRows) {
    withdrawals.push(await reconcileWithdrawal(sql, userId, mapWithdrawal(row)));
  }
  const balance = await getBalance(sql, userId);
  const [fundingRow] = await sql`select * from gmm_funding_sources where user_id = ${userId} limit 1`;
  const creds = await paypalRailCreds(sql);
  const providers = providerStatusMap();
  if (creds) {
    providers.PAYPAL = {
      ...providers.PAYPAL,
      configured: true,
      missing: creds.webhookId ? [] : ["PAYPAL_WEBHOOK_ID"],
    };
  }
  return {
    stations: stations.map(mapStation),
    balance,
    paypal: {
      provider: "paypal",
      configured: Boolean(creds),
      environment: paypalLiveEnv(),
      mode: "live",
    },
    destinations: destRows.map(mapDestination),
    withdrawals,
    funding_source: {
      id: asInt(fundingRow?.id),
      kind: String(fundingRow?.kind ?? "LEDGER"),
      label: String(fundingRow?.label ?? "GMM Ledger — authorizes and records payouts; Stripe/PayPal provider accounts execute and fund them"),
      provider: fundingRow?.provider == null ? null : String(fundingRow.provider),
      provider_account_id:
        fundingRow?.provider_account_id == null ? null : String(fundingRow.provider_account_id),
      has_account_number: fundingRow?.account_number != null && String(fundingRow.account_number) !== "",
      has_routing_number: fundingRow?.routing_number != null && String(fundingRow.routing_number) !== "",
    },
    providers,
    notifications: noteRows.map((n) => ({
      id: asInt(n.id),
      kind: String(n.kind),
      title: String(n.title),
      message: String(n.message),
      read: asBool(n.read),
      created_at: iso(n.created_at),
    })),
    scanner: {
      enabled: true,
      mode: "real-connectors-only",
      fabricated_results: false,
      cycle_minutes: CYCLE_MINUTES,
    },
  };
}

/**
 * Read-only status for GMM's own ledger account. This reports what the database
 * records; it deliberately does not label accounting entries as verified cash.
 */
export async function getLedgerAccountStatus(userId: string) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [ledger] = await sql<{ row_count: number; completed_recorded_usd: unknown; opening_recorded_usd: unknown }>`
    select count(*)::int as row_count,
      coalesce(sum(case when status = 'COMPLETED' then amount else 0 end), 0) as completed_recorded_usd,
      coalesce(sum(case when status = 'COMPLETED' and kind = 'OPENING_BALANCE' then amount else 0 end), 0) as opening_recorded_usd
    from gmm_ledger where user_id = ${userId}`;
  const withdrawals = await sql<{ status: string; count: number; amount: unknown }>`
    select status, count(*)::int as count, coalesce(sum(amount), 0) as amount
    from gmm_withdrawals where user_id = ${userId} group by status order by status`;
  const stations = await sql<{ count: number }>`
    select count(*)::int as count from gmm_stations where user_id = ${userId}`;
  return {
    account_id: 'GMM_LEDGER',
    account_name: 'GMM Ledger',
    authority: 'GMM_LEDGER',
    api_base_path: '/api/gmm',
    database: {
      connected: true,
      backend: dbSource,
      production_database_confirmed: false,
      note: dbSource === 'pglite'
        ? 'Embedded PGlite database is active. This is not proof of a persistent production database.'
        : 'Configured Neon/Postgres connection answered the ledger query. Deployment identity must be independently verified; this does not independently prove external cash backing.',
    },
    ledger_records: {
      row_count: Number(ledger?.row_count ?? 0),
      completed_recorded_usd: asMoney(ledger?.completed_recorded_usd ?? 0),
      opening_recorded_usd: asMoney(ledger?.opening_recorded_usd ?? 0),
      currency: 'USD',
      cash_backing_verified: false,
    },
    stations: { count: Number(stations[0]?.count ?? 0) },
    withdrawals_by_status: withdrawals.map((row) => ({
      status: String(row.status), count: Number(row.count), recorded_usd: asMoney(row.amount),
    })),
    transfer_execution: {
      native_settlement_configured: gmmNativeTransferConfigured(),
      live_transfer_verified: false,
      note: 'GMM Ledger authorizes and records withdrawals. This status endpoint does not claim that an external cash transfer has executed.',
    },
    checked_at: new Date().toISOString(),
  };
}

export async function listLedger(userId: string): Promise<LedgerRow[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql`select * from gmm_ledger where user_id = ${userId} order by created_at desc`;
  return rows.map(mapLedger);
}

export async function listAudit(userId: string): Promise<AuditRow[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql`select * from gmm_audit where user_id = ${userId} order by created_at desc limit 200`;
  return rows.map((r) => ({
    id: asInt(r.id),
    action: String(r.action),
    detail: String(r.detail),
    created_at: iso(r.created_at),
  }));
}

export async function listConnectors(userId: string): Promise<ConnectorState[]> {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = await sql<{
    station_id: number;
    station_name: string;
    connector_type: string;
    endpoint: string | null;
    enabled: boolean;
  }>`select c.station_id, s.name as station_name, c.connector_type, c.endpoint, c.enabled
    from gmm_connectors c
    join gmm_stations s on s.id = c.station_id
    where c.user_id = ${userId}
    order by s.sort_order`;
  return rows.map((r) => ({
    station_id: asInt(r.station_id),
    station_name: String(r.station_name),
    connector_type: String(r.connector_type),
    endpoint: r.endpoint == null ? null : String(r.endpoint),
    enabled: asBool(r.enabled),
  }));
}

export async function saveConnector(
  userId: string,
  input: { station_id: number; connector_type: string; endpoint: string; enabled: boolean },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  if (input.enabled) publicHttpsUrl(input.endpoint);
  await sql`update gmm_connectors
    set connector_type = ${input.connector_type || "http_json"},
        endpoint = ${input.endpoint.trim() || null},
        enabled = ${input.enabled},
        updated_at = now()
    where station_id = ${input.station_id} and user_id = ${userId}`;
  await audit(sql, userId, "connector.updated", `station_id=${input.station_id};enabled=${input.enabled}`);
  return { ok: true };
}

export async function listOpportunities(userId: string, stationId?: number) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const rows = stationId
    ? await sql`select * from gmm_opportunities where user_id = ${userId} and station_id = ${stationId} order by created_at desc`
    : await sql`select * from gmm_opportunities where user_id = ${userId} order by created_at desc`;
  return rows.map(mapOpportunity);
}

export async function addOpportunity(
  userId: string,
  input: {
    station_id: number;
    title: string;
    source_url?: string;
    estimated_value?: number | null;
    evidence?: string;
  },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const title = input.title.trim();
  if (!title) throw new GmmError("Title is required");
  const [station] = await sql`select id from gmm_stations where id = ${input.station_id} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  const estimated = input.estimated_value == null ? null : asMoney(input.estimated_value);
  const source = input.source_url?.trim() || null;
  const evidence = input.evidence?.trim() || null;
  const rows = await sql`insert into gmm_opportunities
    (user_id, station_id, title, source_url, estimated_value, state, evidence)
    values (${userId}, ${input.station_id}, ${title}, ${source}, ${estimated}, 'DETECTED', ${evidence})
    returning *`;
  await stationEvent(sql, userId, input.station_id, "OPPORTUNITY_ENTERED", "DETECTED", title);
  await audit(sql, userId, "opportunity.manual_entry", `id=${asInt(rows[0].id)};station_id=${input.station_id}`);
  return mapOpportunity(rows[0]);
}

export async function recordStationCollection(
  userId: string,
  input: { station_id: number; title: string; amount: number; evidence?: string },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const title = input.title.trim();
  if (!title) throw new GmmError("Title is required");
  const amount = asMoney(input.amount);
  if (toCents(amount) <= 0) throw new GmmError("Collection amount must be greater than zero");
  const [station] = await sql`select id from gmm_stations where id = ${input.station_id} and user_id = ${userId}`;
  if (!station) throw new GmmError("Station not found", 404);
  const evidence = input.evidence?.trim() || "";
  if (evidence.length < 8) {
    throw new GmmError("Funding verification evidence is required. Enter a source confirmation, receipt/reference, award notice, or other traceable evidence before recording a completed collection.");
  }
  const rows = await sql<{ id: number }>`insert into gmm_opportunities
    (user_id, station_id, title, verified_value, state, evidence)
    values (${userId}, ${input.station_id}, ${title}, ${amount}, 'COMPLETED', ${evidence})
    returning id`;
  await creditCompletedCollection(sql, userId, {
    stationId: input.station_id,
    opportunityId: rows[0].id,
    amount,
    title,
  });
  const [row] = await sql`select * from gmm_opportunities where id = ${rows[0].id} and user_id = ${userId}`;
  return mapOpportunity(row);
}

export async function verifyOpportunity(
  userId: string,
  input: { opportunity_id: number; verified_value: number; evidence: string },
) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const [o] = await sql`select * from gmm_opportunities where id = ${input.opportunity_id} and user_id = ${userId}`;
  if (!o) throw new GmmError("Opportunity not found", 404);
  if (String(o.state) === "COMPLETED") {
    const recordedValue = asMoney(o.verified_value);
    if (toCents(recordedValue) > 0) {
      await creditCompletedCollection(sql, userId, {
        stationId: asInt(o.station_id),
        opportunityId: input.opportunity_id,
        amount: recordedValue,
        title: String(o.title),
      });
    }
    const [completedRow] = await sql`select * from gmm_opportunities where id = ${input.opportunity_id} and user_id = ${userId}`;
    return mapOpportunity(completedRow);
  }
  const value = asMoney(input.verified_value);
  if (toCents(value) <= 0) throw new GmmError("Collection amount must be greater than zero");
  const suppliedEvidence = input.evidence.trim();
  if (suppliedEvidence.length < 8) throw new GmmError("Traceable funding verification evidence is required before confirming a collection.");
  const evidence = `${o.evidence || ""}\nCEO COLLECTION VERIFICATION: ${suppliedEvidence}`.trim();
  await sql`update gmm_opportunities
    set state = 'COMPLETED', verified_value = ${value}, evidence = ${evidence}, updated_at = now()
    where id = ${input.opportunity_id} and user_id = ${userId}`;
  await creditCompletedCollection(sql, userId, {
    stationId: asInt(o.station_id),
    opportunityId: input.opportunity_id,
    amount: value,
    title: String(o.title),
  });
  const [row] = await sql`select * from gmm_opportunities where id = ${input.opportunity_id} and user_id = ${userId}`;
  return mapOpportunity(row);
}

export async function markNotificationRead(userId: string, id: number) {
  const sql = await getSql();
  await sql`update gmm_notifications set read = true where id = ${id} and user_id = ${userId}`;
  return { ok: true };
}

export async function scanStation(userId: string, stationId: number) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  return runScan(sql, userId, stationId);
}

/** Run due station cycles from a trusted backend scheduler. This deliberately
 * accepts only the configured owner ID and never authorizes money movement. */
export async function runScheduledStationCycles(userId: string) {
  if (!userId.trim()) throw new GmmError("GMM_OWNER_USER_ID is not configured", 503);
  const sql = await getSql();
  await ensureOwner(sql, userId);
  const before = await sql<{ count: number }>`
    select count(*)::int as count from gmm_stations
    where user_id = ${userId} and enabled = true and active = true
      and paused = false and emergency_stopped = false
      and next_cycle_at is not null and next_cycle_at <= now()`;
  await tickCycles(sql, userId);
  const [after] = await sql<{ count: number }>`
    select count(*)::int as count from gmm_stations
    where user_id = ${userId} and enabled = true and active = true
      and paused = false and emergency_stopped = false
      and next_cycle_at is not null and next_cycle_at <= now()`;
  return { owner_id: userId, due_before: asInt(before[0]?.count), due_after: asInt(after?.count), executed_at: new Date().toISOString() };
}


export async function withOwnerSql<T>(userId: string, fn: (sql: Sql) => Promise<T>) {
  const sql = await getSql();
  await ensureOwner(sql, userId);
  await tickCycles(sql, userId);
  return fn(sql);
}

export async function health() {
  const sql = await getSql();
  const [row] = await sql<{ n: number }>`select count(*)::int as n from gmm_stations`;
  return {
    status: "ok",
    database: "ok",
    database_backend: dbSource,
    production_database_confirmed: false,
    station_count: asInt(row?.n),
    paypal_configured: paypalConfigured(),
    paypal_environment: paypalLiveEnv(),
    production_mode: process.env.NODE_ENV === "production" || process.env.VERCEL === "1" || Boolean(process.env.GROK_PROJECT_ID),
    scheduler_enabled: true,
    cycle_minutes: CYCLE_MINUTES,
  };
}

export async function handlePaypalWebhook(request: Request) {
  const sql = await getSql();
  const event = (await request.json()) as Record<string, unknown>;
  const eid = typeof event.id === "string" ? event.id : "";
  if (!eid) throw new GmmError("Missing event id");
  // Verify the signature before consulting event IDs. Otherwise an unauthenticated
  // request could pre-register a known event ID and suppress the legitimate webhook.
  const creds = await paypalRailCreds(sql);
  if (!creds?.webhookId) throw new GmmError("PayPal webhook credentials are not configured", 503);
  const { verifyPaypalWebhook } = await import("./paypal");
  await verifyPaypalWebhook(request.headers, event, {
    clientId: creds.clientId, clientSecret: creds.clientSecret, webhookId: creds.webhookId,
  });
  const dup = await sql`select id from gmm_webhook_events where event_id = ${eid} limit 1`;
  if (dup.length) return { ok: true, duplicate: true };
  await sql`insert into gmm_webhook_events (provider, event_id, event_type, processed)
    values ('PAYPAL', ${eid}, ${String(event.event_type ?? "")}, false)`;
  const resource = (event.resource ?? {}) as Record<string, unknown>;
  const payoutItem = (resource.payout_item ?? {}) as Record<string, unknown>;
  const batchRef = String(resource.payout_batch_id ?? resource.sender_batch_id ?? "");
  const itemStatus = String(resource.transaction_status ?? payoutItem.transaction_status ?? "");
  const eventType = String(event.event_type ?? "");
  // Reconcile payer-originated checkout captures from PayPal's signed webhook.
  if (["PAYMENT.CAPTURE.COMPLETED", "PAYMENT.CAPTURE.PENDING", "PAYMENT.CAPTURE.DENIED"].includes(eventType)) {
    const supplementary = (resource.supplementary_data ?? {}) as Record<string, unknown>;
    const related = (supplementary.related_ids ?? {}) as Record<string, unknown>;
    const paypalOrderId = String(related.order_id ?? "");
    if (paypalOrderId) {
      const [checkout] = await sql`select o.*, s.name as station_name from gmm_paypal_checkout_orders o join gmm_stations s on s.id = o.station_id and s.user_id = o.user_id where o.paypal_order_id = ${paypalOrderId} limit 1`;
      if (checkout) {
        const amount = (resource.amount ?? {}) as Record<string, unknown>;
        const eventStatus = eventType === "PAYMENT.CAPTURE.COMPLETED" ? "COMPLETED" : eventType === "PAYMENT.CAPTURE.PENDING" ? "PENDING" : "DENIED";
        try {
          await recordPaypalCheckoutCapture(sql, checkout, { captureId: String(resource.id ?? ""), amount: String(amount.value ?? ""), currency: String(amount.currency_code ?? ""), status: eventStatus });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Checkout webhook reconciliation failed";
          await sql`update gmm_paypal_checkout_orders set error_message = ${msg.slice(0, 500)}, updated_at = now() where id = ${asInt(checkout.id)} and status <> 'CAPTURED'`;
          await audit(sql, String(checkout.user_id), "paypal.checkout.webhook_reconcile_failed", `checkout_id=${asInt(checkout.id)};event=${eventType};reason=${msg.slice(0, 200)}`);
        }
      }
    }
  }
  if (batchRef) {
    const [wrow] = await sql`select * from gmm_withdrawals where provider_reference = ${batchRef} limit 1`;
    if (wrow) {
      const userId = String(wrow.user_id);
      let status = String(wrow.status);
      if (eventType.endsWith(".SUCCEEDED") || itemStatus === "SUCCESS") status = "COMPLETED";
      else if (eventType.endsWith(".FAILED") || ["FAILED", "DENIED"].includes(itemStatus)) status = "FAILED";
      else if (
        eventType.endsWith(".RETURNED") ||
        eventType.endsWith(".REVERSED") ||
        ["RETURNED", "REVERSED", "BLOCKED"].includes(itemStatus)
      )
        status = "REVERSED";
      else if (eventType.endsWith(".CANCELED") || itemStatus === "CANCELED") status = "CANCELLED";
      await sql`update gmm_withdrawals set status = ${status} where id = ${asInt(wrow.id)}`;
      await sql`update gmm_provider_records set status = ${status}, raw_status = ${JSON.stringify(event)}, updated_at = now()
        where reference = ${batchRef}`;
      const w = mapWithdrawal({ ...wrow, status });
      if (status === "COMPLETED") await applyProviderStatus(sql, userId, w, "COMPLETED", batchRef);
      if (status === "REVERSED") await applyProviderStatus(sql, userId, w, "REVERSED", batchRef);
    }
  }
  await sql`update gmm_webhook_events set processed = true where event_id = ${eid}`;
  return { ok: true, processed: true };
}

export type { NotificationRow };
