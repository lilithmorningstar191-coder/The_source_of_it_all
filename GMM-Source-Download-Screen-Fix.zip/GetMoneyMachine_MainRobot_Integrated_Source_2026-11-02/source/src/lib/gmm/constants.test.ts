import test from "node:test";
import assert from "node:assert/strict";
import { FIELD_TEAM_STATION_COUNT, STATION_BLURBS, STATION_NAMES, GMM_TRANSFER_FLOW, assertGmmTransferFlow } from "./constants.ts";

test("Get Money Machine preserves exactly its original 15 Field Team Stations", () => {
  assert.equal(STATION_NAMES.length, FIELD_TEAM_STATION_COUNT);
  assert.equal(STATION_BLURBS.length, FIELD_TEAM_STATION_COUNT);
  assert.deepEqual(STATION_NAMES.slice(0, 15), [
    "Free Money Finder", "Unclaimed Funds", "Refund Recovery",
    "Rebate Finder", "Cashback Hub", "Rewards Hub",
    "Bonus Finder", "Fee Recovery",
    "Overpayment Recovery", "Subscription Credits",
    "Claims & Settlements", "Business Incentives",
    "Public Funds Finder", "Revenue Finder", "Reinvestment",
  ]);
  assert.equal(STATION_NAMES.length, 15);
});


test("GMM transfer direction is locked from the ledger to PayPal with one CEO authorization", () => {
  assert.equal(GMM_TRANSFER_FLOW.source, "GMM_LEDGER");
  assert.equal(GMM_TRANSFER_FLOW.destination, "PAYPAL_RECEIVING_ACCOUNT");
  assert.equal(assertGmmTransferFlow({ source: "GMM_LEDGER", destination: "PAYPAL_RECEIVING_ACCOUNT", ceoConfirmed: true }).status, "AWAITING_PROVIDER_RECEIPT");
  assert.throws(() => assertGmmTransferFlow({ source: "PAYPAL", destination: "GMM_LEDGER", ceoConfirmed: true }), /source must be GMM Ledger/);
  assert.throws(() => assertGmmTransferFlow({ source: "GMM_LEDGER", destination: "PAYPAL_RECEIVING_ACCOUNT", ceoConfirmed: false }), /CEO authorization/);
  assert.equal(assertGmmTransferFlow({ source: "GMM_LEDGER", destination: "PAYPAL_RECEIVING_ACCOUNT", ceoConfirmed: true, providerReceiptConfirmed: true }).status, "SUCCESSFUL_TRANSFER");
});
