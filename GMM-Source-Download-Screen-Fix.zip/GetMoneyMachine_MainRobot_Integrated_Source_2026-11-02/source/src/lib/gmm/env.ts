import { env } from "@/lib/env.server";

export function gmmNativeTransferConfigured(): boolean {
  return Boolean(env("GMM_NATIVE_TRANSFER_URL") && env("GMM_NATIVE_TRANSFER_SECRET"));
}

export function stripeConfigured(): boolean {
  return Boolean(env("STRIPE_SECRET_KEY"));
}

export function paypalConfigured(): boolean {
  return Boolean(
    env("PAYPAL_CLIENT_ID") && env("PAYPAL_CLIENT_SECRET") && env("PAYPAL_WEBHOOK_ID"),
  );
}

export function paypalClientId(): string | undefined {
  return env("PAYPAL_CLIENT_ID");
}

export function paypalClientSecret(): string | undefined {
  return env("PAYPAL_CLIENT_SECRET");
}

export function paypalWebhookId(): string | undefined {
  return env("PAYPAL_WEBHOOK_ID");
}

export function settlementKey(): string | undefined {
  return env("SETTLEMENT_KEY");
}

const CONFIG_LOCATION =
  "Server environment variables for this deployment. They are not stored in the ledger.";

function missing(keys: string[]) {
  return keys.filter((key) => !env(key));
}

export function providerStatusMap() {
  const stripeMissing = missing(["STRIPE_SECRET_KEY"]);
  const paypalMissing = missing([
    "PAYPAL_CLIENT_ID",
    "PAYPAL_CLIENT_SECRET",
    "PAYPAL_WEBHOOK_ID",
  ]);
  const plaidMissing = missing(["PLAID_CLIENT_ID", "PLAID_SECRET"]);
  const visaMissing = missing([
    "VISA_API_KEY",
    "VISA_SHARED_SECRET",
    "VISA_ACQUIRING_BIN",
    "VISA_MERCHANT_ID",
  ]);
  const cashMissing = missing([
    "CASHAPP_CLIENT_ID",
    "CASHAPP_API_KEY_ID",
    "CASHAPP_API_SECRET",
  ]);
  return {
    STRIPE_CONNECT: {
      configured: stripeMissing.length === 0,
      mode: env("STRIPE_SECRET_KEY")?.startsWith("sk_live_") ? "live" as const : "test_or_unconfigured" as const,
      provider: "Stripe Connect transfers to connected accounts",
      missing: stripeMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
    PAYPAL: {
      configured: paypalMissing.length === 0,
      mode: "live" as const,
      provider: "PayPal Payouts",
      missing: paypalMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
    ACH: {
      configured: plaidMissing.length === 0,
      provider: "Plaid Transfer",
      missing: plaidMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
    ONEPAY: {
      configured: plaidMissing.length === 0,
      provider: "Plaid Transfer to linked OnePay account",
      missing: plaidMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
    DEBIT_CARD: {
      configured: visaMissing.length === 0,
      provider: "Visa Direct",
      missing: visaMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
    CASH_APP: {
      configured: cashMissing.length === 0,
      provider: "Cash App Pay Payouts",
      missing: cashMissing,
      config_location: CONFIG_LOCATION,
      issues_bank_numbers: false,
    },
  };
}
