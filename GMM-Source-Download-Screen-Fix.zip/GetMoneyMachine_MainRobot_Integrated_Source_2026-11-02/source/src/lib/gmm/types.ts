export type StationState = {
  id: number;
  name: string;
  enabled: boolean;
  active: boolean;
  paused: boolean;
  emergency_stopped: boolean;
  status: "EMERGENCY STOPPED" | "PAUSED" | "RUNNING" | "STOPPED";
  last_activity: string | null;
  last_scan_at: string | null;
  cycle_started_at: string | null;
  next_cycle_at: string | null;
  cycle_count: number;
  cycle_minutes: number;
  paused_remaining_seconds: number;
  /** Sum of completed ledger collections assigned to this station; excludes unassigned opening funds. */
  station_earnings: string;
  /** Number of completed ledger collections assigned to this station. */
  completed_collections: number;
};

export type ProviderBalanceState = {
  status: "LIVE" | "TEST_MODE" | "NOT_CONFIGURED" | "UNAVAILABLE";
  /** Provider-reported USD amount; null means no reliable reading is available. */
  available: string | null;
  /** Provider-reported USD funds not yet available for transfer. */
  pending: string | null;
  /** Available provider funds minus this app's local in-flight payout reservations. */
  spendable: string;
  /** Active payout reservations plus payouts completed after a potentially stale provider snapshot. */
  reserved: string;
  as_of: string | null;
  message: string | null;
};

export type BalanceState = {
  /** Total of confirmed live execution-rail balances available to the GMM Ledger payout orchestrator. */
  available: string;
  display_available: string;
  /** Sum of provider-specific available funds less active reservations. */
  spendable: string;
  transferable: string;
  /** Sum of provider-reported pending balances. */
  pending: string;
  /** Internal GMM Ledger accounting total, tracked separately from externally confirmed rail liquidity. */
  completed_ledger: string;
  currency: "USD";
  source: "provider_balances";
  opening_balance: string;
  display_source: "provider_balances";
  status: "READY" | "PARTIAL" | "UNAVAILABLE" | "NOT_CONFIGURED";
  /** Local payout holds/recent deductions, including payouts not yet reflected in delayed provider reports. */
  reserved: string;
  as_of: string | null;
  stripe: ProviderBalanceState;
  paypal: ProviderBalanceState;
};

export type DestinationState = {
  id: number;
  type: string;
  label: string;
  external_id: string;
  enabled: boolean;
  created_at: string | null;
};

export type WithdrawalState = {
  id: number;
  amount: string;
  destination_id: number;
  status: string;
  provider_reference: string | null;
  error_message: string | null;
  created_at: string | null;
};

export type LedgerRow = {
  id: number;
  kind: string;
  station_id: number | null;
  amount: string;
  status: string;
  description: string;
  provider_reference: string | null;
  created_at: string | null;
};

export type OpportunityState = {
  id: number;
  station_id: number;
  title: string;
  state: string;
  estimated_value: string | null;
  verified_value: string | null;
  source_url: string | null;
  evidence: string | null;
  error_message: string | null;
  created_at: string | null;
  updated_at: string | null;
};

export type AuditRow = {
  id: number;
  action: string;
  detail: string;
  created_at: string | null;
};

export type NotificationRow = {
  id: number;
  kind: string;
  title: string;
  message: string;
  read: boolean;
  created_at: string | null;
};

export type ConnectorState = {
  station_id: number;
  station_name: string;
  connector_type: string;
  endpoint: string | null;
  enabled: boolean;
};

export type ProviderStatus = {
  configured: boolean;
  provider?: string;
  mode?: string;
  missing?: string[];
  config_location?: string;
  issues_bank_numbers?: boolean;
};

export type FundingSource = {
  id: number;
  kind: string;
  label: string;
  provider: string | null;
  provider_account_id: string | null;
  has_account_number: boolean;
  has_routing_number: boolean;
};

export type AppState = {
  stations: StationState[];
  balance: BalanceState;
  paypal: { provider: string; configured: boolean; environment: string; mode: string };
  destinations: DestinationState[];
  withdrawals: WithdrawalState[];
  funding_source: FundingSource;
  providers: Record<string, ProviderStatus>;
  notifications: NotificationRow[];
  scanner: {
    enabled: boolean;
    mode: string;
    fabricated_results: boolean;
    cycle_minutes: number;
  };
};
