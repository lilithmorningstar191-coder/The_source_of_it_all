import { env } from "@/lib/env.server";

export function stripeSecretKey(): string | undefined {
  return env("STRIPE_SECRET_KEY");
}

export async function createStripeConnectTransfer(opts: {
  amount: string;
  connectedAccountId: string;
  reference: string;
}) {
  const key = stripeSecretKey();
  if (!key) return null;
  if (!/^acct_[A-Za-z0-9]+$/.test(opts.connectedAccountId)) {
    throw new Error("Stripe destination must be a connected account ID beginning with acct_.");
  }
  const cents = Math.round(Number(opts.amount) * 100);
  if (!Number.isSafeInteger(cents) || cents <= 0) throw new Error("Invalid payout amount.");
  const form = new URLSearchParams({
    amount: String(cents),
    currency: "usd",
    destination: opts.connectedAccountId,
    description: `Get Money Machine payout ${opts.reference}`.slice(0, 500),
    transfer_group: opts.reference.slice(0, 200),
  });
  const response = await fetch("https://api.stripe.com/v1/transfers", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/x-www-form-urlencoded",
      "Idempotency-Key": `gmm-${opts.reference}`.slice(0, 255),
    },
    body: form,
  });
  const body = (await response.json().catch(() => ({}))) as {
    id?: string;
    error?: { message?: string };
  };
  if (!response.ok || !body.id) {
    throw new Error(`Stripe Connect transfer failed (${response.status}): ${body.error?.message ?? "provider error"}`);
  }
  return {
    provider: "STRIPE_CONNECT",
    // Stripe confirms the transfer object was created and credited to the connected
    // account balance. This does not claim that a separate bank payout has settled.
    status: "COMPLETED",
    provider_reference: body.id,
    raw: { id: body.id, destination: opts.connectedAccountId },
  };
}


export type StripeBalanceSnapshot = {
  available_usd: string;
  pending_usd: string;
  livemode: boolean;
  as_of: string;
};

/** Reads the platform account's actual Stripe balance. Test-mode funds are never spendable. */
export async function readStripeBalance(): Promise<StripeBalanceSnapshot> {
  const key = stripeSecretKey();
  if (!key) throw new Error("Stripe is not configured.");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch("https://api.stripe.com/v1/balance", {
      method: "GET",
      headers: { Authorization: `Bearer ${key}` },
      signal: controller.signal,
    });
    const body = (await response.json().catch(() => ({}))) as {
      livemode?: boolean;
      available?: Array<{ currency?: string; amount?: number }>;
      pending?: Array<{ currency?: string; amount?: number }>;
      error?: { message?: string };
    };
    if (!response.ok) {
      throw new Error(`Stripe balance lookup failed (${response.status}).`);
    }
    const sumUsd = (items: Array<{ currency?: string; amount?: number }> = []) =>
      items.filter((item) => String(item.currency).toLowerCase() === "usd")
        .reduce((total, item) => total + Number(item.amount ?? 0), 0) / 100;
    return {
      available_usd: Math.max(0, sumUsd(body.available)).toFixed(2),
      pending_usd: Math.max(0, sumUsd(body.pending)).toFixed(2),
      livemode: body.livemode === true,
      as_of: new Date().toISOString(),
    };
  } finally {
    clearTimeout(timeout);
  }
}
