import {
  paypalClientId,
  paypalClientSecret,
  paypalWebhookId,
} from "./env";

const PAYPAL_HOST = "https://api-m.paypal.com";

export class ProviderError extends Error {
  status: number;
  constructor(message: string, status = 502) {
    super(message);
    this.status = status;
  }
}

async function accessToken(id: string, secret: string): Promise<string> {
  const basic = Buffer.from(`${id}:${secret}`).toString("base64");
  const res = await fetch(`${PAYPAL_HOST}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      Accept: "application/json",
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const body = (await res.json().catch(() => ({}))) as { access_token?: string };
  if (!res.ok || !body.access_token) {
    throw new ProviderError(`PayPal authentication failed (${res.status})`);
  }
  return body.access_token;
}

export async function assertPaypalCredentials(clientId: string, clientSecret: string) {
  await accessToken(clientId, clientSecret);
}

/** Ensure the webhook ID exists in the live app authenticated by these credentials. */
export async function assertPaypalWebhook(
  clientId: string,
  clientSecret: string,
  webhookId: string,
): Promise<void> {
  const token = await accessToken(clientId, clientSecret);
  const res = await fetch(
    `${PAYPAL_HOST}/v1/notifications/webhooks/${encodeURIComponent(webhookId)}`,
    { headers: { Authorization: `Bearer ${token}`, Accept: "application/json" } },
  );
  const body = (await res.json().catch(() => ({}))) as { id?: string; name?: string; message?: string };
  if (!res.ok || body.id !== webhookId) {
    throw new ProviderError(
      `PayPal webhook verification failed (${res.status}): ${body.message || body.name || "webhook ID not found for these live app credentials"}`,
      res.status >= 400 && res.status < 500 ? 400 : 502,
    );
  }
}

export async function createPaypalPayout(opts: {
  amount: string;
  recipient: string;
  recipientType: "EMAIL" | "PHONE";
  reference: string;
  clientId: string;
  clientSecret: string;
}) {
  const token = await accessToken(opts.clientId, opts.clientSecret);
  const batchId = `GMM-${opts.reference}`.slice(0, 255);
  const res = await fetch(`${PAYPAL_HOST}/v1/payments/payouts`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      "PayPal-Request-Id": batchId,
    },
    body: JSON.stringify({
      sender_batch_header: {
        sender_batch_id: batchId,
        email_subject: "GET MONEY MACHINE payout",
        email_message: "A payout has been initiated.",
      },
      items: [
        {
          recipient_type: opts.recipientType,
          amount: { value: opts.amount, currency: "USD" },
          receiver: opts.recipient,
          note: opts.reference,
          sender_item_id: opts.reference,
        },
      ],
    }),
  });
  const body = (await res.json().catch(() => ({}))) as {
    message?: string;
    name?: string;
    batch_header?: { batch_status?: string; payout_batch_id?: string };
    items?: Array<{ transaction_status?: string }>;
  };
  if (!res.ok) {
    throw new ProviderError(
      `PayPal payout failed (${res.status}): ${body.message || body.name || "provider error"}`,
    );
  }
  const header = body.batch_header ?? {};
  // For a one-item batch, prefer the recipient item's status when the provider
  // returns it; a SUCCESS batch can still contain individual items on hold/fail.
  const itemStatus = body.items?.[0]?.transaction_status;
  return {
    provider: "PAYPAL",
    status: itemStatus ?? header.batch_status ?? "PENDING",
    provider_reference: header.payout_batch_id ?? batchId,
    raw: body,
  };
}

export async function getPaypalPayout(
  payoutBatchId: string,
  clientId: string,
  clientSecret: string,
) {
  const token = await accessToken(clientId, clientSecret);
  const res = await fetch(`${PAYPAL_HOST}/v1/payments/payouts/${payoutBatchId}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ProviderError(`PayPal payout lookup failed (${res.status})`);
  return body as Record<string, unknown>;
}



/** Create a real payer-approved PayPal Checkout order. This collects payment from a payer; it does not move existing station ledger funds. */
export async function createPaypalCheckoutOrder(opts: {
  clientId: string; clientSecret: string; amount: string; currency?: string;
  reference: string; returnUrl: string; cancelUrl: string;
}) {
  const token = await accessToken(opts.clientId, opts.clientSecret);
  const amount = Number(opts.amount);
  if (!Number.isFinite(amount) || amount <= 0 || Math.round(amount * 100) !== amount * 100) {
    throw new ProviderError("PayPal checkout amount must be a positive USD amount with at most two decimal places", 400);
  }
  const currency = opts.currency ?? "USD";
  if (currency !== "USD") throw new ProviderError("Only USD checkout is enabled in this GMM integration", 400);
  const res = await fetch(`${PAYPAL_HOST}/v2/checkout/orders`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json", Prefer: "return=representation", "PayPal-Request-Id": `GMM-ORDER-${opts.reference}`.slice(0, 108) },
    body: JSON.stringify({ intent: "CAPTURE", purchase_units: [{ reference_id: opts.reference, custom_id: opts.reference, amount: { currency_code: currency, value: amount.toFixed(2) }, description: "Get Money Machine Field Team Station payment" }], application_context: { brand_name: "GET MONEY MACHINE", user_action: "PAY_NOW", return_url: opts.returnUrl, cancel_url: opts.cancelUrl } }),
  });
  const body = await res.json().catch(() => ({})) as { id?: string; status?: string; links?: Array<{rel?: string; href?: string}>; message?: string; name?: string };
  if (!res.ok || !body.id) throw new ProviderError(`PayPal order creation failed (${res.status}): ${body.message || body.name || "provider error"}`, res.status >= 400 && res.status < 500 ? 400 : 502);
  const approvalUrl = body.links?.find((link) => link.rel === "payer-action" || link.rel === "approve")?.href;
  if (!approvalUrl) throw new ProviderError("PayPal created an order but did not return an approval URL", 502);
  return { orderId: body.id, status: body.status ?? "CREATED", approvalUrl };
}

/** Capture only after the payer has approved; callers must reconcile the response before posting ledger earnings. */
export async function capturePaypalCheckoutOrder(opts: { clientId: string; clientSecret: string; orderId: string }) {
  const token = await accessToken(opts.clientId, opts.clientSecret);
  const res = await fetch(`${PAYPAL_HOST}/v2/checkout/orders/${encodeURIComponent(opts.orderId)}/capture`, {
    method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json", Prefer: "return=representation", "PayPal-Request-Id": `GMM-CAPTURE-${opts.orderId}`.slice(0, 108) }, body: "{}",
  });
  const body = await res.json().catch(() => ({})) as { id?: string; status?: string; message?: string; name?: string; purchase_units?: Array<{payments?: {captures?: Array<{id?: string; status?: string; amount?: {value?: string; currency_code?: string}} >}}> };
  if (!res.ok) throw new ProviderError(`PayPal capture failed (${res.status}): ${body.message || body.name || "provider error"}`, res.status >= 400 && res.status < 500 ? 409 : 502);
  const capture = body.purchase_units?.flatMap((unit) => unit.payments?.captures ?? []).find((item) => item.id);
  return { orderId: body.id ?? opts.orderId, orderStatus: body.status ?? "UNKNOWN", captureId: capture?.id ?? null, captureStatus: capture?.status ?? "UNKNOWN", amount: capture?.amount?.value ?? null, currency: capture?.amount?.currency_code ?? null };
}

/** Search PayPal's own transaction report; this verifies a credit, it does not initiate one. */
export async function findPaypalIncomingCredit(opts: {
  clientId: string;
  clientSecret: string;
  transactionId: string;
}) {
  const transactionId = opts.transactionId.trim();
  if (!/^[A-Za-z0-9_-]{1,24}$/.test(transactionId)) {
    throw new ProviderError("Enter a valid PayPal transaction ID", 400);
  }
  const token = await accessToken(opts.clientId, opts.clientSecret);
  const end = new Date();
  const start = new Date(end.getTime() - 7 * 24 * 60 * 60 * 1000);
  const isoMinute = (d: Date) => d.toISOString().replace(/\.\d{3}Z$/, "Z");
  const query = new URLSearchParams({
    transaction_id: transactionId,
    start_date: isoMinute(start),
    end_date: isoMinute(end),
    fields: "all",
    page_size: "100",
  });
  const res = await fetch(`${PAYPAL_HOST}/v1/reporting/transactions?${query}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
  });
  const body = await res.json().catch(() => ({})) as {
    transaction_details?: Array<Record<string, unknown>>;
    message?: string;
    name?: string;
  };
  if (!res.ok) {
    throw new ProviderError(`PayPal Transaction Search failed (${res.status}): ${body.message || body.name || "check reporting/search permission"}`, res.status >= 400 && res.status < 500 ? 400 : 502);
  }
  const rows = body.transaction_details ?? [];
  const match = rows.find((row) => {
    const info = (row.transaction_info ?? {}) as Record<string, unknown>;
    return String(info.transaction_id ?? "") === transactionId;
  });
  if (!match) throw new ProviderError("PayPal has not returned that transaction in Transaction Search yet. Reporting can lag by up to three hours; no receipt was recorded.", 409);
  const info = (match.transaction_info ?? {}) as Record<string, unknown>;
  const amount = (info.transaction_amount ?? {}) as Record<string, unknown>;
  const eventCode = String(info.transaction_event_code ?? "");
  const status = String(info.transaction_status ?? "");
  const currency = String(amount.currency_code ?? "");
  const value = Number(amount.value);
  if (!(status === "S" && ["T0300", "T0303"].includes(eventCode) && currency === "USD" && Math.round(value * 100) === 20000)) {
    throw new ProviderError("The PayPal transaction exists, but it does not match a $200 USD bank-deposit/EFT-credit test. No receipt was recorded.", 409);
  }
  // Store only the fields needed for audit/reconciliation, not a full account report.
  return {
    transaction_id: transactionId,
    event_code: eventCode,
    status,
    amount: value.toFixed(2),
    currency,
    initiation_date: String(info.transaction_initiation_date ?? ""),
    updated_date: String(info.transaction_updated_date ?? ""),
    balance_affecting: String((match as Record<string, unknown>).transaction_info ? info.transaction_event_code : ""),
  };
}


/** Automatically discover a successful $200 incoming bank/EFT credit after a test was authorized.
 * Returns null while PayPal has no matching report row; reporting may lag by several hours.
 * This observes incoming money only and does not initiate or manufacture a transfer.
 */
export async function findRecentPaypalIncomingCredit(opts: {
  clientId: string;
  clientSecret: string;
  since: string | Date;
}) {
  const token = await accessToken(opts.clientId, opts.clientSecret);
  const end = new Date();
  const since = new Date(opts.since);
  if (!Number.isFinite(since.getTime())) throw new ProviderError("Deposit test creation time is invalid", 400);
  // PayPal Transaction Search supports a bounded reporting window. Limit to the most recent 30 days.
  const start = new Date(Math.max(since.getTime(), end.getTime() - 30 * 24 * 60 * 60 * 1000));
  const iso = (d: Date) => d.toISOString().replace(/\.\d{3}Z$/, "Z");
  const query = new URLSearchParams({
    start_date: iso(start), end_date: iso(end), fields: "all", page_size: "100",
  });
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  let res: Response;
  try {
    res = await fetch(`${PAYPAL_HOST}/v1/reporting/transactions?${query}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" }, signal: controller.signal,
    });
  } finally { clearTimeout(timeout); }
  const body = await res.json().catch(() => ({})) as {
    transaction_details?: Array<Record<string, unknown>>; message?: string; name?: string;
  };
  if (!res.ok) throw new ProviderError(`PayPal Transaction Search failed (${res.status}): ${body.message || body.name || "check reporting/search permission"}`, res.status >= 400 && res.status < 500 ? 400 : 502);
  const candidates = (body.transaction_details ?? []).flatMap((row) => {
    const info = (row.transaction_info ?? {}) as Record<string, unknown>;
    const amount = (info.transaction_amount ?? {}) as Record<string, unknown>;
    const eventCode = String(info.transaction_event_code ?? "");
    const status = String(info.transaction_status ?? "");
    const currency = String(amount.currency_code ?? "");
    const value = Number(amount.value);
    const date = new Date(String(info.transaction_initiation_date ?? info.transaction_updated_date ?? ""));
    if (status !== "S" || !["T0300", "T0303"].includes(eventCode) || currency !== "USD" || Math.round(value * 100) !== 20000 || !Number.isFinite(date.getTime()) || date < since) return [];
    return [{ transaction_id: String(info.transaction_id ?? ""), event_code: eventCode, status, amount: value.toFixed(2), currency,
      initiation_date: String(info.transaction_initiation_date ?? ""), updated_date: String(info.transaction_updated_date ?? "") }];
  }).filter((row) => row.transaction_id.length > 0);
  if (candidates.length === 0) return null;
  if (candidates.length > 1) throw new ProviderError("More than one matching $200 PayPal credit was found after this test began. No credit was auto-assigned; resolve the ambiguity before another test.", 409);
  return candidates[0];
}

export async function verifyPaypalWebhook(
  headers: Headers,
  event: Record<string, unknown>,
  creds?: { clientId: string; clientSecret: string; webhookId: string },
) {
  const webhookId = creds?.webhookId || paypalWebhookId();
  const clientId = creds?.clientId || paypalClientId();
  const clientSecret = creds?.clientSecret || paypalClientSecret();
  const required = [
    "paypal-auth-algo",
    "paypal-cert-url",
    "paypal-transmission-id",
    "paypal-transmission-sig",
    "paypal-transmission-time",
  ];
  if (!webhookId || !clientId || !clientSecret || required.some((k) => !headers.get(k))) {
    throw new ProviderError("Invalid PayPal webhook headers", 400);
  }
  const token = await accessToken(clientId, clientSecret);
  const res = await fetch(`${PAYPAL_HOST}/v1/notifications/verify-webhook-signature`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      auth_algo: headers.get("paypal-auth-algo"),
      cert_url: headers.get("paypal-cert-url"),
      transmission_id: headers.get("paypal-transmission-id"),
      transmission_sig: headers.get("paypal-transmission-sig"),
      transmission_time: headers.get("paypal-transmission-time"),
      webhook_id: webhookId,
      webhook_event: event,
    }),
  });
  const body = (await res.json().catch(() => ({}))) as {
    verification_status?: string;
  };
  if (!res.ok || body.verification_status !== "SUCCESS") {
    throw new ProviderError("Invalid PayPal webhook signature", 400);
  }
  return true;
}

/** Live production only. Sandbox hosts are never used. */
export function paypalLiveEnv(): string {
  return "live";
}


export type PaypalBalanceSnapshot = {
  available_usd: string;
  pending_usd: string;
  as_of: string | null;
};

/**
 * Reads the PayPal merchant's provider-reported USD balance. PayPal's reporting
 * endpoint can be stale by up to three hours and requires balances/read scope;
 * callers must display the as-of timestamp and must not treat a failed read as $0.
 */
export async function readPaypalBalance(
  clientId: string,
  clientSecret: string,
): Promise<PaypalBalanceSnapshot> {
  const token = await accessToken(clientId, clientSecret);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    const url = new URL(`${PAYPAL_HOST}/v1/reporting/balances`);
    url.searchParams.set("currency_code", "USD");
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "PayPal-Enforce-ISO8601-Format": "true",
      },
      signal: controller.signal,
    });
    const body = (await res.json().catch(() => ({}))) as {
      balances?: Array<{
        currency?: string;
        currency_code?: string;
        available_balance?: { value?: string; currency_code?: string };
        total_balance?: { value?: string; currency_code?: string };
        withheld_balance?: { value?: string; currency_code?: string };
      }>;
      last_refresh_time?: string;
      message?: string;
      name?: string;
    };
    if (!res.ok) {
      if (res.status === 403) {
        throw new ProviderError("PayPal balance access is unavailable. The app may need the balances/read reporting permission.", 502);
      }
      throw new ProviderError(`PayPal balance lookup failed (${res.status}).`, 502);
    }
    const row = (body.balances ?? []).find((item) =>
      String(item.currency ?? item.currency_code ?? item.available_balance?.currency_code ?? "").toUpperCase() === "USD",
    );
    if (!row) {
      return { available_usd: "0.00", pending_usd: "0.00", as_of: body.last_refresh_time ?? null };
    }
    const available = Number(row.available_balance?.value ?? 0);
    const total = Number(row.total_balance?.value ?? available);
    const withheld = Number(row.withheld_balance?.value ?? 0);
    if (![available, total, withheld].every(Number.isFinite)) {
      throw new ProviderError("PayPal returned an unreadable balance snapshot.", 502);
    }
    // PayPal's total balance includes withheld funds. Count only the provider's
    // explicit available_balance as withdrawable; total - available is the remainder.
    return {
      available_usd: Math.max(0, available).toFixed(2),
      pending_usd: Math.max(0, total - available).toFixed(2),
      as_of: body.last_refresh_time ?? null,
    };
  } finally {
    clearTimeout(timeout);
  }
}
