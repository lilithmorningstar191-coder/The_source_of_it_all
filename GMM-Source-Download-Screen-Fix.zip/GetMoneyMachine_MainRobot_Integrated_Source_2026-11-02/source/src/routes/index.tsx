import { createFileRoute } from "@tanstack/react-router";
import { GmmApp } from "@/components/gmm-app";
import { SignInGate } from "@/lib/auth/gates";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <SignInGate><GmmApp /></SignInGate>;
}