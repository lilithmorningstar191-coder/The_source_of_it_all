
## October 29 — station display-name update

The 15 station labels were shortened while preserving their original order and purpose. The migration `0012_station_display_names.sql` renames existing rows in place by `sort_order`, preserving station IDs and linked records. `ensureOwner` also performs a guarded in-place rename for existing owner databases. This change does not configure source connectors or claim any funds were collected.
