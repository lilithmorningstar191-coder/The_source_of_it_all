# PayPal credentials — secure setup

GMM reads PayPal credentials from server-side environment variables:

- `PAYPAL_CLIENT_ID`
- `PAYPAL_CLIENT_SECRET`
- `PAYPAL_WEBHOOK_ID`

Set these in the deployment builder's secret/environment-variable settings. For local development, copy `.env.example` to `.env` and fill in the values locally. Never put live secrets into source code, a distributable ZIP, a browser bundle, screenshots, or a repository.

The Client ID and Client Secret authenticate the PayPal REST app; the webhook ID identifies a webhook registered for that app. They are not themselves a generic API that deposits an arbitrary GMM Ledger balance into the same PayPal balance. Keep the existing server-side transaction verification, and only report a deposit after PayPal confirms an incoming credit.

Because these credentials were previously shared in a chat, rotate the PayPal Client Secret and review/regenerate the webhook configuration as appropriate before live use. Put the new values only in the builder's secret store, not this ZIP.

## GMM-native settlement route (preferred original architecture)

The app supports a provider-neutral GMM-controlled settlement route through `GMM_NATIVE_TRANSFER_URL` and `GMM_NATIVE_TRANSFER_SECRET`. See `GMM_NATIVE_TRANSFER_PATCH.md` for its contract. Configure these only with the original, authorized GMM settlement service; do not use a guessed endpoint or put secrets in the Android app. Without that endpoint, real transfers remain disabled/fail-closed.
