-- Restore the existing 15 Field Team Station funding records that migration 0004
-- removed. These are individual station ledger entries, never a synthetic aggregate
-- opening-balance entry. Only run this restoration automatically when the database
-- contains exactly one GMM owner; multi-owner databases are left untouched to avoid
-- assigning one person's funding records to another user.
WITH station_amounts(name, amount, station_order) AS (
  VALUES
    ('Free Money', 12000.00::numeric, 1),
    ('Unclaimed Property Station', 5200.00::numeric, 2),
    ('Refund Recovery Station', 4800.00::numeric, 3),
    ('Rebate Station', 3750.00::numeric, 4),
    ('Cashback Station', 2900.00::numeric, 5),
    ('Rewards Station', 2650.00::numeric, 6),
    ('Promotional Bonus Station', 3100.00::numeric, 7),
    ('Fee Recovery Station', 2475.00::numeric, 8),
    ('Overpayment Recovery Station', 4125.00::numeric, 9),
    ('Subscription Credit Station', 1980.00::numeric, 10),
    ('Settlement & Claims Station', 6750.00::numeric, 11),
    ('Business Incentive Station', 3600.00::numeric, 12),
    ('Public Opportunity Station', 2300.00::numeric, 13),
    ('Revenue Opportunity Station', 3843.45::numeric, 14),
    ('Reinvestment Station', 700.00::numeric, 15)
), sole_owner AS (
  SELECT min(s.user_id) AS user_id
  FROM gmm_stations s
  WHERE s.name IN (SELECT name FROM station_amounts)
  GROUP BY s.user_id
  HAVING count(DISTINCT s.name) = 15
     AND (SELECT count(DISTINCT owner.user_id)
          FROM gmm_stations owner
          WHERE owner.name IN (SELECT name FROM station_amounts)) = 1
)
INSERT INTO gmm_ledger
  (user_id, kind, station_id, amount, status, description, provider_reference)
SELECT
  owner.user_id,
  'STATION_EARNINGS_IMPORT',
  station.id,
  amounts.amount,
  'COMPLETED',
  'Restored existing Field Team Station funding record. Retained as GMM Ledger accounting; external transferability remains subject to reconciliation with the connected financial account.',
  'GMM-RESTORED-STATION-FUNDING-2026-' || lpad(amounts.station_order::text, 2, '0')
FROM sole_owner owner
JOIN station_amounts amounts ON true
JOIN gmm_stations station
  ON station.user_id = owner.user_id AND station.name = amounts.name
WHERE NOT EXISTS (
  SELECT 1 FROM gmm_ledger existing
  WHERE existing.user_id = owner.user_id
    AND existing.provider_reference = 'GMM-RESTORED-STATION-FUNDING-2026-' || lpad(amounts.station_order::text, 2, '0')
);
