-- Make the ledger's role explicit and durable: GMM Ledger authorizes and records
-- transactions, while Stripe/PayPal are the external execution/funding rails.
-- This migration does not manufacture balances or treat owner attestation as cash.
ALTER TABLE gmm_withdrawals ADD COLUMN IF NOT EXISTS orchestrator text NOT NULL DEFAULT 'GMM_LEDGER';
ALTER TABLE gmm_withdrawals ADD COLUMN IF NOT EXISTS execution_provider text;
ALTER TABLE gmm_withdrawals ADD COLUMN IF NOT EXISTS funding_basis text NOT NULL DEFAULT 'LIVE_PROVIDER_AVAILABLE_BALANCE';

UPDATE gmm_withdrawals w
SET orchestrator = 'GMM_LEDGER',
    execution_provider = upper(d.type),
    funding_basis = 'LIVE_PROVIDER_AVAILABLE_BALANCE'
FROM gmm_destinations d
WHERE d.id = w.destination_id AND d.user_id = w.user_id;

CREATE INDEX IF NOT EXISTS gmm_withdrawals_orchestrator_idx
  ON gmm_withdrawals (user_id, orchestrator, created_at DESC);

UPDATE gmm_funding_sources
SET kind = 'GMM_LEDGER_ORCHESTRATOR',
    label = 'GMM Ledger — internal financial provider and authoritative ledger; Stripe/PayPal are external execution rails'
WHERE kind IN ('LEDGER', 'PROVIDER_BALANCES', 'GMM_LEDGER_ORCHESTRATOR');
