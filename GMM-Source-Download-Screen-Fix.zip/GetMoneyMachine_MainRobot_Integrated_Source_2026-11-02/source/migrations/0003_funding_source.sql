create table if not exists gmm_funding_sources (
  id serial primary key,
  user_id text not null unique,
  kind text not null,
  label text not null,
  provider text,
  provider_account_id text,
  account_number text,
  routing_number text,
  created_at timestamptz not null default now()
);

alter table gmm_withdrawals add column if not exists funding_source_id integer;
