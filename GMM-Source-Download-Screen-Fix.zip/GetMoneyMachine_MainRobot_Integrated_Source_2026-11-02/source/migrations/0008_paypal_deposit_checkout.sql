-- Legacy compatibility migration only. The active GMM receiving-test workflow does NOT use PayPal Checkout.
-- The checkout columns are retained for historical rows so prior database migrations remain forward-compatible.
-- No checkout order is created by the application.
ALTER TABLE gmm_paypal_deposit_tests
  ADD COLUMN IF NOT EXISTS paypal_order_id TEXT,
  ADD COLUMN IF NOT EXISTS paypal_approval_url TEXT,
  ADD COLUMN IF NOT EXISTS paypal_capture_id TEXT,
  ADD COLUMN IF NOT EXISTS paypal_capture_status TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS gmm_paypal_deposit_order_unique
  ON gmm_paypal_deposit_tests (user_id, paypal_order_id)
  WHERE paypal_order_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS gmm_paypal_deposit_capture_unique
  ON gmm_paypal_deposit_tests (user_id, paypal_capture_id)
  WHERE paypal_capture_id IS NOT NULL;
