-- PayPal Checkout payments are real payer-originated receipts, separate from internal station ledger entries.
CREATE TABLE IF NOT EXISTS gmm_paypal_checkout_orders (
  id BIGSERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  station_id INTEGER NOT NULL REFERENCES gmm_stations(id),
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL DEFAULT 'USD' CHECK (currency = 'USD'),
  status TEXT NOT NULL DEFAULT 'CREATED' CHECK (status IN ('CREATED','APPROVED','CAPTURE_PENDING','CAPTURED','FAILED','CANCELLED')),
  idempotency_key TEXT NOT NULL,
  paypal_order_id TEXT,
  approval_url TEXT,
  paypal_capture_id TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, idempotency_key)
);
CREATE UNIQUE INDEX IF NOT EXISTS gmm_paypal_checkout_order_id_unique ON gmm_paypal_checkout_orders(paypal_order_id) WHERE paypal_order_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS gmm_paypal_checkout_capture_id_unique ON gmm_paypal_checkout_orders(paypal_capture_id) WHERE paypal_capture_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS gmm_paypal_checkout_user_idx ON gmm_paypal_checkout_orders(user_id, created_at DESC);
