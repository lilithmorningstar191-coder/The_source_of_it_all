-- CEO-authorized $100 PayPal receiving-account test and provider-confirmed reconciliation.
-- Creating a test record never claims funds moved; only matching PayPal Transaction Search evidence can confirm receipt.
CREATE TABLE IF NOT EXISTS gmm_paypal_deposit_tests (
  id BIGSERIAL PRIMARY KEY,
  user_id TEXT NOT NULL,
  station_id INTEGER NOT NULL REFERENCES gmm_stations(id),
  amount NUMERIC(14,2) NOT NULL DEFAULT 100.00 CHECK (amount = 100.00),
  currency TEXT NOT NULL DEFAULT 'USD' CHECK (currency = 'USD'),
  status TEXT NOT NULL DEFAULT 'AWAITING_SOURCE_TRANSFER',
  idempotency_key TEXT NOT NULL,
  ceo_confirmed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paypal_transaction_id TEXT,
  paypal_event_code TEXT,
  paypal_transaction_status TEXT,
  provider_evidence JSONB,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, idempotency_key),
  UNIQUE (user_id, paypal_transaction_id)
);
CREATE INDEX IF NOT EXISTS gmm_paypal_deposit_tests_user_idx
  ON gmm_paypal_deposit_tests (user_id, created_at DESC);
