-- New live receiving tests default to $200.00 USD. Preserve all historical rows and
-- remove only the original fixed-$100 amount constraint from migration 0007.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'gmm_paypal_deposit_tests'::regclass
      AND conname = 'gmm_paypal_deposit_tests_amount_check'
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%amount%100.00%'
  ) THEN
    ALTER TABLE gmm_paypal_deposit_tests
      DROP CONSTRAINT gmm_paypal_deposit_tests_amount_check;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'gmm_paypal_deposit_tests'::regclass
      AND conname = 'gmm_paypal_deposit_amount_positive'
  ) THEN
    ALTER TABLE gmm_paypal_deposit_tests
      ADD CONSTRAINT gmm_paypal_deposit_amount_positive CHECK (amount > 0);
  END IF;
END $$;
ALTER TABLE gmm_paypal_deposit_tests
  ALTER COLUMN amount SET DEFAULT 200.00;
