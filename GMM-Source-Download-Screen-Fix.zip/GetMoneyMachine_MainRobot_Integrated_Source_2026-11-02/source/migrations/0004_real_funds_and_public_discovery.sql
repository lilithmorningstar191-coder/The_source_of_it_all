-- Safety and capability expansion:
-- 1) A discovered opportunity or a hard-coded estimate is never money received.
-- Remove exact legacy synthetic balance imports before they can fund real payouts.
DELETE FROM gmm_ledger
WHERE kind = 'STATION_EARNINGS_IMPORT'
  AND provider_reference LIKE 'USER-STATION-EARNINGS-2026-%';

DELETE FROM gmm_ledger
WHERE kind = 'OPENING_BALANCE'
  AND provider_reference = 'REFERENCE-BALANCE-60173.45-FAILED-TRANSFER';

-- Older connector scans trusted a third-party JSON "COMPLETED" status and credited it.
-- Reverse only those auto-credits whose opportunity evidence is exactly the legacy marker;
-- preserve separately evidenced, manually confirmed collections.
DELETE FROM gmm_ledger l
WHERE l.provider_reference LIKE 'collection:%'
  AND EXISTS (
    SELECT 1 FROM gmm_opportunities o
    WHERE o.id::text = substring(l.provider_reference from 12)
      AND o.user_id = l.user_id
      AND o.evidence = 'External connector response'
  );
UPDATE gmm_opportunities
SET state = 'DETECTED', verified_value = NULL, updated_at = now()
WHERE state = 'COMPLETED' AND evidence = 'External connector response';

-- Source provenance enables deduplication and location/scope labelling.
ALTER TABLE gmm_opportunities ADD COLUMN IF NOT EXISTS source_provider text;
ALTER TABLE gmm_opportunities ADD COLUMN IF NOT EXISTS country_code text;
ALTER TABLE gmm_opportunities ADD COLUMN IF NOT EXISTS source_external_id text;
ALTER TABLE gmm_opportunities ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;
CREATE UNIQUE INDEX IF NOT EXISTS gmm_opportunities_source_identity_idx
  ON gmm_opportunities (user_id, station_id, source_provider, source_external_id)
  WHERE source_external_id IS NOT NULL;

-- Explicit environment selection for PayPal credentials saved in the database.
CREATE TABLE IF NOT EXISTS gmm_rail_secrets (
  provider text PRIMARY KEY, client_id text NOT NULL, client_secret text NOT NULL,
  webhook_id text, updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE gmm_rail_secrets ADD COLUMN IF NOT EXISTS environment text NOT NULL DEFAULT 'sandbox';

-- These destinations had UI labels but no real payout implementation. Disable them and
-- erase any stored bank/card credential-like strings instead of implying they are usable.
UPDATE gmm_destinations
SET enabled = false,
    external_id = '{"redacted":true,"reason":"This payout rail is not implemented"}'
WHERE upper(type) IN ('ACH', 'ONEPAY', 'CASH_APP', 'DEBIT_CARD');
