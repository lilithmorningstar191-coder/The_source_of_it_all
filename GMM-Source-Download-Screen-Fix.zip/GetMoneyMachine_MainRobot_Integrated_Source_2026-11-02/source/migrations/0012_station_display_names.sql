-- Rename only the display labels for the existing 15 GMM stations.
-- Stable station IDs, sort order, connectors, earnings, opportunities, and ledger rows remain intact.
update gmm_stations set name = case sort_order
  when 1 then 'Free Money Finder'
  when 2 then 'Unclaimed Funds'
  when 3 then 'Refund Recovery'
  when 4 then 'Rebate Finder'
  when 5 then 'Cashback Hub'
  when 6 then 'Rewards Hub'
  when 7 then 'Bonus Finder'
  when 8 then 'Fee Recovery'
  when 9 then 'Overpayment Recovery'
  when 10 then 'Subscription Credits'
  when 11 then 'Claims & Settlements'
  when 12 then 'Business Incentives'
  when 13 then 'Public Funds Finder'
  when 14 then 'Revenue Finder'
  when 15 then 'Reinvestment'
  else name end
where sort_order between 1 and 15
  and name in (
    'Free Money','Unclaimed Property Station','Refund Recovery Station','Rebate Station','Cashback Station','Rewards Station','Promotional Bonus Station','Fee Recovery Station','Overpayment Recovery Station','Subscription Credit Station','Settlement & Claims Station','Business Incentive Station','Public Opportunity Station','Revenue Opportunity Station','Reinvestment Station'
  );
