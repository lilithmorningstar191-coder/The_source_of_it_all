-- Replace legacy payer-checkout pending states with the intended worker/source-provider transfer flow.
-- Keep historical order identifiers for auditability, but the application no longer creates or captures checkout orders.
UPDATE gmm_paypal_deposit_tests
SET status = 'AWAITING_SOURCE_TRANSFER',
    error_message = 'Legacy checkout workflow retired. Awaiting a real transfer initiated by the authorized Field Team source provider; no funds are assumed received.',
    updated_at = now()
WHERE status IN ('AWAITING_PAYER_APPROVAL', 'CAPTURE_PENDING');
