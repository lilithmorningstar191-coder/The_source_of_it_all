# Wise Minds Creation — deployment repair

## Changes in this build

- Switched Nitro from the Vercel output preset to `node-server`, matching a Render-hosted Node service rather than emitting a Vercel-specific artifact.
- Added a production `start` script that runs Nitro's Node server output.
- Removed database migrations from the generic build command. Production schema changes must be an explicit, reviewed deployment step with a verified database target and backup; a build should not mutate the financial ledger's database as a side effect.

## Preserved invariants

- Existing app source, API routes, 15 station definitions, migration files, and ledger/transfer safety checks are retained.
- No production ledger rows, balances, database settings, or external transfers were changed by this source repair.
- External transfers still fail closed unless the authorized settlement implementation/configuration is present and its response verifies cleared source funds and a destination receipt for `COMPLETED`.

## Verification

- JavaScript script tests: run with `node --test 'scripts/**/*.test.mjs'`.
- This is a source repair, not proof of production deployment. Dependency installation, full production build, authenticated live API/ledger checks, Android rebuild, and real-money settlement remain unverified until run against the real configured environment.
