# READ FIRST — owner requirements for this release

1. Protect the ledger, all 15 Field Team Station records, source code, payment integrations, and configurations from unauthorized modification. Never silently edit/delete entries. Preserve audit history and obtain the owner's explicit written approval for material changes. The owner's designated opening GMM ledger balance is **$60,173.45 USD**: preserve it exactly, do not reset it, do not label it fictional/simulated/estimated/unverified merely because no external transfer has happened, and do not subtract $60,000 without a matching authorized ledger transaction. New successfully recorded station earnings accrue on top. PayPal receipt verification is a separate external status and must not alter or contradict the GMM ledger balance.
2. Payment acceptance test must be exactly **$200.00 USD in REAL LIVE MONEY**. No PayPal Sandbox, sandbox credentials, simulated payment, or test-money substitute.
3. The owner requires the real-money test to pass **before the final APK/release is delivered for download**. Do not label the package complete or provide it as release-ready if the live test has not passed.
4. The source-to-PayPal transfer rail is a known blocker until a real authorized source-provider API/account is connected. Do not fake or invent it. If blocked, report the exact missing provider/API and stop release.
5. PayPal secrets must remain in server-side secret storage. Rotate secrets that were posted in chat.
6. A success message requires authoritative PayPal evidence of the exact $200.00 USD incoming credit and a unique transaction reference, followed by one auditable GMM reconciliation.
7. Follow `LIVE_200_DOLLAR_RELEASE_GATE.md` and include PASS/FAIL/BLOCKED evidence for every gate.
