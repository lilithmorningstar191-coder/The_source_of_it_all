# Get Money Machine — deep implementation and live-readiness audit

## Implemented in this build

- Preserves exactly the original 15 named Field Team Stations in their original order. No extra worker slots or stations are created.
- Keeps the $60,173.45 historical station-specific ledger restoration across the original 15 station records. The new slots do not receive any of that amount by inference.
- Adds a CEO-confirmed, fixed-$200.00 USD PayPal receiving-test workflow to both the web app and native Android UI.
- Adds authenticated endpoints to create and list test requests and reconcile a test against PayPal Transaction Search.
- The reconciliation checks PayPal's own transaction report for the exact transaction ID, a successful status, USD currency, exactly $200.00, and incoming bank/EFT credit event code `T0300` or `T0303`. It rejects mismatched transactions, duplicate transaction IDs, pending/failed records, and duplicate ledger receipt entries.
- Records the PayPal-confirmed receipt in a separate ledger row (`PAYPAL_DEPOSIT_TEST_RECEIPT`) without counting it a second time as transferable cash.
- Adds idempotency, CEO authorization, station ownership checks, audit events, notifications, and a single-active-test guard. Starting the test does not itself claim or simulate a transfer.
- Identifies the supported transfer route needed for incoming funds: PayPal Payouts sends funds out of an existing PayPal balance and is not an incoming-credit endpoint.
- Maintains the original project structure and makes changes in a separate working copy. The source archive is not modified in place.

## Important live-money boundary

The source-provider execution route is **not yet connected** because this project has no identified/authorized bank-transfer API or provider credentials for the stations, and no PayPal-issued receiving account/routing details are available in this workspace. The app now prepares the test, requires CEO confirmation, and verifies the actual PayPal credit after the real source provider executes the transfer. It does not fabricate an API call to move funds or mark a request received early.

The PayPal app must have the reporting/search permission needed for `GET /v1/reporting/transactions`. PayPal says transaction-search records can lag by up to three hours. The receiving path can only be fully validated after the source provider uses a supported route into the PayPal Business receiving method available on the actual account. PayPal's own account terms/help determine which receiving methods are enabled on that account.

## Validation performed

- Passed: `node --experimental-strip-types --test src/lib/gmm/constants.test.ts` (exactly 15 original station names preserved).
- Passed: TypeScript transpile/syntax checks for `core.ts`, `paypal.ts`, `constants.ts`, `rest.ts`, and `gmm-app.tsx`.
- Passed: `node --check scripts/migrate.mjs`.
- Not completed: full TypeScript typecheck or production web build; project dependencies and required type definitions are not installed in this environment.
- Not completed: native APK build. The Gradle wrapper could not download Gradle 8.9 because network access is unavailable.
- Not completed: apply migration 0007 against the production database, test live credentials/reporting permission, execute a real source-provider transfer, or verify a real PayPal credit. No live transfer was initiated by this build process.

## Before production

1. Install project dependencies and pass the complete typecheck/build/test suite.
2. Apply migrations, including `0007_paypal_test_deposit.sql`, against the target database and confirm the migration record exists.
3. Verify the live PayPal Business REST app, webhook, and Transaction Search reporting permission. Rotate any secret previously pasted into chat.
4. Configure the real source-provider API and its authorized funding account. Verify the PayPal account supports the intended incoming route and use only the PayPal-issued receiving details / provider-supported flow.
5. Execute the $200.00 test through that real source-provider route with CEO approval, then enter the PayPal transaction ID. GMM must report `RECEIVED` only after the live PayPal report confirms the exact credit.
6. Build and install the APK from the included Android project with the production API URL and release signing configuration.
