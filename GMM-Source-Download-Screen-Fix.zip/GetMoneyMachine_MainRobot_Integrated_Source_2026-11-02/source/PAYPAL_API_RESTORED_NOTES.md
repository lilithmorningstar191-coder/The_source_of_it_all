# PayPal API restoration / integration notes

This package preserves the existing server-side PayPal integration source.

Included API behavior in `src/lib/gmm/paypal.ts`:
- OAuth client-credentials authentication against PayPal's live REST host.
- PayPal Payouts API calls (`POST /v1/payments/payouts`) for sending money out to a recipient.
- Payout status lookup.
- PayPal Transaction Search (`GET /v1/reporting/transactions`) to verify incoming credits.
- PayPal balance/reporting helpers and webhook handler in `src/routes/paypal/webhook.ts`.

Required server-side secrets: `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, and `PAYPAL_WEBHOOK_ID`. Configure them in the deployment secret store; do not hard-code secrets into the APK or ZIP. If previously exposed, rotate the client secret.

Important directionality: PayPal Payouts sends money FROM the PayPal account TO a recipient. Transaction Search verifies money that has already arrived; it does not create an incoming deposit. If GMM must accept a customer's payment into PayPal, that is a separate PayPal Checkout Orders v2 create/capture integration. If GMM must move funds from a Field Team Station/source provider into PayPal, the source provider must supply an authorized transfer API. PayPal does not provide a generic endpoint that converts a GMM ledger balance into cash in the owner's PayPal balance.

This archive preserves the existing API source; it does not imply live credentials are configured or that a live transfer has been tested.
