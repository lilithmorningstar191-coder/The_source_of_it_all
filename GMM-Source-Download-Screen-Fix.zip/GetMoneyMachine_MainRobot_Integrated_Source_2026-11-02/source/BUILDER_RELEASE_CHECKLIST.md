# GMM builder release checklist

- [ ] Existing source code, docs, configs, and attachments audited before changes
- [ ] Exactly 15 original Field Team Stations preserved (names, IDs/order, descriptions/config)
- [ ] GMM Ledger remains source side; PayPal remains destination side
- [ ] No checkout/capture or PayPal Payouts substituted for ledger-to-PayPal funding
- [ ] Actual source-provider money movement API verified from code and provider docs
- [ ] CEO authorization once; no second receipt confirmation
- [ ] Atomic reservation, idempotency, unique references, ambiguous outcome reconciliation
- [ ] PayPal webhook signatures verified and events validated/deduplicated
- [ ] Automated incoming credit matching uses amount, currency, receiver and correlation references where available
- [ ] Success popup only after PayPal provider evidence confirms the credit
- [ ] Ledger debit/credit postings reconcile exactly once and avoid double-counting
- [ ] Test coverage includes auth, insufficient funds, duplicate/replay, timeout, rejection, delayed report, wrong receiver, ambiguous same-amount deposit
- [ ] `npm ci`, typecheck, tests, lint, production build all run and results recorded
- [ ] Migrations validated on a disposable/test database
- [ ] UI/browser smoke test run
- [ ] Android APK compiled if required; artifact path verified
- [ ] ZIP integrity checked; no `.env`, secrets, node_modules, caches or private keys
- [ ] Live transfer claim backed by actual provider-side evidence; otherwise explicitly marked not executed
