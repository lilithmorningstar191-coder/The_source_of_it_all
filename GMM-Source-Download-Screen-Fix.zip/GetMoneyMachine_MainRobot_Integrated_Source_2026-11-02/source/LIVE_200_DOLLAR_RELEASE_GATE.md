# GMM — mandatory $200 live-money release gate

## Owner's explicit requirement

Do not deliver the APK or final downloadable release until a real **$200.00 USD** deposit test has been initiated through an authorized, production source-provider transfer rail and independently confirmed as received in the owner's live PayPal account. **No PayPal Sandbox, sandbox credentials, sandbox payment flow, or simulated-money result may be used for this acceptance test.** Build tools may use isolated development environments, but the payment test and PayPal API environment must be live production only.

## Required execution sequence

1. Verify the owner's live PayPal receiving account and secure server-side live API credentials. Rotate any secret previously exposed in chat. Never embed secrets in an APK, source code, browser bundle, or ZIP.
2. Identify and connect the real, authorized source-provider account/API that can send funds to the owner's PayPal account. The 15 GMM Field Team Stations are app records; they do not themselves constitute external bank accounts or transfer rails.
3. Verify that the source provider explicitly supports the requested $200 USD transfer to this destination. Do not manufacture a transfer endpoint or pretend an internal ledger balance can be externally transferred.
4. Obtain the owner's explicit approval immediately before initiating exactly $200.00 USD of real money. No automatic charge or transfer without that approval.
5. Initiate the live transfer through the authorized source provider. Preserve provider reference, timestamp, source, destination, amount, and status.
6. Independently verify the incoming credit using PayPal's authoritative live transaction record/API. Match exactly $200.00 USD, the receiving account, the expected time window, a successful status, and a unique provider transaction ID. Do not rely on a screenshot or user-entered ID alone.
7. Confirm GMM reconciles exactly one receipt to the selected station, preserves the original ledger and audit history, prevents duplicate posting, and issues a success notification only after provider confirmation. Verify failure, pending, duplicate, and mismatched-amount cases do not report success.
8. Run typecheck, tests, lint, production build, database migrations, webhook signature checks, and signed Android APK build. Record evidence for each result.
9. Release/download is **BLOCKED** until the $200 live transfer is genuinely received and all release checks pass. If the source-provider transfer rail is unavailable, report BLOCKED; do not substitute PayPal Checkout, PayPal Payouts, internal ledger entries, Sandbox, or fabricated evidence.

## Current known blocker

The supplied project has PayPal live receiving/reporting code, but the source-to-PayPal transfer API/account has not been identified or connected in this workspace. PayPal Client ID/Secret alone cannot credit arbitrary money into a PayPal balance. Therefore no one should claim the $200 test is complete until the missing authorized source rail is configured and a real transfer is confirmed.

## Required evidence report

- Live source provider and transfer reference: ______________________________
- Owner approval timestamp: _______________________________________________
- Transfer amount/currency: $200.00 USD
- PayPal transaction/capture reference: ____________________________________
- PayPal final status and received timestamp: ______________________________
- GMM station ledger entry and audit reference: _____________________________
- Typecheck/tests/lint/build/APK results: __________________________________
- Final release decision: PASS / BLOCKED (must be BLOCKED if any required evidence is missing)
