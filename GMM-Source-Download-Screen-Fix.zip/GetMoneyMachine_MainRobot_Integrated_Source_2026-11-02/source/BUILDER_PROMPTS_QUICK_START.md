# Builder prompts for Get Money Machine

Use the master prompt first. Then use the following prompts sequentially in the same builder session. The builder must inspect and edit this project, not merely respond with a plan.

## Prompt 1 — Audit the actual project

Read `BUILDER_MASTER_PROMPT.md` and inspect the whole repository. Verify the existing 15 station definitions, source-provider connectors, GMM Ledger implementation, PayPal integration, migrations, environment variables, and Android wrapper. Do not ask the owner to restate the workflow. Report evidence from actual files, then start implementation.

## Prompt 2 — Finish source-to-PayPal execution

Implement the outgoing transfer from GMM Ledger's actual available funds to the owner's connected PayPal receiving account using the existing authorized source-provider API if present. Do not use PayPal checkout/capture or PayPal Payouts. Use server-side credentials, owner authorization, atomic fund reservation, idempotency, provider status lookup, and an explicit state machine. If the repository lacks a supported source rail, finish the adapter and all safely implementable pieces, then name the exact missing provider capability/account permission; do not invent one or fake money movement.

## Prompt 3 — One confirmation, automatic receipt

Keep one CEO approval before initiation. After that, automatically reconcile the receiving transaction using validated PayPal webhooks plus polling/reporting fallback. Correlate the exact incoming credit to the transfer safely, update the ledger once, and display `SUCCESSFUL TRANSFER — $200.00 USD received in PayPal` only after independent provider confirmation. Remove any manual receipt confirmation or transaction-ID entry. Ambiguous or uncorrelated credits must remain pending for reconciliation.

## Prompt 4 — Production hardening and tests

Add/repair database constraints and migrations, authorization and ownership checks, secrets handling, webhook verification, retry and timeout logic, duplicate/replay protections, atomic ledger reservation/posting, observability, and tests for all failure cases in `BUILDER_MASTER_PROMPT.md`. Preserve all existing features and the exact 15 station definitions.

## Prompt 5 — Compile and deliver

Install dependencies and run typecheck, all tests, lint, production build, migrations on a disposable/test database, browser smoke tests, and Android debug APK build if applicable. Fix the errors instead of merely listing them. Create a clean final ZIP with source, migrations, environment example without secrets, docs, and test/build report. Exclude credentials and caches. Verify ZIP integrity. State clearly whether a real-money transfer has actually been executed; never claim it if it has not.

## Builder response format

Return: (1) final ZIP link/path, (2) APK path if built, (3) exact tests/builds run and results, (4) files changed, (5) any remaining blocker backed by evidence, and (6) explicit statement whether a real PayPal credit was verified. No unsupported claims and no new architecture proposal in place of code changes.
