# PayPal automatic deposit visibility and reconciliation

This update removes manual PayPal transaction-ID entry from the normal receiving-test UI.

## Runtime behavior

- CEO authorization creates a single $200.00 USD receiving-test record tied to the selected Field Team Station.
- The funds panel refreshes the provider-reported PayPal balance and automatically queries PayPal Transaction Search for a successful $200.00 USD incoming bank/EFT credit occurring after that test was created.
- A test changes to `RECEIVED` only after a matching successful PayPal reporting record is found. The PayPal transaction reference and evidence are stored and an idempotent ledger/audit record is written.
- If PayPal has not reported the credit yet, the test remains pending. Reporting data can lag; no balance or ledger estimate is substituted for transaction evidence.
- The panel refreshes automatically every two minutes while open and has a manual refresh button. No customer checkout or manual transaction-ID entry is used.

## Important live funding boundary

This code detects and reconciles an incoming credit; it does not originate a transfer from a Field Team Station. A live source-provider account and authorized transfer API must be configured to move the $200.00 to PayPal. A station record in GMM is not itself an external bank account. No live transfer is claimed or initiated by this update.

## Checks performed

- Station constants test passed: exactly 15 original named stations remain; no extra stations are created.
- TypeScript transpile/syntax checks passed for the modified core, PayPal, UI, and REST files.
- Full production typecheck/build and live PayPal API execution were not performed in this environment.
