# GMM full-archive audit and targeted patch notes

## Changes made in this archive

1. **PayPal credentials Save action**
   - The original server action required client ID, client secret, and webhook ID together. That blocked saving valid Live API credentials before a webhook had been created.
   - The action now verifies the Live OAuth credentials first. A webhook ID is optional at initial save, but if supplied it is verified against those credentials. Missing webhook setup is explicitly shown as incomplete; it is not represented as verified.
   - Saving is now a non-submit button with a visible busy state, disabled when the required credential fields are empty, and explicit success/error feedback. The client secret remains server-side and is cleared from the form after successful save.
   - Saving credentials without a new webhook ID preserves any existing stored webhook ID.

2. **PayPal destination email**
   - The PayPal destination form includes a dedicated recipient email field. Its validation now checks a basic email format, and Save Destination is explicitly a button rather than a form submit control.

3. **Payout direction warning**
   - When a saved PayPal destination is selected, the UI now explains that PayPal Payouts sends funds out of PayPal and is not a supported way to move GMM ledger funds into the owner's PayPal account. The existing server-side block remains in place to prevent a misleading or wrong-direction transfer.

4. **$200 live-test amount verification**
   - The PayPal Transaction Search verifier still contained fixed-$100 amount checks even though the UI and deposit workflow had been updated to $200. Those checks and messages now require exactly $200.00 USD.

5. **Migration safety**
   - The original migration loop dropped every check constraint whose definition mentioned `amount`, which could remove unrelated protections. It now targets only the original fixed-$100 constraint by name and expected definition, and adds the positive-amount constraint only if it is absent. Historical records are not rewritten by this migration.

## Findings that remain blocking

- **No source-to-PayPal transfer rail is implemented.** The current project can verify incoming PayPal reporting and create payer-approved Checkout payments, but it does not implement an authorized source-provider mechanism that moves the existing GMM ledger funds to the PayPal receiving account. An internal ledger entry or station balance cannot itself initiate an external transfer.
- **PayPal Payouts is the wrong direction for this requested flow.** The existing backend correctly blocks using PayPal Payouts as if it deposited money into PayPal. Do not remove that block without identifying and implementing a supported source-side transfer API.
- **Station scans depend on configured connectors.** `runScan` returns `not_configured` when a station has no enabled connector with an HTTPS endpoint. Real worldwide search therefore depends on setting up working, authorized data-source endpoints for the stations; the search UI alone does not supply these services.
- **No real $200 transfer or production webhook test has been performed.** The archive has not been connected to the owner's live provider accounts in this audit.

## Verification limitations

A full dependency install/build/test was attempted with `npm ci --ignore-scripts --no-audit --no-fund`, but the command timed out in this environment. Consequently this archive is a **targeted source patch, not a verified release APK**. No claim is made that the production build, migration against the live database, or real-money transaction has passed.

## Data protection

These changes are source-level only. They do not edit, delete, reset, fabricate, or rewrite existing ledger records or station earnings. Apply the migration only after reviewing it against a backup and the actual production schema.
