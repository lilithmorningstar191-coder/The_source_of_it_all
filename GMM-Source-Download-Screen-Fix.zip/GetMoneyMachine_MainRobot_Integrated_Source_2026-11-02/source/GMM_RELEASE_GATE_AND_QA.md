# GMM End-to-End Release Gate and QA Record

## Non-negotiable product contract

- Exactly 15 Field Team Stations, with the original names and order. `Free Money` remains station 1.
- Exactly three tiers: (1) Field Team stations/providers, (2) CEO review and one-time authorization, (3) receiving account with provider-backed evidence.
- The GMM Ledger is the internal accounting/orchestration record. It is not, by itself, an external bank or wallet balance.
- Field Team Station providers’ actual earned activity and attributable earnings must be recorded as earnings with provenance; opportunity estimates or unverified discovery results must not be silently booked as earned amounts. Keep earned/payable ledger accounting distinct from external funds-transfer status.
- A success popup is allowed only after the intended PayPal account's provider data confirms the actual incoming amount, currency, transaction/reference, and a successful/credited state.
- Retries, duplicate requests, webhook replays, reporting delays, timeouts, and uncertain provider responses must not create duplicate transfers or duplicate accounting entries.

## Current source inspection

### Confirmed present

- Stripe platform balance lookup and Stripe Connect transfer implementation.
- PayPal OAuth/API helpers, balance/reporting lookup, incoming-credit search, and payout-status lookup.
- Ledger orchestration, provider balance checks, persisted transfer workflow, idempotency key handling, and PayPal Payouts directionality documented for selecting the correct incoming-transfer integration.
- Static validator checks the required 15 station names/order and several real-money safety invariants.
- Android project and Gradle wrapper are present.

### Release-blocking gap

No production source-transfer rail has been established that can move funds from an actual authorized source account to the user's intended PayPal receiving account. The repository's Stripe transfer is Stripe Connect to a connected Stripe account, not Stripe Treasury and not PayPal. PayPal Payouts moves money outward from an existing PayPal balance. PayPal incoming transaction search can confirm receipt but cannot initiate the transfer.

The missing external contract is: authorized source provider/product, source account or financial-account ID, supported transfer endpoint, required account permissions, recipient/destination routing to the intended PayPal receiving account, idempotency semantics, transfer status endpoint/webhook, and reference that can be reconciled against PayPal's incoming transaction record. These must come from the actual provider account/docs, not be guessed in code.

## Verification performed for this package

- `node scripts/validate-gmm-build.mjs`: PASS. Confirms the 15-station contract and several source-level financial safety invariants.
- `node --test scripts/*.test.mjs`: 197 tests discovered; 188 passed and 9 failed. The failures are in `scripts/grok-pwa-plugin.test.mjs` (share-card metadata/title behavior) and `scripts/migration-plan.test.mjs` (auth schema copy check). They are not proof of a successful GMM payment flow and remain unresolved.
- `npm ci --ignore-scripts --no-audit --no-fund`: timed out in this environment. Dependencies were not available, so full npm test suite, TypeScript typecheck, lint, production build, migrations against a configured database, and Android build were not verified here.
- No real provider transaction was executed and no live PayPal receipt was verified. This package does not claim otherwise.

## Required end-to-end acceptance matrix before release

1. Station scan/worker result creates a provider-sourced activity record with provenance and timestamp; no activity result alone increases spendable external funds.
2. CEO approval is server-side, authenticated, bound to amount/source/destination, recorded once, and cannot be replayed to authorize a different transaction.
3. A retry/double-submit for the same transfer operation returns the existing operation and does not execute it twice; genuinely new transfer requests remain possible as distinct operations.
4. A timeout after source-provider acceptance enters an unknown/reconciliation state and checks provider status before any retry.
5. A provider rejection records a failure reason and does not show success or mark funds received.
6. A webhook replay is signature-verified, deduplicated, and cannot duplicate ledger entries.
7. PayPal reporting delay shows pending/reconciling status rather than false failure or success.
8. Receipt matching requires the intended receiving account, exact amount, currency, provider transaction/reference, and authoritative credited/completed status; amount-only matching is insufficient for production acceptance.
9. An unrelated incoming transaction with the same amount cannot satisfy the transfer.
10. The success popup is emitted only after the authoritative receipt check succeeds and is tied to the matching transfer operation.
11. Tier 3 displays provider-sourced balance/transaction evidence with its as-of time, while distinguishing ledger balance, reserved funds, pending transfer, and confirmed external receipt.
12. Production credentials remain server-side; no secret values are committed to the source tree or shipped in the ZIP.
13. All migrations apply cleanly to the configured production database; rollback/recovery behavior is documented and tested.
14. Full test suite, typecheck, lint, production build, Android build, and a real low-value authorized end-to-end transaction pass before declaring release-ready.

## Final release decision

**NOT YET LIVE-READY.** The source-level static validation passes, but the live source-to-PayPal transfer contract and live receipt evidence are not present, and complete build/test verification could not be completed in this environment. Keep the success popup gated until the missing provider route is implemented and the acceptance matrix is proven with provider evidence.
