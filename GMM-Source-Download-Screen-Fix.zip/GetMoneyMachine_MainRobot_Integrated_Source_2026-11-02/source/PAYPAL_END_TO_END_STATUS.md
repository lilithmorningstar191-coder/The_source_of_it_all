# GMM PayPal end-to-end status

## Implemented in this source package
- Server-only PayPal OAuth authentication; credentials remain in server environment variables or the existing server-side secret store.
- Owner-authenticated routes and persistence for PayPal checkout records, distinct from the source-provider deposit workflow.
- The live deposit test is fixed at $200.00 USD for new requests. PayPal live transaction reporting must confirm the exact stored amount, USD currency, successful status, and unique transaction ID before GMM marks it received.
- Duplicate transaction IDs are guarded against duplicate posting; confirmed receipts create audit evidence and notifications.
- Migration `0011_live_deposit_test_200.sql` changes the new live-test amount while preserving historical records.

## Still blocked
The existing 15 Field Team Stations are application records, not separate financial accounts or transfer rails. The project still cannot move already-recorded GMM ledger earnings into PayPal until a real, authorized source provider and its documented transfer API/account are connected. Do not substitute PayPal Checkout, PayPal Payouts, internal ledger entries, simulated money, or Sandbox for a source-to-PayPal transfer.

## Required production setup and release gate
1. Rotate any PayPal Client Secret that was pasted into chat or another untrusted location. Never put secrets in the APK, source archive, or browser code.
2. Set the live `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, and `PAYPAL_WEBHOOK_ID` in production server-side secret storage.
3. Configure the live webhook URL as `https://<your-deployed-host>/paypal/webhook` and verify webhook signatures.
4. Apply database migrations through `0011_live_deposit_test_200.sql` in numeric order using the project's migration runner.
5. Run typecheck, tests, lint, migration validation, and production build; create and verify a signed release APK if APK delivery is required.
6. Connect and verify the real, authorized source-provider transfer rail that can send $200.00 USD to the owner's live PayPal account.
7. Obtain the owner's explicit approval, initiate the exact $200.00 USD live transfer through that provider, and independently verify the incoming credit through PayPal's live transaction record. Verify exactly one station ledger receipt, a unique transaction reference, audit entries, and a notification. Pending, failed, duplicate, and mismatched transactions must never show success.
8. Do not configure or use PayPal Sandbox for this project's payment acceptance test. Do not deliver the final APK/release as complete until the real-money test and all build/release checks pass.

## Current status
The source-provider transfer rail is not connected in this workspace, and no live $200 transaction, live webhook delivery, production database migration, full production build, or signed Android APK build has been performed. Therefore the required live-money acceptance gate is BLOCKED, not passed.
