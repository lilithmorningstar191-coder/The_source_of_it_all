# Get Money Machine — live financial route and verification

## Implemented in this source package

- Preserves exactly the original 15 named Field Team Stations.
- Keeps CEO authorization between station selection and a live deposit-test request.
- Uses the live PayPal REST host in the payment integration; payment acceptance must not use PayPal Sandbox credentials or simulated money.
- Creates a fixed $200.00 USD live receiving-test record. This record is authorization and reconciliation state only; it does not itself send money.
- Reconciles an incoming credit only when PayPal's live transaction reporting confirms the exact stored amount, USD currency, successful status, and unique transaction ID.
- Deduplicates transaction IDs and records a traceable station ledger receipt and audit event only after provider confirmation.
- Does not include credentials in the source archive.

## Critical transaction semantics

The current receiving-test path detects and reconciles a credit; it does not originate the transfer. A Field Team Station is an app record, not a bank account or payment rail. To move the $200 from an external source into PayPal, the application must connect a real, authorized source-provider account and its documented transfer API. PayPal credentials alone cannot credit arbitrary money into the owner's wallet. Do not report success based on an internal ledger entry or CEO authorization.

## Mandatory production-only release gate

Follow `LIVE_200_DOLLAR_RELEASE_GATE.md`. The final APK/release must not be delivered as complete until the exact $200.00 USD live transfer is actually received and independently verified in the owner's production PayPal account, GMM reconciles it once, and build/release checks pass. Do not use PayPal Sandbox, sandbox credentials, or simulated payment evidence for this acceptance test. Non-money code checks may be run in isolated development tooling, but the payment environment must remain live production.

## Current validation and blockers

The source archive was checked for ZIP integrity. Full dependency installation/build, deployment migrations, webhook delivery, a signed APK build, and the real $200 transfer have not been completed in this workspace. The source-to-PayPal transfer provider/account remains unidentified and unconnected. The release gate is therefore BLOCKED until the authorized source rail is connected and a live transfer is confirmed. No live transaction is claimed.
