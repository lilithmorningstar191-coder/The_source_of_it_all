# Get Money Machine — builder handoff

Start here:
1. Read `BUILDER_MASTER_PROMPT.md` in full.
2. Use `BUILDER_PROMPTS_QUICK_START.md` in sequence.
3. Use `BUILDER_RELEASE_CHECKLIST.md` before delivery.

## Owner's required flow

**15 existing Field Team Stations (workers) → GMM Ledger (outgoing source) → one CEO authorization → connected PayPal receiving account → automatic provider-side receipt verification → SUCCESSFUL TRANSFER popup.** No second confirmation after the send. PayPal is the destination, never the source for this flow.

## Current project facts

The repository already includes GMM ledger logic, PayPal credentials/webhook validation and transaction-reporting code, automatic detection of a matching $200.00 incoming credit, a receipt state and UI notification. The implementation notes document PayPal Payouts directionality and the incoming-transfer route still required. Inspect these existing components before modifying them; do not overwrite them with a new implementation.

The current documented workflow records CEO authorization as `AWAITING_SOURCE_TRANSFER`, and automatic PayPal reporting can detect an incoming credit. The project still must prove and connect the source-side API that can actually move the ledger's real available funds into the PayPal receiving account. Do not infer that a ledger record itself represents transferable cash. If the source-provider transfer mechanism is already elsewhere in this ZIP, find and reuse it; only report it missing after searching code, configs, migrations, and adapters.

## Validation performed in this handoff environment

- `node --experimental-strip-types --test src/lib/gmm/constants.test.ts` — passed: 2 tests, including exact 15-station invariant and locked transfer direction.
- Full install/typecheck/lint/build/Android compile and live provider transfer have not been run in this handoff step. The builder must run the complete commands in the master prompt and report their real results.
- No live $200.00 transfer is represented as sent or received.
