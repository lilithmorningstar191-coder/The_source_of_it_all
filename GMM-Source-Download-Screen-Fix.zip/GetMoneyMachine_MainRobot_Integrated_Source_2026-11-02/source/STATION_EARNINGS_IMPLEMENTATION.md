# Station earnings and real-money balance semantics

The application has 15 configured discovery stations. Station scans can discover opportunities and estimates, but connector data is untrusted and never creates cash. Owner-entered collection records are saved as station accounting activity; they do not automatically create money in Stripe or PayPal.

## Provider-confirmed available and transferable balance

The Dashboard and Move Money views read the platform's actual live Stripe balance (`GET /v1/balance`) and the PayPal merchant's reported USD balance (`GET /v1/reporting/balances`). Only live-mode, provider-confirmed available USD is counted in the combined available, spendable, and transferable display. The combined total spans distinct provider accounts; every payout is separately limited to the selected destination provider’s own spendable balance. Stripe test-mode balances are explicitly marked as test funds and are excluded. GMM Ledger remains the internal financial provider and source of truth. External execution-rail status is shown separately; if the rail balance cannot be read, the app preserves ledger records and does not claim the external payout is ready.

PayPal's reporting balances endpoint can lag by up to three hours and requires the `balances/read` reporting permission. Its snapshot time is displayed, and completed payouts after that snapshot are deducted conservatively from spendable money. In-flight payouts reserve funds to reduce the risk of spending the same funds twice. Because PayPal reporting can lag, recent completed payouts are also deducted from the app’s calculated spendable amount until the provider snapshot catches up; the UI identifies these as payout holds/recent deductions.

## Payout rules

- Stripe Connect transfers require enough live available balance in the platform Stripe account and a valid, onboarded connected account ID (`acct_...`). A Stripe transfer to a connected account is not a guarantee of immediate bank payout; the connected account's payout schedule and eligibility apply.
- PayPal Payouts require valid live credentials, access to the provider balance report, sufficient available PayPal balance, and a valid recipient.
- Unsupported provider labels (ACH, OnePay, Cash App, and debit card) are not offered as active payout rails until a genuine provider implementation is added.
- `gmm_ledger` is the canonical internal financial-provider record. The external execution adapter must still follow the selected rail’s officially supported funding rules; a ledger record is never misrepresented as a completed external deposit.

## Required live setup

Set a Stripe live secret key in the server environment. Save PayPal live credentials and grant the PayPal app the balances/read reporting permission in the PayPal developer dashboard. Recipient connected accounts must complete any Stripe onboarding and verification required by Stripe. Live provider credentials and balances cannot be verified by static code checks; this project must be tested with the actual provider accounts before claiming the payout rail is operational.
