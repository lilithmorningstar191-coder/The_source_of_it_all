# Stripe Connect and live provider-backed balances

## Live balance reads

The app reads `GET /v1/balance` using the server-side `STRIPE_SECRET_KEY`. The API response's USD `available` balance feeds live spendable/transferable money. USD `pending` is shown separately and never counts as spendable cash. A Stripe test-mode response is labelled `TEST_MODE — NOT REAL MONEY` and excluded from all real available/spendable totals.

## Stripe Connect transfers

In destination settings, select Stripe Connect and enter the recipient's connected account ID (`acct_...`). The recipient must have completed the onboarding and verification Stripe requires. Payout requests are checked against the verified live Stripe available balance and the local in-flight reservation amount before a transfer is submitted. The transfer request uses an idempotency key.

A Stripe Connect transfer moves funds from the platform Stripe balance into the connected account. It does not itself guarantee the recipient's bank has received the funds; the connected account's payout schedule, eligibility, country, and verification govern the subsequent bank payout.

## PayPal balance and payouts

The app reads `GET /v1/reporting/balances?currency_code=USD` from the live PayPal API. The configured PayPal app must have the `https://uri.paypal.com/services/reporting/balances/read` permission. PayPal reporting may lag by up to three hours; the snapshot time is displayed and recently completed PayPal payouts are conservatively deducted until the report catches up.

## Money integrity

GMM Ledger is the internal financial provider and canonical transaction source of truth. Station estimates and discovery payloads never mint money. External payout requests are submitted through official Stripe/PayPal execution adapters and must satisfy the selected rail’s real funding requirements. If an external balance read fails, preserve the ledger state and report the rail readiness separately; never invent a balance or claim an external payout succeeded.

Before live use, test with appropriate test-mode credentials and then verify the production account balance, enabled Connect capabilities, PayPal reporting permissions, recipient onboarding, settlements, payout status reconciliation, refunds/disputes, and provider-side bank payout configuration. Secrets must remain server-side.
