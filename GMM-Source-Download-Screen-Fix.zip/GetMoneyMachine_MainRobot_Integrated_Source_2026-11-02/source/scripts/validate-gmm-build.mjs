import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const read = (p) => readFileSync(resolve(root, p), 'utf8');
const fail = (m) => { console.error(`GMM VALIDATION FAILED: ${m}`); process.exitCode = 1; };

const constants = read('src/lib/gmm/constants.ts');
const core = read('src/lib/gmm/core.ts');
const android = read('android/app/src/main/java/com/getmoneymachine/MainActivity.kt');
const gradle = read('android/app/build.gradle.kts');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const paypal = read('src/lib/gmm/paypal.ts');
const buildDocs = read('android/BUILD_APK.md');
const migrations = read('migrations/0004_real_funds_and_public_discovery.sql');
const stripe = read('src/lib/gmm/stripe.ts');
const types = read('src/lib/gmm/types.ts');
const webUi = read('src/components/gmm-app.tsx');
const ledgerArchitecture = read('LEDGER_AND_REAL_MONEY_ARCHITECTURE.md');
const provenanceMigration = read('migrations/0005_ledger_orchestrator_provenance.sql');

const stationNames = [...constants.matchAll(/"([^"]+Station|Free Money)"/g)].map((m) => m[1]);
const expected = [
  'Free Money',
  'Unclaimed Property Station',
  'Refund Recovery Station',
  'Rebate Station',
  'Cashback Station',
  'Rewards Station',
  'Promotional Bonus Station',
  'Fee Recovery Station',
  'Overpayment Recovery Station',
  'Subscription Credit Station',
  'Settlement & Claims Station',
  'Business Incentive Station',
  'Public Opportunity Station',
  'Revenue Opportunity Station',
  'Reinvestment Station',
];
if (JSON.stringify(stationNames) !== JSON.stringify(expected)) fail('station order/names do not match the required 15-station specification');
if (!constants.includes('"Free Money"') || !core.includes('for (let i = 0; i < STATION_NAMES.length; i += 1)')) fail('Free Money station seeding/preservation logic is missing');
if (!core.includes("kind in ('STATION_COLLECTION', 'STATION_EARNINGS_IMPORT')") || !core.includes('STATION_EARNINGS_IMPORT')) fail('station earnings accounting aggregation is missing');
if (!core.includes('await runScan(sql, userId, stationId);')) fail('START does not trigger an immediate real scan');
if (!core.includes('CYCLE_MINUTES = 90') && !constants.includes('CYCLE_MINUTES = 90')) fail('90-minute cycle is missing');
if (!core.includes('fabricated_results: false')) fail('anti-fabrication invariant is missing');
if (!migrations.includes("provider_reference = 'REFERENCE-BALANCE-60173.45-FAILED-TRANSFER'") || !migrations.includes('DELETE FROM gmm_ledger')) fail('legacy synthetic aggregate balance cleanup is missing');
if (!stripe.includes('GET') && !stripe.includes('/v1/balance')) fail('Stripe provider balance read is missing');
if (!paypal.includes('/v1/reporting/balances')) fail('PayPal provider balance read is missing');
if (!core.includes('source: "provider_balances"') || !core.includes('providerBalance.spendable') || !core.includes('providerBalance.status !== "LIVE"')) fail('payouts are not bounded by verified live provider-backed spendable balance');
if (!ledgerArchitecture.includes('GMM Ledger is Get Money Machine\'s internal financial provider') || !ledgerArchitecture.includes('Builder invariants') || !read('BUILDER_HANDOFF_LEDGER_PROVIDER.md').includes('real production transfer')) fail('canonical ledger provider contract or builder acceptance requirements are missing');
if (!provenanceMigration.includes("DEFAULT 'GMM_LEDGER'") || !provenanceMigration.includes('execution_provider') || !core.includes('orchestrator=GMM_LEDGER')) fail('ledger orchestrator provenance is missing from payout lifecycle');
if (!types.includes('status: "READY" | "PARTIAL" | "UNAVAILABLE" | "NOT_CONFIGURED"')) fail('balance-read status is not exposed through the API type');
if (!paypal.includes('https://api-m.paypal.com')) fail('PayPal live endpoint is missing');
if (!paypal.includes('itemStatus ?? header.batch_status') || !core.includes('DENIED: "FAILED"')) fail('PayPal item-level payout reconciliation is incomplete');
if (paypal.includes('sandbox.paypal.com')) fail('PayPal sandbox endpoint remains in source');
if (!manifest.includes('android.permission.INTERNET')) fail('Android INTERNET permission is missing');
if (!/compileSdk\s*=\s*35/.test(gradle) || !/minSdk\s*=\s*26/.test(gradle) || !/targetSdk\s*=\s*35/.test(gradle)) fail('Android SDK targets are incomplete');
if (!gradle.includes('com.android.application')) fail('Android application plugin is missing');
if (!existsSync(resolve(root, 'android/gradlew'))) fail('Gradle wrapper is missing');
if (!existsSync(resolve(root, 'android/gradle/wrapper/gradle-wrapper.properties'))) fail('Gradle wrapper properties are missing');
if (!buildDocs.includes('Free Money')) fail('APK handoff does not mention Free Money');
if (android.includes('15 stations') || android.includes('15 Stations')) fail('Android UI still claims 15 stations');
if (read('src/components/gmm-app.tsx').includes('15 Stations')) fail('web UI still claims 15 stations');
if (!core.includes('as station_earnings') || !core.includes('as completed_collections')) fail('station-specific ledger earnings aggregation is missing');
if (!webUi.includes('RECORDED STATION EARNINGS')) fail('web station cards do not show station-specific earnings');
if (!webUi.includes('GMM Ledger') || !webUi.includes('provider balances') || !webUi.includes('providerSpendableLabel') || !webUi.includes('balanceStatusLabel(state.balance.status)')) fail('web UI does not show ledger orchestration and provider balance status safely');
if (!android.includes('Recorded station earnings:')) fail('Android station cards do not show station-specific earnings');
if (!android.includes('LIVE SPENDABLE / TRANSFERABLE') || !android.includes('nullableNumber("available")') || !android.includes('delay(30_000)') || !android.includes('nullableString("as_of")')) fail('Android UI does not refresh and show provider-backed balances/status');

if (process.exitCode) process.exit();
console.log('GMM STATIC VALIDATION: PASS');
console.log(`Stations: ${expected.length} (Free Money preserved as #1)`);
console.log('Station earnings: accounting records only; they do not create cash.');
console.log('GMM Ledger: canonical internal financial provider, ledger, and payout orchestrator.');
console.log('Stripe/PayPal: external execution rails subject to their official funding requirements.');
console.log('Balance integrity: ledger state and external execution-rail readiness remain distinct; no fabricated cash or payout success.');
console.log('START: immediate real scan');
console.log('Cycle: 90 minutes');
console.log('Fabricated earnings: disabled');
console.log('PayPal endpoint: production api-m.paypal.com');
console.log('Android: native Compose / SDK 35 / min 26 / target 35');
