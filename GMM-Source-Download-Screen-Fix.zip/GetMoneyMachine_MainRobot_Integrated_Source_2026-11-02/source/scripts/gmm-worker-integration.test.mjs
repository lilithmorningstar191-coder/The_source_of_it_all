import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => readFile(path.join(root, p), 'utf8');

test('internal worker route requires server secret and configured owner', async () => {
  const source = await read('src/lib/gmm/rest.ts');
  assert.match(source, /path === "\/internal\/worker\/tick"/);
  assert.match(source, /process\.env\.GMM_WORKER_SECRET/);
  assert.match(source, /process\.env\.GMM_OWNER_USER_ID/);
  assert.match(source, /mismatch !== 0\) return err\("Unauthorized", 401\)/);
  assert.match(source, /runScheduledStationCycles\(ownerId\)/);
});

test('scheduled station cycles only select enabled, active, unpaused, non-emergency due stations', async () => {
  const source = await read('src/lib/gmm/core.ts');
  const start = source.indexOf('export async function runScheduledStationCycles');
  assert.notEqual(start, -1);
  const end = source.indexOf('\nexport async function withOwnerSql', start);
  const body = source.slice(start, end);
  for (const condition of ['enabled = true', 'active = true', 'paused = false', 'emergency_stopped = false', 'next_cycle_at <= now()']) {
    assert.ok(body.includes(condition), `missing ${condition}`);
  }
  assert.doesNotMatch(body, /requestTransfer|startPaypal|stripe|paypal/i);
});

test('cron runner fails closed without API URL and worker secret', async () => {
  const source = await read('scripts/run-gmm-worker.mjs');
  assert.match(source, /GMM_API_URL/);
  assert.match(source, /GMM_WORKER_SECRET/);
  assert.match(source, /process\.exit\(2\)/);
  assert.match(source, /\/api\/gmm\/internal\/worker\/tick/);
});
