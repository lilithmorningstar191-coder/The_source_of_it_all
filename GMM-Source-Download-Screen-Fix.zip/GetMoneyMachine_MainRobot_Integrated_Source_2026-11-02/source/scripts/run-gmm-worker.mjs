const apiBase = (process.env.GMM_API_URL ?? "").trim().replace(/\/$/, "");
const secret = (process.env.GMM_WORKER_SECRET ?? "").trim();
if (!apiBase || !secret) {
  console.error("GMM_API_URL and GMM_WORKER_SECRET are required; no station work was run.");
  process.exit(2);
}
const url = `${apiBase.replace(/\/api\/gmm$/, "")}/api/gmm/internal/worker/tick`;
const response = await fetch(url, {
  method: "POST",
  headers: { Authorization: `Bearer ${secret}`, Accept: "application/json" },
  signal: AbortSignal.timeout(25_000),
});
const body = await response.text();
if (!response.ok) {
  console.error(`GMM background tick failed (${response.status}): ${body.slice(0, 1000)}`);
  process.exit(1);
}
console.log(body);
