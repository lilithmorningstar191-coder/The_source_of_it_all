# Builder handoff — implement, build, and prove GMM Ledger

This is an implementation contract, not a request to redesign the financial model.

## Canonical identity

- Application financial provider / internal source of truth: `GMM_LEDGER`.
- Canonical transaction store: `gmm_ledger` plus linked reservation, withdrawal, provider-response, and audit records.
- External execution adapters: `STRIPE_CONNECT` and `PAYPAL`.
- Every code path must preserve the ledger transaction ID, owner, amount, currency, idempotency key, funding basis, destination, execution rail, provider reference, status history, and audit trail.

## Required build tasks

1. Read `LEDGER_AND_REAL_MONEY_ARCHITECTURE.md` before changing money-related code.
2. Apply all migrations in numeric order, including `0005_ledger_orchestrator_provenance.sql`.
3. Trace every balance, payout, webhook, refund/reversal, and UI display back to the ledger record. Remove competing internal balance sources.
4. Keep owner-verified ledger availability distinct from external rail readiness. Preserve owner verification when a rail is unavailable; show the rail as unavailable without erasing or relabeling the ledger record.
5. Ensure transfer requests reserve ledger funds atomically before external submission; enforce idempotency and prevent double spending.
6. Implement only provider-supported funding and payout operations. Stripe/PayPal APIs may require funds held by the provider; do not represent an internal database balance as already deposited there.
7. Run static validation, unit tests, typecheck, lint, production build, migration checks, and preview smoke tests. Fix failures rather than reporting success from partial checks.
8. In preview, test a failed/missing-credentials case, a provider-unavailable case, a duplicate-submit case, a definitive provider failure/reversal case, and a successful provider response.
9. A real-money proof requires real production credentials, a funded eligible provider account, a valid destination, and the owner's explicit confirmation of the exact amount. Submit a small real transaction, capture the provider reference, verify its final status through the provider API, and show the corresponding ledger/audit entries. Test mode is not real-money proof. The owner explicitly forbids PayPal Sandbox for the acceptance test.

## Completion report required

Report each check as PASS / FAIL / BLOCKED with evidence. Distinguish source validation, local preview, test-mode transfer, and real production transfer. Never state that a live transfer succeeded unless the provider's authoritative status confirms it.
