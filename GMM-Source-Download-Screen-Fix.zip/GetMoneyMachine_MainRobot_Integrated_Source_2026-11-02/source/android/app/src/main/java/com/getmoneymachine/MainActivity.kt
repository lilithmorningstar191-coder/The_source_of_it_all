package com.getmoneymachine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.time.Instant
import java.time.Duration
import kotlinx.coroutines.flow.first

private val API_URL = BuildConfig.API_URL.trimEnd('/')
private val ComponentActivity.tokenStore get() = applicationContext.dataStore
private val android.content.Context.dataStore by preferencesDataStore(name = "gmm_session")
private val API_KEY = stringPreferencesKey("api_url")
@Volatile private var liveApiUrl: String = API_URL

private fun normalizeApi(raw: String): String {
    val trimmed = raw.trim().trimEnd('/')
    return if (trimmed.endsWith("/api/gmm")) trimmed else "$trimmed/api/gmm"
}

private suspend fun api(path: String, token: String? = null, method: String = "GET", body: String? = null): JsonElement = withContext(Dispatchers.IO) {
    val root = normalizeApi(liveApiUrl)
    val c = (URL(root + path).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 20_000
        readTimeout = 20_000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("Content-Type", "application/json")
        token?.let { setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) doOutput = true
    }
    if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    val response = c.responseCode
    val stream = if (response in 200..299) c.inputStream else c.errorStream
    val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
    if (response !in 200..299) {
        val detail = runCatching { Json.parseToJsonElement(text).jsonObject["detail"]?.jsonPrimitive?.content }.getOrNull()
        error(detail ?: "HTTP $response")
    }
    Json.parseToJsonElement(text)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContent { MaterialTheme { App(this@MainActivity) } }
    }
}

@Composable
private fun App(activity: MainActivity) {
    var apiUrl by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val store = activity.applicationContext.dataStore.data.first()
        apiUrl = store[API_KEY] ?: API_URL
        liveApiUrl = apiUrl
        loaded = true
    }
    if (!loaded) return
    if (apiUrl.isBlank()) {
        ApiSetup { value ->
            apiUrl = value
            liveApiUrl = value
            activity.applicationContext.dataStore.edit { it[API_KEY] = value }
        }
    } else MainShell("")
}

@Composable
private fun ApiSetup(onSave: (String) -> Unit) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GET MONEY MACHINE", style = MaterialTheme.typography.headlineMedium)
        Text("Production API URL")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(url, { url = it }, label = { Text("https://your-app.example/api/gmm") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSave(url.trim()) }, enabled = url.startsWith("https://"), modifier = Modifier.fillMaxWidth()) { Text("SAVE API URL") }
    }
}

private val tabs = listOf("Dashboard", "Stations", "Move Money", "Transactions", "Security", "Notifications")

@Composable
private fun MainShell(token: String) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("Dashboard") }
    var stations by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var balance by remember { mutableStateOf<JsonObject?>(null) }
    var destinations by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var withdrawals by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var transactions by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var audit by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var notifications by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var paypal by remember { mutableStateOf<JsonObject?>(null) }
    var error by remember { mutableStateOf("") }

    fun load() {
        scope.launch {
            try {
                val results = listOf(
                    api("/stations", token).jsonArray,
                    api("/balance", token).jsonObject,
                    api("/destinations", token).jsonArray,
                    api("/withdrawals", token).jsonArray,
                    api("/transactions", token).jsonArray,
                    api("/audit", token).jsonArray,
                    api("/notifications", token).jsonArray,
                    api("/paypal/status", token).jsonObject
                )
                stations = results[0].jsonArray; balance = results[1].jsonObject; destinations = results[2].jsonArray
                withdrawals = results[3].jsonArray; transactions = results[4].jsonArray; audit = results[5].jsonArray
                notifications = results[6].jsonArray; paypal = results[7].jsonObject; error = ""
            } catch (e: Exception) { error = e.message ?: "Backend unavailable" }
        }
    }
    LaunchedEffect(Unit) {
        load()
        // Refresh provider-backed balances while the app is open; provider snapshots
        // still display their own as-of timestamps and are never treated as fabricated cash.
        while (true) {
            delay(30_000)
            try {
                balance = api("/balance", token).jsonObject
            } catch (e: Exception) {
                if (balance == null) error = e.message ?: "Balance refresh failed"
            }
        }
    }

    fun post(path: String) {
        scope.launch { try { api(path, token, "POST"); load() } catch (e: Exception) { error = e.message ?: "Request failed" } }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("GET MONEY MACHINE", style = MaterialTheme.typography.titleLarge); Text("GMM Ledger · Verified external funding") }
        }
        ScrollableTabRow(selectedTabIndex = tabs.indexOf(tab).coerceAtLeast(0)) {
            tabs.forEach { label -> Tab(selected = tab == label, onClick = { tab = label }, text = { Text(label) }) }
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        when (tab) {
            "Dashboard" -> Dashboard(stations, balance, paypal, ::post)
            "Stations" -> Stations(stations, token, ::post, load)
            "Move Money" -> MoveMoney(balance, destinations, withdrawals, stations, token, load, { error = it })
            "Transactions" -> JsonList("Ledger Transactions", transactions)
            "Security" -> JsonList("Audit & Security", audit)
            "Notifications" -> JsonList("Notifications", notifications)
        }
    }
}

@Composable
private fun Dashboard(stations: JsonArray, balance: JsonObject?, paypal: JsonObject?, post: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(8.dp))
        val currentStatus = balance?.string("status") ?: "UNAVAILABLE"
        val stripe = balance?.obj("stripe")
        val paypalBalance = balance?.obj("paypal")
        Text("LIVE SPENDABLE / TRANSFERABLE: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("spendable")}"}", style = MaterialTheme.typography.titleMedium)
        Text("Verified live available: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("available")}"}")
        Text("Provider pending: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("pending")}"}; payout holds/recent deductions: $${balance?.number("reserved")}")
        Text("Balance status: $currentStatus")
        Text("Stripe: ${stripe?.string("status") ?: "NOT_CONFIGURED"} · available ${stripe?.nullableNumber("available") ?: "—"} · spendable ${providerSpendableText(stripe)}")
        stripe?.nullableString("as_of")?.let { Text("Stripe balance checked: $it") }
        stripe?.nullableString("message")?.let { Text(it) }
        Text("PayPal: ${paypalBalance?.string("status") ?: "NOT_CONFIGURED"} · available ${paypalBalance?.nullableNumber("available") ?: "—"} · spendable ${providerSpendableText(paypalBalance)}")
        paypalBalance?.nullableString("as_of")?.let { Text("PayPal balance snapshot: $it") }
        paypalBalance?.nullableString("message")?.let { Text(it) }
        Text("Station collections are accounting records only; they do not create depositable cash.")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ post("/stations/control/start") }) { Text("START ALL") }
            Button({ post("/stations/control/stop") }) { Text("STOP ALL") }
            Button({ post("/stations/control/pause") }) { Text("PAUSE ALL") }
            Button({ post("/stations/control/emergency") }) { Text("EMERGENCY") }
        }
        Text("Station earnings", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        Text("Each amount below is calculated only from completed ledger collections assigned to that station. The opening balance is not assigned to a station without a source breakdown.")
        stations.forEach { station ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(station.jsonObject.string("name"), modifier = Modifier.weight(1f))
                Text("$${station.jsonObject.number("station_earnings")}")
            }
        }
        Text("Running stations discover only through configured real connectors; they never create money automatically.")
    }
}

@Composable
private fun Stations(stations: JsonArray, token: String, post: (String) -> Unit, reload: () -> Unit) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<JsonObject?>(null) }
    LazyColumn(Modifier.fillMaxSize()) {
        items(stations) { station ->
            val id = station.int("id")
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text(station.string("name"), style = MaterialTheme.typography.titleMedium)
                    Text("Recorded earnings: $${station.number("station_earnings")}")
                    Text("${station.int("completed_collections")} completed collections")
                    val nextCycle = station.string("next_cycle_at")
                    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
                    LaunchedEffect(station.int("id"), station.bool("active"), station.bool("paused"), nextCycle) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
                    val remaining = if (station.bool("paused")) station.int("paused_remaining_seconds").toLong() else if (station.bool("active") && nextCycle.isNotBlank()) runCatching { maxOf(0, Duration.between(Instant.ofEpochMilli(now), Instant.parse(nextCycle)).seconds) }.getOrDefault(0) else 0
                    Text(if (station.bool("active")) "RUNNING • ${remaining/3600}:${(remaining%3600)/60}:${remaining%60}" else if (station.bool("paused")) "PAUSED • ${remaining/3600}:${(remaining%3600)/60}:${remaining%60}" else "STOPPED")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("start", "pause", "stop", "enable", "disable", "emergency").forEach { action ->
                            TextButton({ post("/stations/$id/$action") }) { Text(action.uppercase()) }
                        }
                    }
                    TextButton({ selected = station }) { Text("DETAILS / SCAN / OPPORTUNITIES") }
                }
            }
        }
    }
    selected?.let { StationDetail(it, token, { selected = null }, reload) }
}

@Composable
private fun StationDetail(station: JsonObject, token: String, close: () -> Unit, reload: () -> Unit) {
    val scope = rememberCoroutineScope()
    val id = station.int("id")
    var opportunities by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var title by remember { mutableStateOf("") }
    var evidence by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    fun load() { scope.launch { runCatching { opportunities = api("/opportunities?station_id=$id", token).jsonArray }.onFailure { message = it.message ?: "Load failed" } } }
    LaunchedEffect(Unit) { load() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(station.string("name"), style = MaterialTheme.typography.titleLarge); TextButton(close) { Text("CLOSE") } }
        Text("Recorded station earnings: $${station.number("station_earnings")}", style = MaterialTheme.typography.titleMedium)
        Text("${station.int("completed_collections")} completed collections · amounts are linked by station ID")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ scope.launch { runCatching { api("/stations/$id/scan", token, "POST"); load(); reload() }.onFailure { message = it.message ?: "Scan failed" } } }) { Text("SCAN") }
        }
        OutlinedTextField(title, { title = it }, label = { Text("Opportunity title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value, { value = it }, label = { Text("Collected amount") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(evidence, { evidence = it }, label = { Text("Source note") }, modifier = Modifier.fillMaxWidth())
        Button({
            scope.launch {
                try {
                    api("/collections", token, "POST", buildJsonObject {
                        put("station_id", id); put("title", title); put("amount", value.toDoubleOrNull()); put("evidence", evidence)
                    }.toString())
                    title = ""; value = ""; evidence = ""; message = "Collection recorded in accounting; provider-backed cash balance unchanged"; load(); reload()
                } catch (e: Exception) { message = e.message ?: "Save failed" }
            }
        }) { Text("RECORD COMPLETED COLLECTION") }
        if (message.isNotEmpty()) Text(message, modifier = Modifier.padding(6.dp))
        LazyColumn { items(opportunities) { o -> Text("#${o.int("id")} ${o.string("title")} • ${o.string("state")} • estimated $${o.number("estimated_value")}", modifier = Modifier.padding(vertical = 4.dp)) } }
    }
}

@Composable
private fun MoveMoney(balance: JsonObject?, destinations: JsonArray, withdrawals: JsonArray, stations: JsonArray, token: String, reload: () -> Unit, onError: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf("PAYPAL") }
    var label by remember { mutableStateOf("") }
    var providerData by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var depositTests by remember { mutableStateOf<JsonArray>(buildJsonArray { }) }
    var selectedStationId by remember { mutableStateOf("") }
    var stationMenuOpen by remember { mutableStateOf(false) }
    var testTransactionId by remember { mutableStateOf("") }
    var pendingTestId by remember { mutableStateOf("") }
    var confirmTestDialog by remember { mutableStateOf(false) }
    val types = listOf("PAYPAL", "STRIPE_CONNECT")
    LaunchedEffect(Unit) {
        runCatching { depositTests = api("/paypal/deposit-tests", token).jsonArray }
            .onFailure { message = it.message ?: "Could not load deposit tests" }
    }
    if (confirmTestDialog) AlertDialog(
        onDismissRequest = { confirmTestDialog = false },
        title = { Text("CEO confirmation: $100 test") },
        text = { Text("Prepare one $100.00 USD PayPal receiving test from the selected Field Team Station. This creates an audited request but does NOT move money automatically. A real supported source-provider transfer must be executed first; GMM will then verify the credit directly with PayPal.") },
        confirmButton = { TextButton(onClick = {
            confirmTestDialog = false
            scope.launch {
                try {
                    val result = api("/paypal/deposit-tests", token, "POST", buildJsonObject {
                        put("station_id", selectedStationId.toInt()); put("ceo_confirmed", true); put("idempotency_key", "GMM-PP-TEST-${UUID.randomUUID()}")
                    }.toString()).jsonObject
                    message = "Test #${result["id"]?.jsonPrimitive?.content ?: "?"} prepared. No money has moved yet. Execute the real source-provider transfer, then reconcile its PayPal transaction ID."
                    depositTests = api("/paypal/deposit-tests", token).jsonArray
                } catch (e: Exception) { onError(e.message ?: "Could not prepare test") }
            }
        }) { Text("CONFIRM & PREPARE") } },
        dismissButton = { TextButton(onClick = { confirmTestDialog = false }) { Text("CANCEL") } }
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        val currentStatus = balance?.string("status") ?: "UNAVAILABLE"
        val stripe = balance?.obj("stripe")
        val paypalBalance = balance?.obj("paypal")
        Text("LIVE SPENDABLE / TRANSFERABLE: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("spendable")}"}", style = MaterialTheme.typography.titleMedium)
        Text("Verified live available: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("available")}"}")
        Text("Pending: ${if (currentStatus == "UNAVAILABLE" || currentStatus == "NOT_CONFIGURED") "—" else "$${balance?.number("pending")}"}; payout holds/recent deductions: $${balance?.number("reserved")}")
        Text("Balance status: $currentStatus")
        Text("Stripe: ${stripe?.string("status") ?: "NOT_CONFIGURED"} · available ${stripe?.nullableNumber("available") ?: "—"} · spendable ${providerSpendableText(stripe)}")
        stripe?.nullableString("as_of")?.let { Text("Stripe balance checked: $it") }
        stripe?.nullableString("message")?.let { Text(it) }
        Text("PayPal: ${paypalBalance?.string("status") ?: "NOT_CONFIGURED"} · available ${paypalBalance?.nullableNumber("available") ?: "—"} · spendable ${providerSpendableText(paypalBalance)}")
        paypalBalance?.nullableString("as_of")?.let { Text("PayPal balance snapshot: $it") }
        paypalBalance?.nullableString("message")?.let { Text(it) }
        Text("GMM Ledger records and controls authorization. Field Team Stations are the workers/funding engine; the CEO verifies and confirms; PayPal is the receiving destination. PayPal Payouts is not a deposit rail, so the app requires a supported source-provider transfer and direct PayPal receipt verification.")
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("CEO-CONTROLLED $100 PAYPAL RECEIVING TEST", style = MaterialTheme.typography.titleMedium)
                Text("Workers/stations → CEO confirmation → PayPal. The station ledger is not proof of a deposit. The source provider must execute the real supported transfer into the receiving route issued by PayPal. GMM verifies a successful $100.00 USD incoming bank/EFT credit (T0300/T0303) in PayPal Transaction Search; reporting may lag up to three hours.")
                Spacer(Modifier.height(8.dp))
                Box {
                    val selectedName = stations.firstOrNull { it.jsonObject["id"]?.jsonPrimitive?.content == selectedStationId }?.jsonObject?.string("name")
                    OutlinedButton(onClick = { stationMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedName ?: "Select source Field Team Station") }
                    DropdownMenu(expanded = stationMenuOpen, onDismissRequest = { stationMenuOpen = false }) {
                        stations.forEach { item ->
                            DropdownMenuItem(text = { Text(item.jsonObject.string("name")) }, onClick = {
                                selectedStationId = item.jsonObject.int("id").toString(); stationMenuOpen = false
                            })
                        }
                    }
                }
                Button(enabled = selectedStationId.isNotBlank(), onClick = { confirmTestDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("CEO CONFIRM & PREPARE $100 TEST") }
                depositTests.forEach { item ->
                    val test = item.jsonObject
                    Spacer(Modifier.height(8.dp))
                    Text("Test #${test["id"]?.jsonPrimitive?.content ?: "?"} · $${test["amount"]?.jsonPrimitive?.content ?: "100.00"} · ${test.string("status").replace('_', ' ')}", style = MaterialTheme.typography.titleSmall)
                    Text("${test.string("station_name")} · PayPal transaction ${test.nullableString("paypal_transaction_id") ?: "not confirmed"}")
                    if (test.string("status") == "AWAITING_SOURCE_TRANSFER") {
                        OutlinedTextField(testTransactionId, { testTransactionId = it }, label = { Text("Real PayPal transaction ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(enabled = testTransactionId.isNotBlank(), onClick = {
                            val id = test["id"]?.jsonPrimitive?.content ?: return@Button
                            pendingTestId = id
                            scope.launch {
                                try {
                                    val confirmed = api("/paypal/deposit-tests/$id/confirm", token, "POST", buildJsonObject { put("transaction_id", testTransactionId.trim()) }.toString()).jsonObject
                                    message = "PayPal confirmed $100.00 USD receipt. Test status: ${confirmed.string("status")}."
                                    testTransactionId = ""; depositTests = api("/paypal/deposit-tests", token).jsonArray; reload()
                                } catch (e: Exception) { onError(e.message ?: "PayPal receipt verification failed") }
                                finally { pendingTestId = "" }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (pendingTestId == test["id"]?.jsonPrimitive?.content) "CHECKING PAYPAL…" else "VERIFY CREDIT WITH PAYPAL") }
                    }
                    test.nullableString("error_message")?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
        Text("Add transfer destination", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(label, { label = it }, label = { Text("Destination label") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            types.forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
        }
        OutlinedTextField(
            providerData,
            { providerData = it },
            label = { Text(if (type == "PAYPAL") "PayPal recipient email" else "Stripe connected account ID (acct_...)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Button(enabled = label.isNotBlank() && providerData.isNotBlank(), onClick = {
            scope.launch {
                try {
                    val external = if (type == "PAYPAL") providerData.trim() else providerData.trim()
                    val d = api("/destinations", token, "POST", buildJsonObject {
                        put("type", type); put("label", label.trim()); put("external_id", external)
                    }.toString()).jsonObject
                    selected = d["id"]!!.jsonPrimitive.content
                    label = ""; providerData = ""; message = "$type destination saved"; reload()
                } catch (e: Exception) { onError(e.message ?: "Destination failed") }
            }
        }) { Text("SAVE DESTINATION") }
        Spacer(Modifier.height(10.dp))
        Text("Transfer", style = MaterialTheme.typography.titleMedium)
        val enabledDestinations = destinations.filter { it.jsonObject["enabled"]?.jsonPrimitive?.booleanOrNull == true }
        if (enabledDestinations.isNotEmpty()) {
            enabledDestinations.forEach { d ->
                val id = d.jsonObject["id"]!!.jsonPrimitive.content
                FilterChip(selected = selected == id, onClick = { selected = id }, label = { Text(d.jsonObject["label"]!!.jsonPrimitive.content) })
            }
        } else Text("No enabled destination is configured yet.")
        OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(enabled = amount.toDoubleOrNull()?.let { it > 0 } == true && selected.isNotBlank(), onClick = {
            scope.launch {
                try {
                    val w = api("/withdrawals", token, "POST", buildJsonObject {
                        put("amount", amount.toDouble()); put("destination_id", selected.toInt()); put("idempotency_key", UUID.randomUUID().toString())
                    }.toString()).jsonObject
                    message = "Transfer status: ${w.string("status")}"; amount = ""; reload()
                } catch (e: Exception) { onError(e.message ?: "Transfer failed") }
            }
        }) { Text("TRANSFER") }
        if (message.isNotEmpty()) Text(message, modifier = Modifier.padding(6.dp))
        Text("Transfer History", style = MaterialTheme.typography.titleMedium)
        JsonRows(withdrawals)
    }
}

@Composable
private fun JsonList(title: String, rows: JsonArray) { Column(Modifier.fillMaxSize()) { Text(title, style = MaterialTheme.typography.titleLarge); JsonRows(rows) } }

@Composable
private fun JsonRows(rows: JsonArray) {
    LazyColumn { items(rows) { row -> Text(row.toString(), modifier = Modifier.padding(vertical = 4.dp)) } }
}

private fun JsonObject.string(key: String): String = this[key]?.jsonPrimitive?.contentOrNull ?: ""
private fun JsonObject.bool(key: String): Boolean = this[key]?.jsonPrimitive?.booleanOrNull ?: false
private fun JsonObject.int(key: String): Int = this[key]?.jsonPrimitive?.intOrNull ?: 0
private fun JsonObject.number(key: String): String = this[key]?.jsonPrimitive?.contentOrNull ?: "0.00"
private fun JsonObject.nullableNumber(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull?.let { "$${it}" }
private fun JsonObject.nullableString(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }

private fun providerSpendableText(balance: JsonObject?): String =
    if (balance == null || balance.string("status") in listOf("UNAVAILABLE", "NOT_CONFIGURED")) "—"
    else "$${balance.number("spendable")}"
private fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
