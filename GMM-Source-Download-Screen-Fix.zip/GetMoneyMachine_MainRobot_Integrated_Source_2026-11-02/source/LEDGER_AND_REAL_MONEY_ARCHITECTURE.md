# Get Money Machine — Ledger Provider Contract (mandatory builder specification)

## One source of truth across the entire application

**GMM Ledger is Get Money Machine's internal financial provider, authoritative ledger, and payout orchestrator.** Treat `GMM_LEDGER` as the app-wide financial-provider identity in UI, API contracts, database provenance, logs, audit records, tests, and generated build configuration. The ledger owns the application-level transaction lifecycle: owner authorization, balance accounting, idempotency, reservations, transaction status, audit history, and reconciliation. Do not create a second competing internal balance or silently route around the ledger.

**Stripe and PayPal are connected external execution rails called by GMM Ledger.** They are not the application's internal ledger or source of truth. Their APIs can only move money that is actually eligible for movement under the relevant provider account and product. A payout record must retain both `orchestrator=GMM_LEDGER` and the exact `execution_provider` (`STRIPE_CONNECT` or `PAYPAL`) plus its funding basis and external reference.

## Required money states

Keep these concepts distinct in every component:

1. **Ledger-recorded:** an accounting entry exists.
2. **Owner-verified:** the owner has attested to the record, with timestamp, evidence/reference, amount, currency, and audit actor recorded. This is a meaningful ledger verification state; it must not be discarded merely because an external balance API is unavailable.
3. **Ledger-available:** the ledger's verified balance after completed debits, reversals, holds, and in-flight reservations. This is the internal source-of-truth balance and must never be fabricated from station estimates or discovery results.
4. **Rail-fundable:** the selected external rail has the required account, capabilities, credentials, and funds or approved funding arrangement to execute the transaction.
5. **Submitted / processing / completed / failed:** transaction lifecycle states. A button click or a local ledger debit is never proof that an external payment completed.

Do not collapse these states into one generic “real/fake” flag. If the external rail cannot currently be verified, keep the ledger record and its owner-verification state intact; show the external-rail status separately. Never display an unavailable external amount as `$0`, and never substitute an unverified external amount.

## Transfer contract

1. GMM Ledger receives the transfer request, authenticates the owner, validates amount/currency/destination, and enforces an idempotency key.
2. GMM Ledger checks its own owner-verified ledger-available amount and creates an atomic reservation so the same funds cannot be sent twice.
3. GMM Ledger calls the configured Stripe or PayPal execution rail using server-side credentials and the provider-supported funding flow. The request must explicitly record its funding basis. The implementation must not claim the ledger database itself is a bank account or invent a provider-issued account number.
4. The external API may accept, reject, or leave the transfer processing. Record the exact response/reference and reconcile callbacks/status polling. Release or reverse reservations correctly on definitive failure. Only an authoritative provider success can mark the external payout completed.
5. If a provider requires funds in its own account, an eligible source, or a separate funding operation, the implementation must use that provider-supported path. A ledger entry or owner attestation does not automatically credit Stripe or PayPal. Never silently misrepresent this requirement or pretend a payout was sent.
6. Every payout, webhook, status update, reservation, reversal, and audit entry must be linked to the same GMM Ledger transaction and identify the actual external execution rail.

## Builder invariants — do not reinterpret these

- GMM Ledger is the application's internal financial provider and sole internal transaction source of truth.
- Stripe/PayPal are external execution rails; they must not replace GMM Ledger as the app's accounting authority.
- All balances use integer cents / decimal-safe arithmetic, USD unless a supported currency is explicitly implemented.
- Record actual Field Team provider earnings as earned/payable ledger entries when supported by the station/provider’s real activity and evidence. Do not book opportunity estimates or unverified search results as earned amounts, and do not confuse an earned/payable ledger entry with a completed external transfer.
- Owner verification must be persisted as a distinct auditable fact; it is not a fabricated bank/provider confirmation.
- Prevent a retry or double tap of the same operation from executing twice, race-condition overspending, double debits, and duplicate webhook processing. Do not blanket-block separate new transfer requests; each new operation needs its own authorization and identity.
- Keep test/sandbox funds separate from live money. No test funds can appear as live spendable money.
- No success UI, receipt, or “paid” status until the execution rail confirms the relevant success state.
- Do not expose provider secrets in client/browser/Android code.
- Do not replace a missing implementation with a mock success, fake account details, fabricated balances, or placeholder transaction IDs.

## Preview acceptance: prove it rather than claim it

The builder must finish the app, run database migrations, pass tests, and open the preview. The preview must show a clear integration/readiness status for the ledger and each execution rail. To prove a **real-money** transfer, configure genuine production credentials server-side, a real funded/capable provider account, and a valid destination; then submit a small owner-approved live transfer, retain the real provider reference, and verify the final status against the provider. A preview using test credentials proves only the test flow, not a real-money transfer. Do not run a real-money transfer without the owner's explicit confirmation of the exact amount and destination.

A source-code/static check cannot certify external account setup or guarantee that a real payout will be accepted. If the environment lacks the required credentials, provider funding, migrations, or destination capability, report the exact blocker; do not claim the live-money test passed.
