# GMM private-owner handoff — status and truth conditions

**Scope:** one privately owned Android app for one owner. This package is not a public release, Google Play submission, or multi-tenant product launch.

## What is in this package

- Recovered GMM application/backend source and migrations.
- GMM Ledger account and 15-station model, API routes, authentication, audit/withdrawal records, and recovery documentation.
- Read-only `GET /api/gmm/account/status` route for authenticated inspection of the configured database records.
- Provider-neutral call interface for a GMM-controlled settlement service, with HTTPS enforcement (except localhost), bearer-secret authentication, idempotency key, timeout, and reconciliation behavior.
- Builder handoff prompt and verification gates.

## What is not established by this local package

No live deployment was accessed or verified. No production database was queried from this workspace. No cash custodian/source account was independently verified. No transfer was initiated or received. The remote settlement service implementation, production URL/secret, and authorized source-of-funds connection are not present in the recovered files. An internal ledger balance or the hard-coded/reported opening amount is an accounting record, not proof that spendable external cash exists.

The owner-reported opening amount is **$60,173.45 USD**. Preserve it as a reported/recovery record until reconciled against authoritative records; do not silently convert it to verified cash or fabricate funding transactions. The reported failed $60,000 attempt requires source/destination reconciliation before any reversal or retry.

## Release / completion gates — all must pass before calling the app fully complete

1. Build and test the current source on a clean environment; fix all failures, including existing metadata tests, typecheck, and Android packaging.
2. Deploy the backend to the owner's private environment and capture the exact deployment/revision identity.
3. Authenticate and call `GET /api/gmm/account/status`; independently confirm the endpoint is the live deployment and that it reads the intended persistent production database, not local PGlite or preview data.
4. Reconcile the ledger rows and all 15 station allocations against trustworthy source records; investigate duplicates, failed/pending transfers, and opening-balance imports. Do not treat station arithmetic or seeded records as evidence of external funds.
5. Identify the actual source account/custodian holding cleared funds and obtain an authoritative balance/transaction record. If no external source balance exists, the ledger cannot itself create cash.
6. Implement/deploy the missing GMM-controlled settlement service. It must authenticate the caller, authorize only the owner, verify available settled source funds, validate destination ownership, enforce amount limits and idempotency, persist immutable audit evidence, handle timeouts/reconciliation safely, and report `COMPLETED` only after authoritative destination receipt is confirmed.
7. Test in a non-live environment first. Then, only after funds/source/destination are independently verified and the owner authorizes it, run a small live transfer and independently confirm the destination receipt, source debit, settlement reference, and ledger posting. Do not use a large $60,000 attempt as the first test.
8. Re-run build, typecheck, auth/security checks, all tests, migration checks, Android install/launch, and end-to-end tests. Attach actual logs/results, not screenshots or simulated responses alone.

## Design constraints

- GMM Ledger remains the app's account/ledger authority.
- Private single-owner operation only; no public release or Google Play work.
- Do not redesign the app or substitute a different account product.
- Do not add Stripe, PayPal, or Moov as GMM's core ledger/account backend. Existing legacy/provider code must not be mistaken for a working source-to-destination settlement route.
- A destination label such as PayPal, Cash App, or debit card is not a transfer rail. Any external delivery requires a lawful, authorized route and source of settled funds. If the owner has not authorized/configured one, fail closed and explain the blocker; never simulate success.
- Never store secrets in source control, client code, APKs, or this ZIP. Configure secrets only in the private server environment.

## Current truthful completion state

**Recovery source and handoff assembled: yes. Local ZIP integrity: to be verified by packaging check. Live production verification and real-money settlement: not completed.** This distinction is intentional: no access to the owner's deployment, production database, source account, or settlement endpoint was available in this workspace, so claiming those actions are done would be false.
