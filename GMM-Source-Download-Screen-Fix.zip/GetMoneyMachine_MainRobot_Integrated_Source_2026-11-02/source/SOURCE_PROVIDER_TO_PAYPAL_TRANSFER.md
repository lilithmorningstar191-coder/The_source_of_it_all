# Field Team source-provider → PayPal receiving transfer

## Active workflow
1. The CEO selects a Field Team Station and explicitly authorizes the $200.00 USD test.
2. GMM creates an idempotent `AWAITING_SOURCE_TRANSFER` authorization record. It does not create a checkout, request payment from a payer, or mark funds received.
3. The station's real, authorized source-provider rail must initiate a $200.00 USD transfer to the connected PayPal receiving account.
4. After the provider reports that it initiated the transfer, GMM checks the actual incoming transaction through PayPal Transaction Search and records `RECEIVED` only when PayPal confirms the exact amount and currency.

## Live source-provider connector is still required
The project does not currently contain the source provider's production API endpoint, authentication method, source account/worker identifiers, recipient-routing contract, or provider-specific transfer and status-lookup endpoints. A Field Team Station inside GMM is application logic; its name and ledger balance do not themselves provide a bank/payment account or the authority to move money.

Do not invent an endpoint or send credentials to an undocumented URL. To enable automated initiation, connect the actual provider API and its authorized production account. The integration must support a real outbound transfer to the specified PayPal receiver, idempotency, transfer-status lookup, and a provider reference that can be reconciled with PayPal's incoming transaction report. If the actual provider cannot send funds to PayPal, that provider cannot be used as the source rail for this flow.

PayPal client credentials are used here only to validate and reconcile the receiving account. They are not a generic API for crediting arbitrary money into the owner's PayPal balance.
