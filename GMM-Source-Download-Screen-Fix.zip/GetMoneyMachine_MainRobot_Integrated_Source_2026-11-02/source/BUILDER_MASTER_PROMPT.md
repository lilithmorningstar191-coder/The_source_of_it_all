# GMM Builder Master Prompt — Finish the Existing App, Do Not Rebuild It

You are receiving the complete existing Get Money Machine (GMM) project. Treat this as an implementation and release-completion task, not a greenfield redesign. Read the existing source, configuration, migrations, attached notes, and all handoff documents before editing. Reuse working implementations already present. Do not ask the owner to repeat the business flow described below.

## OWNER MONEY DIRECTIVE — HIGHEST PRIORITY

The existing GMM opening ledger balance is the owner's designated, verified opening balance of **$60,173.45 USD**. Preserve that exact amount and the project's existing Available/Spendable/Transferable balance meaning. Do not label it fictional, simulated, estimated, pending, or unverified merely because an external transfer to PayPal has not happened. Do not reset it after station activity, overwrite it, silently deduct from it, or subtract $60,000 unless a matching authorized ledger transaction explicitly requires that debit. New successfully recorded station earnings accrue on top of the opening balance. If documents conflict, preserve this owner money directive. Keep PayPal receipt status separate: never fabricate a PayPal confirmation, but never use the absence of a PayPal receipt as a reason to alter or contradict the GMM ledger balance.

## Non-negotiable business flow

**Exactly 15 existing Field Team Stations (workers) → existing GMM Ledger (source of the outgoing funds) → one CEO authorization → the owner's already-connected PayPal account as destination → automatic provider-side receipt verification → one “SUCCESSFUL TRANSFER” notification.**

- Preserve all 15 original station names, ordering, configuration, amounts, IDs, descriptions, and directory structure. Do not expand to 50 stations, rename stations, delete features, or replace the project with a demo.
- Field Team Stations are the workers/funding engine. GMM Ledger is the source-side accounting and orchestration layer. PayPal is the receiving destination only for this flow.
- The owner authorizes once before sending. Do not require a second manual receipt confirmation.
- Never use customer checkout, Orders API capture, PayPal Payouts, or a PayPal withdrawal as a substitute for this outgoing GMM-ledger-to-PayPal receiving transaction.
- Never mark success based on a UI action, local ledger row, request acceptance, pending status, webhook receipt without validation, or a guessed transaction. Success requires independently verified provider evidence that the funds were credited to the intended PayPal account.
- The first live test amount is exactly USD 200.00. Never send money automatically during development or deployment. The live test must be explicitly authorized by the owner in the deployed app after the source route and destination are confirmed.
- Do not invent new earnings, station source accounts, account numbers, provider endpoints, transfer permissions, or external account balances. Preserve the owner-designated $60,173.45 GMM opening ledger balance exactly as specified above. Keep the GMM ledger balance separate from PayPal-side receipt confirmation without relabeling or changing the GMM balance.

## First: audit before coding

1. Inspect `src/lib/gmm/core.ts`, `paypal.ts`, `stripe.ts`, `api.ts`, `types.ts`, `constants.ts`, `src/components/gmm-app.tsx`, all API routes, migrations, `.env.example`/environment documentation, Android wrapper, `package.json`, lockfile, and the existing `GMM_*`, `*_IMPLEMENTATION.md`, `*_READINESS.md`, and builder-handoff docs.
2. Identify existing source-provider connection(s), stored credentials, account identifiers, and transfer methods already in the project. Reuse the real implementation if it exists. Do not assume it is absent just because a README says so; inspect code, migrations, configuration schema, and connector adapters first.
3. Produce a brief evidence-based inventory of each actual implementation and exact remaining blocker. Then implement every blocker that can be solved from the supplied code and authorized APIs.
4. Keep changes focused and additive. Preserve unrelated app features, authentication, authorization, station configuration, visual design, and data.

## Required end-to-end implementation

### Source funds and ledger
- Identify how the real money represented by GMM's available ledger balance is held and what authorized API can debit/move it. A database balance alone is not a money-moving rail.
- Use the existing source provider/account connection in the project if it truly supports this direction. If the source funds are already held by a connected financial institution or processor, implement its documented outbound transfer method, server-side authentication, account/recipient mapping, idempotency, transfer status lookup, and webhook or polling reconciliation.
- If the project has no supported rail to send those funds to the PayPal receiving account, do not fake a rail or point requests at an invented endpoint. Complete the adapter interface, schemas, error handling, environment validation, test fixtures, and provider documentation, and state the precise external authorization/account capability still required. Do not represent that portion as live-complete.
- Reserve funds atomically before execution. Prevent concurrent requests, double-spending, duplicate transfers, replayed idempotency keys, and cross-user access. Use integer cents or the existing money helpers; never floating-point arithmetic for balances.
- Treat timeouts/ambiguous results as `RECONCILIATION_REQUIRED`, not failed or successful. Query the provider by stable reference before retrying.

### CEO authorization and transfer state machine
- Require authenticated owner/CEO and server-side ownership validation for station, ledger, destination, and transaction IDs.
- One explicit authorization before initiation. Receipt confirmation is automatic and must not prompt the user to click a second confirmation button.
- Persist a state machine such as `DRAFT → AUTHORIZED → SUBMITTING → PENDING/RECONCILIATION_REQUIRED → RECEIVED/COMPLETED`, with `FAILED` only for a definitive provider rejection. Record actor, amount, currency, station/source, destination account alias, timestamps, provider references, and sanitized failure details.
- Use DB transactions and unique constraints to make reservation, transfer intent, provider reference, and ledger posting idempotent.

### PayPal receiving side
- Inspect and reuse the existing live PayPal credential storage and transaction-search implementation. Keep secrets server-side; never return them to the browser, log them, include them in a ZIP handoff, or commit them.
- Confirm the configured credentials correspond to the intended live PayPal account/app and have required reporting/webhook permissions. Verify webhook signatures using the correct live webhook ID and validate event resource, amount, currency, status, receiver/account identity where available, and transaction reference.
- Prefer a validated webhook for prompt updates plus scheduled/polling reconciliation as a recovery path. Reporting latency must not create false negatives or false successes. Poll only the relevant time window, handle pagination, timeouts, retries, rate limits, and delayed reports.
- Match the actual incoming credit to the exact authorized transfer using amount, currency, destination, provider/source reference where available, and safe matching rules. Amount-only matching is insufficient if multiple same-amount transactions could exist. If unambiguous correlation is impossible, leave pending and show a clear reconciliation state.
- Record PayPal's external transaction ID once, enforce unique provider transaction references, and prevent receipt ledger rows from double-counting the same cash.
- On confirmed credit only, update the transfer state and show a clear success dialog/toast: `SUCCESSFUL TRANSFER — $200.00 USD received in PayPal`. Include source station, destination alias, timestamp, and transaction reference. No manual transaction ID entry and no second receipt confirmation.

### Security, reliability, and data integrity
- Validate every request with schemas; authorize every operation server-side; rate-limit transfer initiation; protect CSRF/session boundaries according to the app's auth framework.
- Use safe error messages in the UI and detailed but secret-free server logs. Never expose tokens, secrets, full account data, or raw provider payloads unnecessarily.
- Validate webhook signatures before deduplication decisions. Handle replay attacks, duplicate events, out-of-order events, concurrent callbacks, retries, and partial DB failures.
- Add migrations with safe defaults, appropriate indexes/unique constraints, and rollback/recovery notes. Do not mutate historical ledger data silently.
- Add tests for wrong direction, insufficient funds, unauthorized user, malformed amount/currency, duplicate submit, provider timeout, definitive rejection, ambiguous response, duplicate webhook, invalid signature, delayed PayPal reporting, wrong receiving account, same-amount unrelated credit, receipt exactly once, and successful end-to-end reconciliation.

## Build and release requirements

Run from the project root and fix actual errors:
1. `npm ci` (use network if needed; report registry/network failures accurately).
2. `npm run typecheck`.
3. `npm test`.
4. `npm run lint`.
5. `npm run build` and the project's database migrations against a disposable/test database first; do not run a destructive migration against production without explicit approval.
6. Run browser/UI smoke tests for sign-in, dashboard, all 15 stations, CEO authorization, pending transfer, automatic receipt update, success popup, and failure/reconciliation states.
7. If Android is part of this deliverable, inspect `android/` and its Gradle wrapper; run the appropriate debug APK build (`./gradlew assembleDebug`) and report the exact artifact path and build result. Do not claim an APK is built unless the file exists and the build succeeded.
8. Verify the final ZIP with `unzip -t`, include the project root consistently, include all required source/config/migrations/docs, and exclude `.env`, credentials, `node_modules`, build caches, private keys, and secrets.
9. Provide a concise release report with commands actually run, pass/fail results, APK/ZIP paths, exact live configuration still required, and whether a real-money transfer was actually performed. Never claim a live transfer test without provider evidence.

## Definition of done

The task is done only when the existing app builds, tests pass (or every remaining failure is precisely documented), all 15 stations and unrelated features remain intact, the source-to-PayPal transfer direction cannot be reversed in code/UI, a single CEO authorization initiates one real supported transfer, PayPal receipt is detected without manual confirmation, the success popup is triggered only by verified receipt, and ledger accounting reconciles exactly once. If a missing external provider capability prevents real movement, finish all code possible and identify that single precise external blocker without pretending it is solved.
