# Wise Minds Creation — GitHub / Render upload

This archive contains the project files with the repository contents at the ZIP root.

## Important
- Do **not** upload this ZIP as a single file and expect Render to deploy it. Render needs the extracted source files in a Git repository.
- Do not commit `.env`, API secrets, private keys, database passwords, or provider credentials.
- The app's production deployment and database/API connection have not yet been verified. Do not treat this package as proof that live balances or transfers work.

## Create the GitHub repository
1. Download and extract `WISE_MINDS_GITHUB_UPLOAD.zip` on a computer if possible. On Android, use the Files app's **Extract** option.
2. In GitHub, create a **new empty repository** named `wise-minds-creation`. Do not add a README, license, or `.gitignore` during creation.
3. Upload the **contents of the extracted folder**, not the ZIP itself. GitHub's browser uploader may not handle a whole project with nested folders reliably on a phone; if it fails, use GitHub Desktop or Git from a computer to push the extracted folder.
4. Confirm `package.json`, `vite.config.ts`, `src/`, `server/`, `migrations/`, and `android/` appear at the repository root.
5. In Render, create a Web Service from that GitHub repository, using the existing Wise Minds Creation Postgres database. Do not create a replacement database.

## Render build/start settings
- Runtime: Node
- Build command: `npm ci && npm run build`
- Start command: `npm start`
- Health check path: use the app's existing health endpoint only after confirming it in source.

Configure required environment variables in Render's Environment page using the project's documented setup. Never paste secrets into GitHub. Do not run database migrations against production until the target database and migration impact are reviewed.
