# GMM — Three-Tier Implementation Completion Prompt

Complete the existing Get Money Machine project in this repository. Inspect and implement directly in the existing codebase, preserving the current UI, database, original 15 Field Team Stations, station names/order/configuration, ledger records, authentication, and directory structure.

## Required business model: exactly three tiers

1. **Tier 1 — Field Team employees/providers:** The existing 15 Field Team Stations represent the user's field-team employees/providers. They perform the work and submit their actual provider/activity results into the existing GMM workflow. Connect each station's real data and status to its backend records; do not invent earnings or treat station activity estimates as cash.
2. **Tier 2 — CEO confirmation:** The owner/CEO reviews and confirms the submitted activity and authorizes the applicable action once. Connect the existing UI to persistent server-side authorization and ensure retries cannot duplicate an action.
3. **Tier 3 — Bank account / receiving visibility:** The CEO can see and verify the resulting external financial activity in the connected receiving account. This tier must display the actual provider/account balance or transaction evidence, status, timestamps, and reference when available. It must not treat a local ledger entry as proof that an external account received funds.

Keep this as three tiers. Do not add tiers or replace the user's model with a different provider/account architecture.

## Findings from the current repository that must be completed

- `src/lib/gmm/stripe.ts` implements a Stripe balance read and a **Stripe Connect** transfer to a Stripe connected account. It does not implement Stripe Treasury financial-account transfers, and a Connect transfer is not a transfer to PayPal.
- `src/lib/gmm/core.ts` must use the correct supported transfer route for incoming funds. PayPal Payouts sends money out of an existing PayPal balance; it does not credit the owner's PayPal balance from an arbitrary internal GMM ledger balance.
- `SOURCE_PROVIDER_TO_PAYPAL_TRANSFER.md` documents that the actual source-provider transfer-initiation API, authentication contract, source account identifiers, recipient routing, and transfer-status lookup are still missing.
- `src/lib/gmm/paypal.ts` supports PayPal API authentication and incoming-credit lookup/reconciliation. That monitoring does not initiate the source transfer.
- Existing Stripe Connect and PayPal balance code must not be misrepresented as Stripe Treasury or as a completed GMM-to-PayPal transfer.

## Implementation work

1. Map every existing station, provider record, CEO approval action, ledger record, transfer API, bank/receiving-account view, and webhook to the three tiers above. Produce a concise in-project mapping and implement missing wiring directly.
2. Inspect all current provider configuration, SDK dependencies, API routes, migrations, and environment access. Identify whether a real Stripe Treasury integration and eligible financial account exist in the supplied project/account configuration. The current repository scan did not find a Stripe Treasury-specific implementation. Implement the supported Treasury endpoints only after confirming the actual product, account capabilities, source financial account, destination route, and API permissions.
3. Implement the real transfer from the appropriate actual funding mechanism to the user's intended PayPal receiving account only if a supported and authorized rail exists. Include provider-side transfer initiation, idempotency, status retrieval, timeout recovery, unique provider references, webhook/reconciliation handling, and accounting records. Do not invent endpoints or treat a ledger number as externally transferable money.
4. If Stripe Treasury cannot transfer directly to PayPal, implement the actual supported route that is available in the user's connected financial setup. Document the exact missing provider capability or account permission if no such route is available. Do not substitute Stripe Connect without clearly establishing that it matches the required route.
5. Wire the existing CEO confirmation to the server-side transfer execution once. Persist requested, authorized, processing, received/settled, failed, and reconciliation-required states. Duplicate submissions and webhook retries must not duplicate transfers or ledger postings.
6. Use the existing PayPal integration to verify actual incoming receipt by transaction ID/reference, amount, currency, status, and timestamps. Handle reporting delays and recoverable API errors. Show `SUCCESSFUL TRANSFER` only after PayPal provides authoritative evidence that the funds were credited to the intended account.
7. Ensure the Tier 3 bank/receiving-account view reflects actual provider-backed information, with timestamps and clear distinction between internal ledger records, pending transfers, and externally confirmed receipt. Never fabricate available balance or claim that money moved based only on a ledger entry.
8. Preserve the original 15 Field Team Stations and existing user data. Fix mismatches across frontend, backend, database migrations, webhooks, and Android client where present.
9. Run the existing tests, typecheck, lint, production build, migration checks, and Android build where supported. Add tests for CEO approval, successful receipt, rejected transfers, duplicate requests/events, delayed reporting, timeouts, and recovery. Report exact results and any external provider/account prerequisite still blocking live execution.
10. Deliver the updated ZIP and a clear implementation report. Do not claim a live transfer or completed PayPal receipt unless a real transaction was actually verified.
