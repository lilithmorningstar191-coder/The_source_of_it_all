# GMM three-tier transfer flow — owner intent and implementation boundary

## Business flow (preserve)

**15 Field Team Stations / providers → GMM Ledger → one CEO authorization → the CEO's connected PayPal receiving account → automatic receipt reconciliation → SUCCESSFUL TRANSFER notification.**

- Keep exactly 15 stations, with their existing names and order; Free Money remains station 1.
- Field Team Stations are the providers/workers in the GMM business model. Record their actual earned activity and attributable earnings as earnings in GMM's ledger, with the station/provider, amount, currency, evidence/provenance, and timestamp. Do not relabel genuinely earned provider earnings as fictional merely because the receiving transfer has not yet occurred.
- GMM Ledger is the internal accounting and transfer-orchestration source. Its entries describe what GMM records as earned/payable; they do not themselves create an external bank/wallet balance or supply a payment network.
- The CEO authorizes once before initiating the transfer. Receipt checking is automatic; do not ask the CEO for a second manual receipt confirmation.
- PayPal is the receiving destination for this flow, not the source.
- A transfer request that is accepted or still processing is shown as pending/in progress. Show SUCCESSFUL TRANSFER only after PayPal/provider evidence confirms that the matching funds reached the intended receiving account. This is a truthful transaction-status rule, not a judgment that station providers did not earn their money.
- Repeated user actions are allowed as separate new actions when appropriate. A retry of the same transfer operation must reuse its operation/idempotency identity so a network retry or double tap does not send the same funds twice. This is not a blanket ban on new requests.

## What can and cannot be completed from this ZIP

The ZIP contains PayPal credential/OAuth and transaction-reporting helpers, incoming-credit reconciliation, Stripe Connect transfer code, ledger orchestration, and a transfer workflow. It does not identify an authorized source-side account/API that holds the funds represented by GMM earnings and supports moving them to the owner's PayPal receiving account. Stripe Connect transfer sends funds to a connected Stripe account; PayPal Payouts sends money out of a PayPal balance. Neither is a generic API for moving GMM's internal ledger balance into an arbitrary PayPal balance.

Therefore, the remaining live integration requirement is the real source provider and its authorized transfer capability: provider/product, source account or financial-account identifier, supported outbound endpoint, receiver-routing method accepted for the owner's PayPal account, required permissions, stable transfer reference, status lookup/webhook, and idempotency semantics. These must be obtained from the provider account/docs and configured server-side. No undocumented endpoint or fake success can safely substitute for them.

## Completion criteria

1. A station/provider's actual earnings are recorded as earnings, with a traceable source and status.
2. The CEO authorizes once; GMM records a transfer operation bound to its amount, source, and PayPal destination.
3. The real authorized source rail submits the transfer and returns its reference/status.
4. GMM automatically reconciles that operation against authoritative PayPal receipt evidence.
5. The success notification fires once after receipt is confirmed. Delays and uncertain provider outcomes remain in a visible pending/reconciliation state and are automatically checked; no manual receipt confirmation is required.
6. Retry handling prevents the same operation from being executed twice, while allowing a genuinely new transfer to be created intentionally.

No live money movement is claimed until the source-side rail is configured and a real authorized end-to-end transaction is verified.
