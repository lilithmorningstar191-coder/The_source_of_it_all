# GMM-native transfer execution patch

This patch adds the missing **software integration point** between the existing GMM Ledger withdrawal orchestrator and a GMM-controlled settlement service. It does not add a PayPal Payouts or Stripe transfer path.

## Required server configuration

- `GMM_NATIVE_TRANSFER_URL`: HTTPS endpoint for the original/authorized GMM settlement service.
- `GMM_NATIVE_TRANSFER_SECRET`: server-side bearer secret shared with that service.

Do not put the secret in Android/client code. Do not point this setting at an unverified service.

## Request contract

`POST` JSON fields: `source` (`GMM_LEDGER`), `destination_type`, `destination_id`, `amount` (USD decimal string), `currency` (`USD`), `idempotency_key`, `withdrawal_id`, and `user_reference`. Header `Idempotency-Key` repeats the same idempotency key.

The service must authenticate the caller, authorize the user/destination, verify actual source funds are available, reserve/debit atomically, execute the real transfer, and make duplicate requests with the same idempotency key safe. It must not treat the app's display balance as proof of settled money.

Successful HTTP responses must be JSON with `status` (`PENDING`, `PROCESSING`, `COMPLETED`, or `FAILED`) and a stable `reference`. `COMPLETED` must only be returned after the settlement service has independently confirmed the destination receipt. Unknown or ambiguous responses are retained as `RECONCILIATION_REQUIRED` by the app.

## Important status

The code path is now present, but **real transfers are not enabled by this patch alone**. The original settlement endpoint and its credentials were not present in the recovered files, so the environment variables cannot safely be populated and no live-money test can be performed. Until the original authorized endpoint is recovered and configured, the existing fail-closed provider path remains in use. This patch is not a deployment and does not establish that the displayed opening balance is externally settled cash.
