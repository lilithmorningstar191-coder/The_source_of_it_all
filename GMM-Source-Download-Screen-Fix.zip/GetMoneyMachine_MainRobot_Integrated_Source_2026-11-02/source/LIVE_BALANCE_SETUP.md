# Live spendable and transferable balance setup

GMM Ledger is the internal financial provider and canonical source of truth for application transactions. The app does not mint money from scanner results or estimates. Stripe and PayPal are external execution rails; their balance, account-capability, and funding requirements are tracked separately.

## Stripe

1. Configure `STRIPE_SECRET_KEY` on the server/deployment environment. Use a live secret key only after the Stripe account and Connect configuration are ready. Never put the secret in browser code, Android code, source control, or a ChatGPT message.
2. The app calls Stripe `GET /v1/balance` and reads the USD `available` and `pending` balances. `available` is used as the provider-reported available-funds input; `pending` is displayed separately and is not spendable.
3. Add a destination with its Stripe connected account ID (`acct_...`). The recipient account must be valid and have completed required Stripe onboarding/capability checks. Payout submission transfers funds from the platform Stripe balance to that connected account; the later bank payout is subject to Stripe's rules and schedule.
4. Test-mode funds are displayed as test mode and excluded from real spendable/transferable totals. Test credentials cannot send real payouts.

## PayPal

1. Configure the live `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` on the server, or save credentials in the app's PayPal configuration. Keep secrets server-side. If PayPal credentials were saved by an earlier build, save them again in this build so the stored provider environment is explicitly set to `live`; non-live database credentials are ignored for live balances and payouts.
2. Give the PayPal REST app the Payouts permission and the reporting scope `https://uri.paypal.com/services/reporting/balances/read` so the app can read `GET /v1/reporting/balances?currency_code=USD`. `PAYPAL_WEBHOOK_ID` is required for webhook signature verification.
3. Add a payout destination using a recipient email address. PayPal's reporting-balance data can lag up to three hours; the UI shows the provider snapshot time. Recent payouts are deducted from spendable funds while a stale snapshot catches up.

## Ledger authority and external funding

GMM Ledger is the internal financial provider, authoritative system of record, and payout orchestrator: it authorizes transfers, stores transaction history, tracks reservations and status, maintains the audit trail, and reconciles execution-rail responses. Every payout records GMM Ledger as orchestrator and Stripe/PayPal as the execution provider. The selected rail must use its officially supported funding flow. See `LEDGER_AND_REAL_MONEY_ARCHITECTURE.md` and `BUILDER_HANDOFF_LEDGER_PROVIDER.md`.

## How the values work

- **Available** is based on provider-reported USD available balances.
- **Spendable / transferable** subtracts local payout holds and recent payouts not yet reflected in a delayed PayPal report.
- **Pending** is displayed separately and is not available for payouts.
- **GMM Ledger** is the internal financial provider and authoritative transaction/orchestration record. Ledger entries and owner verification must remain visible and auditable; they must not be falsely represented as an external provider deposit unless an actual funding transaction confirms it. Recording estimates or discovering an opportunity never creates cash.
- **Combined balance is not interchangeable across providers.** Each payout request is checked against the selected destination provider's own balance. A combined total cannot be used to pay out more than the selected source can fund.
- If an external rail balance is unconfigured or cannot be verified, the UI shows `—` for that rail instead of claiming a verified $0. GMM Ledger records remain intact, while external execution readiness is reported separately.

## Verification before real use

Static validation checks that the app reads Stripe and PayPal balances, excludes Stripe test mode, displays provider-specific values and snapshot times, and blocks payouts when a provider balance is unavailable. Full TypeScript/Android builds and live payout tests must be run in an environment with installed dependencies, configured build tools, valid live provider credentials, and eligible recipient accounts. No live balance is claimed until the provider API actually returns it.
